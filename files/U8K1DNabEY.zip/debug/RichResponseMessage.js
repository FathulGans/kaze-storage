=> sock.relayMessage(
  m.chat,
  {
  botForwardedMessage: {
    message: {
      richResponseMessage: {
        messageType: 1,
        submessages: [
          {
            messageType: 2,
            messageText: "https://cloudstore.my.id\n𝜙﹒SIAGA! 𝅄\n ╰─ WOY BOS DATENG @6281524385851 🚨\nburuan rapiin chat, jangan sampe ketauan bucin di grup sebelah 🏃‍♂️"
          }
        ],
        unifiedResponse: {
          data: "eyJ0ZXh0IjoiaHR0cHM6Ly9jbG91ZHN0b3JlLm15LmlkXG7wnZyZ77mSU0lBR0EhIPCdhYRcbiDilbDilIAgV09ZIEJPUyBEQVRFTkcgQDYyODE1MjQzODU4NTEg8J+aqFxuYnVydWFuIHJhcGlpbiBjaGF0LCBqYW5nYW4gc2FtcGUga2V0YXVhbiBidWNpbiBkaSBncnVwIHNlYmVsYWgg8J+Pg+KAjeKZgu+4jyIsInNvdXJjZSI6ImNybTMtZmFsbGJhY2stZ2VuZXJhdGVkIn0="
        }
      }
    },
    contextInfo: {
      participant: "6281524385851@s.whatsapp.net",
      stanzaId: "ACEEC9F63B1AFF920F5F3AA462E710D5",
      quotedMessage: {
        extendedTextMessage: {
          endCardTiles: [],
          text: ".crm3",
          previewType: 0,
          inviteLinkGroupTypeV2: 0
        }
      }
    }
  }
},
  {}
)