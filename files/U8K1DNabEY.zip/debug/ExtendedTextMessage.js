=> sock.relayMessage(
  m.chat,
  {
  extendedTextMessage: {
    text: "📊 Berikut ini adalah statistik dari bot kami\nKey\tValue\nBot\tIchigo Kurosaki MD\nVersion\tv3.4.2\nUptime\t13m 23s\nUsers\t1621\nPremium\t0\nGroups\t96\nPlatform\tlinux x64\nNode\tv24.21.0\nCPU Load\t0.96%\nRAM\t20.01 GB / 25.44 GB\nHeap\t175.63 MB / 300.93 MB\nUpdated\t16.30.11\nIchigo Kurosaki MD"
  }
},
  {}
)