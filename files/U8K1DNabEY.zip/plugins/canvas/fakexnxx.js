import { createCanvas } from "@napi-rs/canvas";
import moment from "moment";
import te from "../../src/lib/ichigo-error.js";

const pluginConfig = {
  name: "fakexnxx",
  alias: [],
  category: "canvas",
  description: "Bikin fake komentar XNXX",
  usage: ".fakexnxx <nama>|<komentar>|[likes]|[dislikes]",
  example: ".fakexnxx Fauzan|Mantap bro|100|0",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 2,
  isEnabled: true,
};

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(" ");
  let line = "";
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + " ";
    const width = ctx.measureText(testLine).width;
    if (width > maxWidth && n > 0) {
      ctx.fillText(line, x, y);
      line = words[n] + " ";
      y += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, x, y);
}

async function handler(m, { sock }) {
  const input = m.text?.trim();
  if (!input || !input.includes("|")) {
    return m.reply(`⚠️ Harap masukkan nama dan komentar!\nContoh: \`${m.prefix}${m.command} Fauzan|Mantap bro|100|0\``);
  }

  const parts = input.split("|");
  const name = parts[0]?.trim();
  const quote = parts[1]?.trim();
  const likes = parts[2]?.trim() || "0";
  const dislikes = parts[3]?.trim() || "0";

  if (!name || !quote) {
    return m.reply(`⚠️ Parameter nama dan komentar diperlukan`);
  }

  await m.react("🕕");
  
  try {
    const date = moment().format("MMM D, YYYY, h:mm A");
    const canvas = createCanvas(650, 320);
    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "#00008B";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, "rgba(10,35,81,1)");
    gradient.addColorStop(1, "rgba(8,28,65,1)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#FF0000";
    ctx.fillRect(35, 50, 40, 15);

    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(35, 65, 40, 15);

    ctx.font = "bold 24px sans-serif";
    ctx.fillStyle = "#FFFFFF";
    ctx.textAlign = "left";
    ctx.fillText(name, 85, 75);

    ctx.font = "16px sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.textAlign = "right";
    ctx.fillText(date, canvas.width - 45, 75);

    ctx.font = "22px sans-serif";
    ctx.fillStyle = "#FFFFFF";
    ctx.textAlign = "left";
    wrapText(ctx, quote, 45, 140, canvas.width - 90, 32);

    ctx.font = "bold 20px sans-serif";
    ctx.fillStyle = "#FFFFFF";
    ctx.fillText(`👍 ${likes}`, 60, 265);

    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.fillText(`👎 ${dislikes}`, 140, 265);

    ctx.fillText("Reply", 220, 265);
    ctx.fillText("Report", 310, 265);

    const buffer = await canvas.encode("png");
    await sock.sendMessage(m.chat, { image: buffer, caption: "🔞 *Fake XNXX Comment*" }, { quoted: m });
    await m.react("✅");

  } catch (err) {
    await m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };
