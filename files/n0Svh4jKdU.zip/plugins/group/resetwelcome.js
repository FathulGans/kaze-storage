import { getDatabase } from '../../src/lib/ichigo-database.js'

const pluginConfig = {
    name: 'resetwelcome',
    alias: ['delwelcome', 'clearwelcome'],
    category: 'group',
    description: 'Reset welcome message ke default',
    usage: '.resetwelcome',
    example: '.resetwelcome',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const groupData = db.getGroup(m.chat)

    if (!groupData?.welcomeMsg) {
        return m.reply(`❌ *ɢᴀɢᴀʟ*\n\n> Welcome message sudah default`)
    }

    db.setGroup(m.chat, { welcomeMsg: null })
    db.save()

    m.react('✅')

    await m.reply(`✅ *ᴡᴇʟᴄᴏᴍᴇ ᴅɪʀᴇsᴇᴛ*\n\n> Kembali ke pesan default`)
}

export { pluginConfig as config, handler }