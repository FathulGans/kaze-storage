import axios from "axios";
import config from "../../config.js";

const GEMINI_MODEL = "gemini-3.6-flash";
const GEMINI_API_KEY = config?.geminiApiKey || config?.APIkey?.google || "";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

const FETCH_TIMEOUT_MS = 20000;

async function gemini(input = {}) {
  const payload = typeof input === "string" ? { message: input } : input || {};
  const { message, instruction = "" } = payload;

  if (!message) throw new Error("Message is required.");
  if (!GEMINI_API_KEY) {
    throw new Error(
      "Gemini API key belum diisi. Cek config.APIkey.google / config.geminiApiKey.",
    );
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

  try {
    const body = {
      contents: [
        {
          role: "user",
          parts: [{ text: message }],
        },
      ],

      generationConfig: {
        temperature: 1.0,
        topP: 0.95,

        thinkingConfig: {
          thinkingLevel: "low",
        },
      },
    };

    if (instruction) {
      body.systemInstruction = {
        parts: [{ text: instruction }],
      };
    }

    const { data } = await axios.post(GEMINI_URL, body, {
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": GEMINI_API_KEY,
      },
      signal: controller.signal,
    });

    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) {
      
      const finishReason = data?.candidates?.[0]?.finishReason;
      throw new Error(
        `Gemini API tidak mengembalikan teks${finishReason ? ` (finishReason: ${finishReason})` : ""}.`,
      );
    }

    return {
      text: text.trim(),
      sessionId: null, 
    };
  } catch (error) {
    if (error.name === "CanceledError" || error.code === "ERR_CANCELED") {
      throw new Error(`Timeout memanggil Gemini API (>${FETCH_TIMEOUT_MS}ms)`);
    }
    if (error?.response?.data) {
      const apiMessage =
        typeof error.response.data === "string"
          ? error.response.data
          : error.response.data?.error?.message || error.response.data?.message;
      if (apiMessage) {
        error.message = apiMessage;
      }
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

export { gemini as chat };
export default gemini;
