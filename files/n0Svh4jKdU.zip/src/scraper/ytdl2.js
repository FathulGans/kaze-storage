import axios from "axios";
import crypto from "crypto";

const YOUTUBE_ID_REGEX = /(?:v=|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/;

const AES_KEY_HEX = "C5D58EF67A7584E4A29F6C35BBC4EB12";

const VALID_FORMATS = ["144", "240", "360", "480", "720", "1080", "mp3"];

const client = axios.create({
  headers: {
    "content-type": "application/json",
    origin: "https://yt.savetube.me",
    "user-agent":
      "Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0",
  },
  timeout: 30000,
});

function extractVideoId(url) {
  return String(url || "").match(YOUTUBE_ID_REGEX)?.[1] || null;
}

function decrypt(enc) {
  try {
    const src = Buffer.from(enc, "base64");
    const key = Buffer.from(AES_KEY_HEX, "hex");
    const iv = src.subarray(0, 16);
    const data = src.subarray(16);

    const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);
    const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);

    return JSON.parse(decrypted.toString());
  } catch (err) {
    throw new Error(`Gagal mendekripsi data: ${err.message}`);
  }
}

async function getCdn() {
  const { data } = await client.get("https://media.savetube.vip/api/random-cdn");

  if (!data?.cdn) {
    throw new Error("Tidak bisa mendapatkan server CDN dari SaveTube");
  }

  return data.cdn;
}

// SaveTube's response shape has changed a few times in the wild. Instead of
// hardcoding one path, walk the common possibilities so we don't break every
// time they rename a field.
function pickDownloadUrl(payload) {
  if (!payload) return null;
  const candidates = [
    payload?.downloadUrl,
    payload?.download_url,
    payload?.data?.downloadUrl,
    payload?.data?.download_url,
    payload?.data?.url,
    payload?.url,
    payload?.result?.downloadUrl,
    payload?.result?.url,
  ];
  return candidates.find((v) => typeof v === "string" && v.length > 0) || null;
}

function pickKey(info) {
  if (!info) return null;
  return (
    info?.key ||
    info?.data?.key ||
    info?.result?.key ||
    null
  );
}

async function ytdl2(url, format = "mp3") {
  try {
    const videoId = extractVideoId(url);

    if (!videoId) {
      return { status: false, mess: "Format URL tidak dikenali atau bukan link YouTube yang valid" };
    }

    if (!VALID_FORMATS.includes(format)) {
      return {
        status: false,
        mess: `Format tidak dikenali. Pilihan: ${VALID_FORMATS.join(", ")}`,
      };
    }

    const cdn = await getCdn();

    const infoRes = await client.post(`https://${cdn}/v2/info`, {
      url: `https://www.youtube.com/watch?v=${videoId}`,
    });

    if (!infoRes?.data?.data) {
      console.error("[ytdl2] Unexpected /v2/info response:", JSON.stringify(infoRes?.data));
      return { status: false, mess: "Respons /v2/info tidak sesuai (lihat log server untuk detail)." };
    }

    const info = decrypt(infoRes.data.data);
    const key = pickKey(info);

    if (!key) {
      console.error("[ytdl2] Decrypted info missing 'key':", JSON.stringify(info));
      return { status: false, mess: "Field 'key' tidak ditemukan pada info video (lihat log server)." };
    }

    const downloadType = format === "mp3" ? "audio" : "video";
    const quality = format === "mp3" ? "128" : format;

    const dlRes = await client.post(`https://${cdn}/download`, {
      id: videoId,
      downloadType,
      quality,
      key,
    });

    const downloadUrl = pickDownloadUrl(dlRes?.data);

    if (!downloadUrl) {
      // Log the full raw response so we can see SaveTube's actual current
      // field names instead of guessing blind.
      console.error("[ytdl2] /download response without a recognizable downloadUrl:", JSON.stringify(dlRes?.data));
      return {
        status: false,
        mess: "URL download tidak ditemukan pada respons SaveTube (raw response sudah di-log di server console).",
      };
    }

    return {
      status: true,
      title: info.title,
      videoId,
      thumbnail: info.thumbnail || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
      duration: info.duration,
      cached: Boolean(info.fromCache),
      format,
      download: downloadUrl,
    };
  } catch (err) {
    // If SaveTube returned an HTTP error, axios hides the body inside
    // err.response.data — surface it so the real cause is visible.
    const remoteDetail = err?.response?.data
      ? ` | remote: ${JSON.stringify(err.response.data)}`
      : "";
    if (err?.response?.data) {
      console.error("[ytdl2] Request failed with remote response:", JSON.stringify(err.response.data));
    }
    return { status: false, mess: `${err.message}${remoteDetail}` };
  }
}

export { ytdl2 };
export default ytdl2;