import fetch from 'node-fetch';

const pluginConfig = {
  name: 'tempmail',
  category: 'ai',
  command: ['tempmail'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, prefix, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        const _res = await fetch('https://rynekoo-api.hf.space/tools/tempmail/v1/create').then(r => r.json());
        if (!_res.success) return Reply('❌ Gagal membuat email sementara. Server down.');

        const _h = _res.result;
        let _teks = `📧 *TEMP MAIL CREATED* 📧\n\n`;
        _teks += `📬 *Email:* ${_h.email}\n`;
        _teks += `🔑 *Session ID:* \`${_h.sessionId}\`\n`;
        _teks += `⌛ *Expired:* ${_h.expiresAt}\n\n`;
        _teks += `💡 *Cara cek inbox:*\n`;
        _teks += `Ketik: *${prefix}checkmail ${_h.sessionId}*`;

        Reply(_teks);

    } catch (e) {
        console.error('[tempmail-error]', e.message);
        Reply('❌ Terjadi kesalahan pada server email.');
    }
};

export default handler;
