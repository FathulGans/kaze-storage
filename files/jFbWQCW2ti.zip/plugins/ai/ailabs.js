import FormData from 'form-data';
import axios from 'axios';
import { sleep } from '../../library/function.js';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'ailabs',
  category: 'ai',
  command: ['ailabs', 'buatvideo', 'aivideo', 'genvideo'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!tierAkses.isPrem(m.sender) && !isVip) 
        return Reply(mess.prem);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    
    if (!text && !mime.startsWith('image/')) {
        return Reply(example("a cat walking in the rain\nAtau reply gambar: .buatvideo make it animated"));
    }
    
    
    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    let imageBuffer = null;
    let imageUrl = '';
    
    if (mime.startsWith('image/')) {
        try {
            imageBuffer = await q.download();
            if (!imageBuffer) throw new Error('Gagal download gambar');
            
            const { ImageUploadService } = (await import('node-upload-images')).default;
            const service = new ImageUploadService('pixhost.to');
            const upload = await service.uploadFromBinary(imageBuffer, `video_${Date.now()}.jpg`);
            imageUrl = upload.directLink;
        } catch (e) {
            return Reply('❌ Gagal download/upload gambar');
        }
    }
    
    const prompt = text || "animate this image";
    
    try {
        let requestId = null;
        let formData = new FormData();
        formData.append("prompt", prompt);
        
        if (imageBuffer) {
            formData.append("initialFrame", imageBuffer, { filename: "image.jpg", contentType: "image/jpeg" });
        }
        
        const generateRes = await axios.post("https://www.freeaivideos.org/api/video_generation", formData, {
            headers: { ...formData.getHeaders(), "user-agent": "NB Android/1.0.0", "origin": "https://www.freeaivideos.org", "referer": "https://www.freeaivideos.org/" },
            timeout: 60000
        });
        
        requestId = generateRes.data?.request_id;
        
        if (!requestId) {
            throw new Error('Gagal mendapatkan request ID');
        }
        
        let videoUrl = null;
        let attempts = 0;
        const maxAttempts = 120;
        
        while (attempts < maxAttempts && !videoUrl) {
            await sleep(5000);
            attempts++;
            
            try {
                const statusRes = await axios.get(`https://www.freeaivideos.org/api/video_generation?request_id=${requestId}&prompt=`, {
                    headers: { "user-agent": "NB Android/1.0.0", "origin": "https://www.freeaivideos.org" },
                    timeout: 15000
                });
                
                if (statusRes.data?.video_url) {
                    videoUrl = statusRes.data.video_url;
                    break;
                }
            } catch (e) { console.error(e); }
        }
        
        if (!videoUrl) {
            throw new Error('Timeout: Video generation terlalu lama');
        }
        
        await raiden.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: mess.done,
            mimetype: 'video/mp4'
        }, { quoted: m });
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[AIVIDEO ERROR]', error);
        await Reply(mess.error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    }
};

export default handler;
