import axios from 'axios';

const pluginConfig = {
  name: 'chatplusai',
  category: 'ai',
  command: ['chatplusai', 'plusai'],
};

const handler = async (m, ctx) => {
    let { Reply, isPremium, isVip, raiden, text, troli } = ctx;
 if (!isPremium && !isVip) return Reply(global.mess.prem);
 
 var _qP9 = text ? text : (m.quoted && m.quoted.text ? m.quoted.text : "");
 if (!_qP9) return Reply("Ada yang bisa saya bantu? Silakan masukkan pertanyaan atau instruksi.");

 await m.react('🪄');

 try {
 var _axP9 = axios;
 var _apiKeyP9 = "nz-5736ed5d13";
 var _ownerNameP9 = global.namaOwner || "Master";

 var _instruct9 = "";
 if (isVip) {
 _instruct9 = `(System: Lawan bicaramu adalah Lord ${_ownerNameP9}, penciptamu. Berbicaralah dengan sangat sopan, setia, dan patuh). `;
 }

 var _finalQ9 = _instruct9 + _qP9;

 var _resP9 = await _axP9.get(`https://api.naze.biz.id/ai/chat?query=${encodeURIComponent(_finalQ9)}&apikey=${_apiKeyP9}`, {
 timeout: 60000
 });

 var _hasilP9 = _resP9.data?.message || _resP9.data?.result || _resP9.data;

 if (typeof _hasilP9 !== 'string') {
 _hasilP9 = JSON.stringify(_hasilP9);
 }

 if (!_hasilP9 || _hasilP9 === "undefined") throw new Error("API tidak memberikan respon teks.");

 await raiden.sendMessage(m.chat, { 
 text: _hasilP9.trim()
 }, { quoted: troli });

 await m.react('✅');

 } catch (e) {
 console.error('[CHATPLUS ERROR]:', e.message);
 await m.react('❌');
 var _errTxt = e.response?.data?.error || e.message;
 Reply("⚠️ Maaf Lord, terjadi kendala teknis pada server AI.\n\nError: " + _errTxt);
 }
};

export default handler;
