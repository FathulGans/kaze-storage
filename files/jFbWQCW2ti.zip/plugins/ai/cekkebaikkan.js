const pluginConfig = {
  name: 'cekkebaikkan',
  category: 'ai',
  command: ['cekkebaikkan'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden, troli } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
const _tKB = m.mentionedJid[0]||(m.quoted?m.quoted.sender:m.sender);
const _pKB = Math.floor(Math.random()*101);
const _kKB = _pKB>=80?'Malaikat versi manusia! Kebaikanmu nyata banget dirasain orang 😇':_pKB>=50?'Cukup baik, tapi masih ada celah buat jadi lebih baik 🙂':_pKB>=20?'Kebaikannya perlu diasah nih, coba lebih sering amal 😅':'Perlu banyak introspeksi nih brooo 😬';
await raiden.sendMessage(m.chat,{text:`😇 *CEK TINGKAT KEBAIKAN*\n\nTarget: @${_tKB.split('@')[0]}\nTingkat Kebaikan: *${_pKB}%*\n\n📝 ${_kKB}`,mentions:[_tKB]},{ quoted: troli });
};

export default handler;
