import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'raidenedit',
  category: 'ai',
  command: ['raidenedit'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden } = ctx;
    if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    const teks = q.text?.split(' ').slice(1).join(' ') || m.text?.split(' ').slice(1).join(' ');
    if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));
    if (!teks) return Reply(example("ubah jadi anime"));
    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, {
        react: { text: "⏰", key: m.key }
    });
    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");

        const base64Image = userImageBuffer.toString('base64');
        const mimeType = mime || 'image/jpeg';

        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${global.googleApiKey}`;

        const response = await axios.post(apiUrl, {
            contents: [{
                parts: [
                    {
                        inline_data: {
                            mime_type: mimeType,
                            data: base64Image
                        }
                    },
                    {
                        text: teks
                    }
                ]
            }]
        }, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 60000
        });

        const result = response.data;
        const textResult = result?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!textResult) throw new Error("Gemini tidak memberikan respons.");

        await raiden.sendMessage(m.chat, {
            text: `*✨ Raiden AI Edit:*\n\n${textResult}`
        }, { quoted: m });
        await raiden.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });
    } catch (e) {
        console.error('[RAIDENEDIT ERROR]', e);
        await raiden.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        });
        Reply(mess.error);
    }
};

export default handler;
