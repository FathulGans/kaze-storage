const pluginConfig = {
  name: 'autoai',
  category: 'ai',
  command: ['autoai'],
};

const handler = async (m, ctx) => {
    let { Reply, text } = ctx;
    const response = global.autoAiHandler.handleCommand(m, text);
    return Reply(response);
};

export default handler;
