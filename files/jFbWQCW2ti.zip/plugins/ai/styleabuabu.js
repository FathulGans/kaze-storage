import __axios from 'axios';

const pluginConfig = {
  name: 'styleabuabu',
  category: 'ai',
  command: ['styleabuabu'],
};

const handler = async (m, ctx) => {
    let { Reply, isPremium, isVip, raiden, safeErr, troli } = ctx;
 if (!isPremium && !isVip) return Reply(global.mess.prem);

 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';

 if (!/image/.test(mime)) {
 return Reply(`❌ Reply gambar!\nContoh:\n.styleabuabu`);
 }

 await m.react('⏳');

 try {
 const cloudinary = (await import('cloudinary')).default.v2;
 const axios = __axios;

 if (!global.cloudinaryCloudName || !global.cloudinaryApiKey || !global.cloudinaryApiSecret) {
 throw new Error("Config Cloudinary belum diisi");
 }

 cloudinary.config({
 cloud_name: global.cloudinaryCloudName,
 api_key: global.cloudinaryApiKey,
 api_secret: global.cloudinaryApiSecret
 });

 let buffer = await q.download();
 if (!buffer) throw new Error("Gagal download gambar");

 let upload = await new Promise((resolve, reject) => {
 const stream = cloudinary.uploader.upload_stream(
 { resource_type: 'image' },
 (err, res) => err ? reject(err) : resolve(res)
 );
 stream.end(buffer);
 });

 if (!upload?.secure_url) throw new Error("Upload gagal");

 let editedUrl = cloudinary.url(upload.public_id, {
 transformation: [
 { effect: "grayscale" },
 { quality: "auto" }
 ]
 });

 let result = await axios.get(editedUrl, {
 responseType: 'arraybuffer'
 });

 let finalBuffer = Buffer.from(result.data);

 await raiden.sendMessage(m.chat, {
 image: finalBuffer,
 caption: `╭─❏ STYLE ABU-ABU
│ ✅ Berhasil convert
╰──────────❏`
 }, { quoted: troli });

 await m.react('✅');

 } catch (err) {
 console.error(err);
 await m.react('❌');

 try {
 let buffer = await q.download();
 await raiden.sendMessage(m.chat, {
 image: buffer,
 caption: `❌ Error:\n${err.message}`
 }, { quoted: troli });
 } catch {
 Reply(`❌ ${safeErr(err)}`);
 }
 }
};

export default handler;
