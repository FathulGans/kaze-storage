import axios from 'axios';

const pluginConfig = {
  name: 'copilot',
  category: 'ai',
  command: ['copilot', 'bing'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

    if (!text) return Reply(`✈️ *MICROSOFT COPILOT AI*\n\nContoh: ${prefix + command} Jelaskan apa itu black hole`);

    const _copilotBlocklist = ['addowner', 'addprem', '.addowner', 'addown', 'addpremium', 'jadi owner', 'kasih akses', 'give owner'];
    if (_copilotBlocklist.some(w => text.toLowerCase().includes(w))) {
        await raiden.sendMessage(m.chat, { react: { text: '🚫', key: m.key } });
        return Reply('❌ *PERMINTAAN DITOLAK*\n\nInput tidak diizinkan oleh sistem keamanan.');
    }

    await raiden.sendMessage(m.chat, { react: { text: '✈️', key: m.key } });

    try {
        const { data } = await axios.get(`https://rynekoo-api.hf.space/text.gen/copilot?text=${encodeURIComponent(text)}`);
        if (!data.success || !data.result) {
            await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return Reply('❌ Copilot tidak dapat merespon saat ini. Coba lagi nanti.');
        }
        Reply(`✈️ *MICROSOFT COPILOT*\n\n${data.result.text}`);
        await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[copilot-error]', e.message);
        await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        Reply('❌ Server Copilot sedang sibuk atau down.');
    }
};

export default handler;
