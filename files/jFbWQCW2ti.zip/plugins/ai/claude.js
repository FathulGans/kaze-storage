import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'claude',
  category: 'ai',
  command: ['claude'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);

 if (!tierAkses.isPrem(m.sender) && !isVip)
 return Reply("🔒 Fitur ini khusus untuk member *premium*. Upgrade dulu ya buat bisa pakai fitur ini.");

 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);

 if (!text) {
 return Reply(example("Gimana cara fix bug dalam code?"))
 }

 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 const pesan = encodeURIComponent(text.trim());
 const apiUrl = `${global.apisynox}/ai-chat/claude-opus-4.8?pesan=${pesan}`;

 const response = await axios.get(apiUrl, { timeout: 60000 });
 const data = response.data;

 if (!data.status || !data.result || !data.result.reply) {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return Reply(mess.error)
 }

 const reply = data.result.reply;

 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(reply);

 } catch (error) {
 console.log('[CLAUDE ERROR]', error.response?.status, error.response?.data || error.message);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error)
 }
};

export default handler;
