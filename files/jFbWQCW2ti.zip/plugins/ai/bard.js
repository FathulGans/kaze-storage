import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'bard',
  category: 'ai',
  command: ['bard'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, text } = ctx;
if (!text) return Reply(`Contoh: ${prefix}${command} halo, siapa kamu?`);

if (!isRegistered(m.sender) && !isVip)
return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

try {
const encodedText = encodeURIComponent(text);
const apiUrl = `${global.termai}/api/chat/bard?query=${encodedText}&key=${global.apitermai}`;

const { data } = await axios.get(apiUrl, { timeout: 60000 });

const response = data.chatUi || data.result || 'Tidak ada respon';

const finalResponse = `🎀 ${global.botname}\n\n${response}`;

await Reply(finalResponse);
await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

} catch (error) {
await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
Reply('❌ Gagal memproses permintaan');
}
return;
};

export default handler;
