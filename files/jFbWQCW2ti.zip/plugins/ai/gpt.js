import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'gpt',
  category: 'ai',
  command: ['gpt'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);

 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);

 if (!text) return Reply(example("apa itu kecerdasan buatan?"));

 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 const response = await axios.get(`https://api-cloud.my.id/ai/gpt?text=${encodeURIComponent(text)}`, { timeout: 60000 });
 const r = response.data.result;
 const resultText = typeof r === "string" ? r : r && r.text;

 if (response.data.status && resultText) {
 await Reply(`🤖 *GPT*\n${resultText}`);
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } else {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply("❌ GPT tidak dapat menjawab pertanyaan tersebut.");
 }
 } catch (error) {
 console.error('[GPT ERROR]', error);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
};

export default handler;
