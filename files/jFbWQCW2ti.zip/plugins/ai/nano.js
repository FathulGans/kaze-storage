import __form_data from 'form-data';
import __fs from 'fs';
import axios from 'axios';
import os from 'os';
import path from 'path';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'nano',
  category: 'ai',
  command: ['nano', 'raidenedit2', 'raidenai'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi)
    if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(global.mess.prem)
    if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit)
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    if (!/image/.test(mime)) return Reply(`Kirim atau balas gambar dengan caption ${prefix + command} <prompt>`)
    if (!text) return Reply(`Contoh: ${prefix + command} Jadikan seperti anime`)
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })
    try {
        const { tmpdir } = os
        const { join, basename, extname } = path
        const fs = __fs
        const FormData = __form_data

        const genserial = () => {
            let s = ""
            for (let i = 0; i < 32; i++) s += Math.floor(Math.random() * 16).toString(16)
            return s
        }
        const nanoUpload = async (filename) => {
            const form = new FormData()
            form.append("file_name", filename)
            const res = await axios.post("https://api.imgupscaler.ai/api/common/upload/upload-image", form, {
                headers: { 
                    ...form.getHeaders(), 
                    origin: "https://imgupscaler.ai", 
                    referer: "https://imgupscaler.ai/" 
                }
            })
            return res.data.result
        }
        const nanoToOSS = async (putUrl, filePath) => {
            const file = fs.readFileSync(filePath)
            const type = extname(filePath) === ".png" ? "image/png" : "image/jpeg"
            const res = await axios.put(putUrl, file, {
                headers: { 
                    "Content-Type": type, 
                    "Content-Length": file.length 
                },
                maxBodyLength: Infinity
            })
            return res.status === 200
        }
        const nanoCreateJob = async (imageUrl, prompt) => {
            const form = new FormData()
            form.append("model_name", "magiceraser_v4")
            form.append("original_image_url", imageUrl)
            form.append("prompt", prompt)
            form.append("ratio", "match_input_image")
            form.append("output_format", "jpg")
            const res = await axios.post("https://api.magiceraser.org/api/magiceraser/v2/image-editor/create-job", form, {
                headers: { 
                    ...form.getHeaders(), 
                    "product-code": "magiceraser", 
                    "product-serial": genserial(), 
                    origin: "https://imgupscaler.ai", 
                    referer: "https://imgupscaler.ai/" 
                }
            })
            return res.data.result.job_id
        }
        const nanoCheck = async (jobId) => {
            const res = await axios.get(`https://api.magiceraser.org/api/magiceraser/v1/ai-remove/get-job/${jobId}`, {
                headers: { 
                    origin: "https://imgupscaler.ai", 
                    referer: "https://imgupscaler.ai/" 
                }
            })
            return res.data
        }
        let media = await q.download()
        const tmpInput = join(tmpdir(), `nano_${Date.now()}.jpg`)
        fs.writeFileSync(tmpInput, media)
        const filename = basename(tmpInput)
        const up = await nanoUpload(filename)
        await nanoToOSS(up.url, tmpInput)
        const cdn = "https://cdn.imgupscaler.ai/" + up.object_name
        const jobId = await nanoCreateJob(cdn, text)
        let result
        do {
            await new Promise((r) => setTimeout(r, 3000))
            result = await nanoCheck(jobId)
        } while (result.code === 300006)
        const resultUrl = result.result.output_url[0]
        fs.unlinkSync(tmpInput)
        await raiden.sendMessage(m.chat, { 
            image: { url: resultUrl }, 
            caption: `*${global.botname} EDITOR*\n\n*prompt:* ${text}` 
        }, { quoted: m })
        addLimit(m.sender, tierAkses.isPrem(m.sender), isVip)
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
    } catch (e) {
        console.error(e)
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        Reply(`❌ Error: ${e.message}`)
    }
};

export default handler;
