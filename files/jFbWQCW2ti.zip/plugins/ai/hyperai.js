import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'hyperai',
  category: 'ai',
  command: ['hyperai', 'webpilot', 'venice', 'powerbrain', 'publicai'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, safeErr, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    if (!text) return Reply(`📌 Contoh: ${prefix}${command} halo nama ku alip`);

    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        const encodedText = encodeURIComponent(text);
        let apiUrl = '';
        let aiName = '';
        let icon = '';

        if (command === 'hyperai') {
            apiUrl = `${global.apialip}/ai/hyperai?apikey=${global.apikeyalip}&prompt=${encodedText}`;
            aiName = 'HyperAI';
            icon = '⚡';
        } else if (command === 'webpilot') {
            apiUrl = `${global.apialip}/ai/webpilot?apikey=${global.apikeyalip}&prompt=${encodedText}`;
            aiName = 'WebPilot';
            icon = '🌐';
        } else if (command === 'venice') {
            apiUrl = `${global.apialip}/ai/venice?apikey=${global.apikeyalip}&prompt=${encodedText}`;
            aiName = 'VeniceAI';
            icon = '🎨';
        } else if (command === 'powerbrain') {
            apiUrl = `${global.apialip}/ai/powerbrain?apikey=${global.apikeyalip}&prompt=${encodedText}`;
            aiName = 'PowerBrain';
            icon = '🧠';
        } else if (command === 'publicai') {
            apiUrl = `${global.apialip}/ai/publicai?apikey=${global.apikeyalip}&prompt=${encodedText}`;
            aiName = 'PublicAI';
            icon = '💬';
        }

        const response = await axios.get(apiUrl, { timeout: 60000 });
        const data = response.data;

        if (!data.status || !data.result) {
            throw new Error('Gagal mendapatkan respon dari AI');
        }

        let finalResponse = `${icon} *${aiName}*\n\n${data.result}`;

        if (command === 'webpilot' && data.source && Array.isArray(data.source) && data.source.length > 0) {
            let sourcesText = '\n\n📰 *Sumber:*\n';
            data.source.slice(0, 3).forEach((source, i) => {
                if (source && source.title) {
                    sourcesText += `${i+1}. ${source.title}\n`;
                }
            });
            if (data.source.length > 3) {
                sourcesText += `   ...dan ${data.source.length - 3} sumber lainnya`;
            }
            finalResponse += sourcesText;
        }

        await Reply(finalResponse);
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (error) {
        console.error(`${command} Error:`, error.message);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(`❌ Gagal memproses ${command}: ${safeErr(error) || 'Coba lagi nanti'}`);
    }
    return;
};

export default handler;
