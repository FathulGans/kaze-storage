const pluginConfig = {
  name: 'listwaifu',
  category: 'ai',
  command: ['listwaifu', 'daftarwaifu', 'waifulist'],
};

const handler = async (m, ctx) => {
    let { daftar, isVip, prefix, raiden, troli } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
 
 const waifuListForDisplay = [
 { name: "Hatsune Miku", anime: "Vocalical" }, { name: "Rias Gremory", anime: "High School DxD" },
 { name: "Isuzu Sento", anime: "Amagi Brilliant Park" }, { name: "Shinka Nibutani", anime: "Chuunibyou" },
 { name: "Yumeko Jabami", anime: "Kakegurui" }, { name: "Tejina Senpai", anime: "Tejina Senpai" },
 { name: "Touka Kirishima", anime: "Tokyo Ghoul" }, { name: "Kurumi Tokisaki", anime: "Date A Live" },
 { name: "Sagiri Izumi", anime: "Eromanga Sensei" }, { name: "Asuna Yuuki", anime: "SAO" },
 { name: "Emilia", anime: "Re:Zero" }, { name: "Hestia", anime: "DanMachi" },
 { name: "Nezuko Kamado", anime: "Demon Slayer" }, { name: "Erza Scarlet", anime: "Fairy Tail" },
 { name: "Megumin", anime: "Konosuba" }, { name: "Zero Two", anime: "Darling in Franxx" }
 ];
 
 let teks = `╭─❏ *📋 DAFTAR WAIFU POPULER*
│
│ Total: ${waifuListForDisplay.length}+ Waifu
│
`;
 
 waifuListForDisplay.forEach((w, i) => {
 teks += `│ ${(i + 1).toString().padStart(2, '0')}. ${w.name}\n`;
 teks += `│ └ ${w.anime}\n`;
 });
 
 teks += `│
│ 💡 *Cara menggunakan:*
│ • ${prefix}waifu - Waifu populer random
│ • ${prefix}waifu next - Waifu berikutnya
│ • ${prefix}waifurandom - Gacha random
│
╰──────────❏
🌸 *${global.botname}* - Waifu Collection`;
 
 await raiden.sendMessage(m.chat, { text: teks }, { quoted: troli });
};

export default handler;
