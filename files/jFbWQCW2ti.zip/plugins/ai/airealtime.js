import { fetchJson } from '../../library/function.js';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'airealtime',
  category: 'ai',
  command: ['airealtime'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);

    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);

    if (!text) return Reply(`Contoh: ${prefix + command} jam berapa hari ini`);


    try {
await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const apiUrl = `https://api-faa.my.id/faa/ai-realtime?text=${encodeURIComponent(text)}`;
        const response = await fetchJson(apiUrl);

        if (response.status && response.result) {
            await Reply(response.result);
        } else {
            throw new Error('Gagal mendapatkan respons AI');
        }

    } catch (error) {
        console.error('AI Error:', error);
        Reply('Gagal memproses pertanyaan. Coba lagi nanti.');
    }
    return;
};

export default handler;
