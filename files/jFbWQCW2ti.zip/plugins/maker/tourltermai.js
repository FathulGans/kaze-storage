import FormData from 'form-data';
import axios from 'axios';

const pluginConfig = {
  name: 'tourltermai',
  category: 'maker',
  command: ['tourltermai'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, safeErr } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    try {
        const targetMsg = (m.quoted || m);
        const mimeType = (targetMsg.msg || targetMsg).mimetype || '';
        if (!mimeType) {
            return Reply(`❌ silakan kirim atau reply media (gambar, video, audio, sticker, atau dokumen) dengan caption *${prefix + command}*.\n\n📌 Contoh:\nkirim media, lalu tulis: *${prefix + command}*\nreply ke media, lalu ketik: *${prefix + command}*`);
        }
        const isAccepted = /image|video|audio|webp|application\/pdf|text|application\/vnd.openxmlformats-officedocument/.test(mimeType);
        if (!isAccepted) {
            return Reply(`❌ maaf, format file ini tidak didukung`);
        }        
        let mediaBuffer = await raiden.downloadMediaMessage(targetMsg);
        const MAX_LIMIT = 150 * 1024 * 1024;
        if (mediaBuffer.length > MAX_LIMIT) {
            if (/image/.test(mimeType) && !/webp/.test(mimeType)) {
                mediaBuffer = await (await import('sharp')).default(mediaBuffer).jpeg({ quality: 70 }).toBuffer();
            } else {
                return Reply("⚠️ file terlalu besar (maksimal 150MB). silakan kirim file lebih kecil");
            }
        }
        let extension = mimeType.split('/')[1] || 'bin';
        if (extension.includes('vnd.openxmlformats-officedocument')) {
            extension = 'docx';
        } else if (extension === 'plain') {
            extension = 'txt';
        } else if (extension === 'vnd.ms-excel') {
            extension = 'xls';
        }        
        const fileName = `file.${extension}`;
        const Form = FormData;        
        async function uploadFile(fileBuffer, fName) {
            const key = global.termaiUploadKey || "";
            const domain = "https://c.termai.cc";
            const formData = new Form();
            formData.append('file', fileBuffer, { filename: fName });
            const response = await axios.post(`${domain}/api/upload?key=${key}`, formData, {
                headers: {
                    ...formData.getHeaders()
                },
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            return response.data;
        }
        await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 2001) + 3000));
        const result = await uploadFile(mediaBuffer, fileName);        
        if (result && result.status) {
            Reply(`✅ berhasil diupload!\n\nURL: ${result.path}`);
        } else {
            Reply("❌ Gagal mengupload file ke server");
        }
    } catch (err) {
        Reply(`⚠️ error: ${err.response?.data?.message || safeErr(err) || err}`);
    }
};

export default handler;
