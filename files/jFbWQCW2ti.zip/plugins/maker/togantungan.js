import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'togantungan',
  category: 'maker',
  command: ['togantungan'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, prefix, raiden, text, uploadKappaFile } = ctx;
  if (!m.isGroup) return
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);

    if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);

    addLimit(m.sender, tierAkses.isPrem(m.sender), isVip, isVip);

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";

    if (!/image\//i.test(mime)) {
        return Reply(`❌ Reply ke *gambar* lalu ketik *${prefix}togantungan archio official*`);
    }

    const inputName = text?.trim();
    if (!inputName) {
        return Reply(`❌ Masukkan nama\nContoh: *${prefix}togantungan alip*`);
    }

    const userName = inputName.slice(0, 20);

    await m.reply("🔑🎨 Lagi bikin gantungan kunci versi kamu… sabar ya!");
    await raiden.sendMessage(m.chat, { react: { text: "✨", key: m.key } });

    const PROMPT_FIGURE = `
Create a close-up, ultra realistic product photo of a cute custom keychain.

ABSOLUTE RULES:
- The figure must be 100% based on the uploaded photo.
- The figure is a full-body chibi miniature of the person in the photo.
- Do NOT include Doraemon or any copyrighted character.

KEYCHAIN DESIGN:
- Full-body chibi figure using the user's face, hairstyle, and clothing.
- A blue heart-shaped charm with a tiny white flower.
- A blue name tag strap with the name "${userName}" clearly printed in white text.
- A square blue photo frame charm.

PHOTO FRAME REQUIREMENT:
- The square photo frame MUST display the SAME uploaded photo clearly.
- The photo must fully fill the frame (no green screen, no blank area).

The keychain is held in a human hand.
Soft pastel colors, cute and clean kawaii aesthetic.
Bright indoor store background with soft bokeh lights.
Shallow depth of field, realistic lighting, ultra high detail.
Commercial product photography, 4K resolution.
`;


    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar");

        const userImageUrl = await uploadKappaFile(userImageBuffer, mime || 'image/jpeg');
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_FIGURE)}`;

        const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
        const hasilBuffer = Buffer.from(response.data, "binary");

        await raiden.sendMessage(
            m.chat,
            {
                image: hasilBuffer,
                caption: `*Done 🔑✨ Gantungan kunci "${userName}" siap!*`
            },
            { quoted: m }
        );
    } catch (e) {
        await Reply("❌ Error: " + e.message);
    } finally {
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    }
};

export default handler;
