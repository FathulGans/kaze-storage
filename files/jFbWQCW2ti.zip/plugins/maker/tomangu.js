import __axios from 'axios';
import __form_data from 'form-data';
import __https from 'https';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tomangu',
  category: 'maker',
  command: ['tomangu'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, text } = ctx;
    if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
    
    const axios = __axios;
    const FormData = __form_data;
    const Jimp = (await import('jimp')).default;
    const fakeUserAgent = (await import('fake-useragent')).default;
    const https = __https;

    const agent = new https.Agent({
        rejectUnauthorized: false
    });

    if (!global.tomanguSessions) global.tomanguSessions = {};

    const agamaList = ['islam', 'kristen', 'hindu', 'budha', 'konghucu'];
    const agamaMap = {
        'islam': { symbol: '☪️', name: 'Islam' },
        'kristen': { symbol: '✝️', name: 'Kristen' },
        'hindu': { symbol: '🕉️', name: 'Hindu' },
        'budha': { symbol: '☸️', name: 'Budha' },
        'konghucu': { symbol: '⚛️', name: 'Konghucu' }
    };

    const PROMPT = `Create an ultra-realistic, emotionally powerful cinematic photograph of two people deeply in love but separated by their different religious backgrounds.

**CRITICAL: DO NOT change the faces, hair, or clothing of either person. Keep everything EXACTLY as in the original images.**

The two people should be positioned slightly apart, facing each other with intense eye contact, their hands almost touching but not quite.

Add subtle floating religious symbols:
- For Person 1: @agama1_symbol (@agama1_name)
- For Person 2: @agama2_symbol (@agama2_name)

The symbols should glow softly, floating between them, gently facing away from each other - symbolizing love that transcends but is constrained by belief.

Setting: Misty field at golden hour, warm melancholic lighting, dreamy haze. Intimate, sacred, heartbreakingly beautiful atmosphere.

Cinematic, high resolution, photorealistic, emotional depth, masterpiece photography.`;

    async function uploadUguu(buffer, filename = "file.jpg") {
        const form = new FormData();
        form.append("files[]", buffer, { filename, contentType: "application/octet-stream" });
        const { data } = await axios.post("https://uguu.se/upload.php", form, {
            headers: { ...form.getHeaders(), "User-Agent": fakeUserAgent() },
            httpsAgent: agent,
            maxBodyLength: Infinity,
            timeout: 60000
        });
        const url = data?.files?.[0]?.url;
        if (!url) throw new Error("Upload ke Uguu gagal");
        return url;
    }

    async function mergePhotos(buf1, buf2) {
        const img1 = await Jimp.read(buf1);
        const img2 = await Jimp.read(buf2);
        const size = 700;
        img1.cover(size, size);
        img2.cover(size, size);
        const gap = 40;
        const canvas = new Jimp(size * 2 + gap, size, 0xffffffff);
        canvas.composite(img1, 0, 0);
        canvas.composite(img2, size + gap, 0);
        return await canvas.getBufferAsync(Jimp.MIME_JPEG);
    }

    const key = `${m.chat}:${m.sender}`;
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    const agama = text.trim().toLowerCase();

    if (!agamaList.includes(agama)) {
return Reply(
    `
╭─❏ Tomangu
│✧ 1. Reply foto 1 dgn .tomangu islam
│✧ 2. Reply foto 2 dgn .tomangu kristen
╰──────────❏

Agama tersedia:
${agamaList.map(a => `│✧ • ${a} ${agamaMap[a].symbol}`).join('\n')}
╰──────────❏

Contoh: .tomangu islam (reply foto 1)
         .tomangu kristen (reply foto 2)`
)
    }

    if (!/image\//i.test(mime)) {
        return Reply('❌ Reply ke gambar!')
    }

    if (!global.tomanguSessions[key]) {
        const buf = await q.download();
        if (!buf) return Reply('❌ Gagal download gambar');
        
        global.tomanguSessions[key] = {
            foto1: buf,
            agama1: agama,
            foto1Id: m.quoted ? m.quoted.id : m.id
        };
        
        return Reply(
    `╭─❏ Tomangu
│✧ Agama : ${agamaMap[agama].name} ${agamaMap[agama].symbol}
╰──────────❏

Sekarang reply foto kedua dengan .tomangu [agama]`
)
        
    } else {
        const sess = global.tomanguSessions[key];
        
        if (sess.foto2) {
            return Reply('❌ Sesi sudah lengkap, tunggu hasilnya');
        }
        
        if (sess.agama1 === agama) {
            return Reply('❌ Agama harus berbeda!');
        }
        
        const buf2 = await q.download();
        if (!buf2) return Reply('❌ Gagal download gambar kedua');
        
        sess.foto2 = buf2;
        sess.agama2 = agama;
        
        try {
            await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
            
            const merged = await mergePhotos(sess.foto1, sess.foto2);
            const mergedUrl = await uploadUguu(merged, "merged.jpg");
            
            const customPrompt = PROMPT
                .replace('@agama1_symbol', agamaMap[sess.agama1].symbol)
                .replace('@agama1_name', agamaMap[sess.agama1].name)
                .replace('@agama2_symbol', agamaMap[sess.agama2].symbol)
                .replace('@agama2_name', agamaMap[sess.agama2].name);
            
            const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(mergedUrl)}&prompt=${encodeURIComponent(customPrompt)}`;
            
            const response = await axios.get(apiUrl, { 
                responseType: "arraybuffer",
                timeout: 90000
            });
            
            const hasilBuffer = Buffer.from(response.data, "binary");
            
            await raiden.sendMessage(m.chat, { 
    image: hasilBuffer, 
    caption: `╭─❏ Tomangu
│✧ Person 1 : ${agamaMap[sess.agama1].name} ${agamaMap[sess.agama1].symbol}
│✧ Person 2 : ${agamaMap[sess.agama2].name} ${agamaMap[sess.agama2].symbol}
╰──────────❏`
}, { quoted: m });
            
            await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

        } catch (e) {
            console.error('[TOMANGU ERROR]', e);
            await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
            Reply(`❌ Gagal: ${e.message || 'Unknown error'}`);
        } finally {
            delete global.tomanguSessions[key];
        }
    }
};

export default handler;
