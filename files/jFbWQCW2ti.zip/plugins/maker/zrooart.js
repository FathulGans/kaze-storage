import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'zrooart',
  category: 'maker',
  command: ['zrooart'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, q, raiden } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


  const fetch = (await import('node-fetch')).default;
  const FormData = (await import('form-data')).default;
  const input = q ? q.split('|').map(v => v.trim()) : [];
  const prompt = input[0];
  let style = input[1] || 'Fantasy Art';
  let aspect = input[2] || '16:9';

  const styleList = [
    'None', '3D Model', 'Analog Film', 'Anime', 'Cinematic', 'Comic Book',
    'Digital Art', 'Enhance', 'Fantasy Art', 'Isometric', 'Line Art',
    'Low Poly', 'Modeling Compound', 'Neon Punk', 'Origami',
    'Photographic', 'Pixel Art', 'Tile Texture'
  ];

  const ratioList = [
    '16:9', '1:1', '9:16', '4:5', '5:4', '2:3', '3:2', '21:9', '9:21'
  ];

  if (!prompt) {
    return Reply(`*Format:*
.zrooart <prompt> | <style?> | <ratio?>

*Contoh:*
.zrooart naga api | Anime | 9:16
.zrooart kota masa depan | random | random

*Style yang tersedia:*
${styleList.join(', ')}

*Rasio yang tersedia:*
${ratioList.join(', ')}`);
  }

  if (style.toLowerCase() === 'random') {
    style = styleList[Math.floor(Math.random() * styleList.length)];
  }

  if (aspect.toLowerCase() === 'random') {
    aspect = ratioList[Math.floor(Math.random() * ratioList.length)];
  }

  const form = new FormData();
  form.append('video_description', prompt);
  form.append('test_mode', 'false');
  form.append('negative_prompt', 'blurry, distorted, bad quality');
  form.append('aspect_ratio', aspect);
  form.append('style', style);
  form.append('output_format', 'png');
  form.append('seed', '0');

  Reply(`⏳ Membuat gambar dari prompt:\n*${prompt}*\nStyle: *${style}*\nRasio: *${aspect}*`);

  try {
    const res = await fetch('https://aiart-zroo.onrender.com/generate', {
      method: 'POST',
      headers: { accept: '*/*' },
      body: form
    });

    const json = await res.json();

    if (!json.success || !json.image_path)
      return Reply('❌ Gagal membuat gambar:\n' + JSON.stringify(json, null, 2));

    const finalURL = `https://aiart-zroo.onrender.com${json.image_path}?t=${Date.now()}`;

    await raiden.sendMessage(m.chat, {
      image: { url: finalURL },
      caption: `✅ Gambar berhasil dibuat dari:\n*${prompt}*\nStyle: *${style}*\nRasio: *${aspect}*`
    }, { quoted: m });

  } catch (e) {
    Reply('❌ Terjadi error:\n' + e.message);
  }
};

export default handler;
