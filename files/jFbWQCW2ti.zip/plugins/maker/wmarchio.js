import __axios from 'axios';
import __baileys from '../../src/lib/baileys-compat.js';
import __fs from 'fs';

const pluginConfig = {
  name: 'wmarchio',
  category: 'maker',
  command: ['wmarchio'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden, troli } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 const { generateWAMessageFromContent, proto } = __baileys;
 const axios = __axios;
 const sharp = (await import('sharp')).default;
 const fs = __fs;

 const WM_URL = 'https://raw.githubusercontent.com/zionjs0/Togithub/main/uploads/1776948583539_1776948583538.jpg';

 try {
 let q = m.quoted ? m.quoted : m;
 let type = q.mtype || Object.keys(q.message || {})[0];

 if (type !== 'imageMessage') {
 return Reply('❌ Kirim atau reply gambar!');
 }

 await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

 let media = await raiden.downloadAndSaveMediaMessage(q);

 let buffer;
 if (Buffer.isBuffer(media)) buffer = media;
 else if (typeof media === 'string') buffer = fs.readFileSync(media);
 else if (media?.buffer) buffer = media.buffer;
 else throw 'Format media tidak dikenali';

 if (!buffer || buffer.length < 1000) {
 throw 'Buffer kosong';
 }

 const wmRes = await axios.get(WM_URL, {
 responseType: 'arraybuffer'
 });
 const wmBuffer = Buffer.from(wmRes.data);

 const image = sharp(buffer);
 const meta = await image.metadata();

 const width = meta.width;

 const wmSize = Math.floor(width * 0.8);

 const cleanWM = await sharp(wmBuffer)
 .resize(wmSize)
 .modulate({
 brightness: 1.2,
 saturation: 1.3
 })
 .sharpen()
 .png()
 .toBuffer();

 const posX = Math.floor((width - wmSize) / 2);
 const wmMeta = await sharp(cleanWM).metadata();
 const posY = Math.floor((meta.height - wmMeta.height) / 2);

 const result = await image
 .composite([{
 input: cleanWM,
 top: posY,
 left: posX,
 blend: 'over',
 opacity: 1
 }])
 .jpeg({
 quality: 100,
 chromaSubsampling: '4:4:4'
 })
 .toBuffer();

 await raiden.sendMessage(m.chat, {
 image: result,
 caption: 'Done cuy. Nih wm bang archio😋'
 }, { quoted: troli });

 await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 if (typeof media === 'string' && fs.existsSync(media)) {
 fs.unlinkSync(media);
 }
 } catch (err) {
 console.error('[WMARCHIO ERROR]', err);

 await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });

 if (err.message?.includes('timeout')) {
 return Reply('❌ Timeout, coba lagi');
 }

 Reply(`❌ Error:\n${err}`);
 }
 return;
};

export default handler;
