import axios from 'axios';
import { uploadCatbox, uploadKappaFile, uploadQu, uploadUguu } from '../tools/uploader.js';

const pluginConfig = {
  name: 'fakecallimage',
  category: 'maker',
};

async function generateFakeCallImage(buffer, mimeType, nama, durasi, apiEndpoint) {
    const generateFilename = (mimeType) => {
        const extMap = {
            'image/jpeg': 'jpg', 'image/jpg': 'jpg',
            'image/png': 'png', 'image/webp': 'webp'
        }
        const ext = extMap[mimeType] || 'jpg'
        return 'raiden-' + Date.now() + '-' + Math.floor(Math.random() * 9999) + '.' + ext
    }
    const isValidUrl = (u) => typeof u === 'string' && /^https?:\/\//.test(u.trim())
    const delay = (ms) => new Promise(res => setTimeout(res, ms))

    function isValidImageBuffer(buf) {
        if (!buf || buf.length < 100) return false
        const hex = buf.slice(0, 4).toString('hex')
        return (
            hex.startsWith('ffd8') ||
            hex.startsWith('89504e47') ||
            buf.slice(0, 4).toString('ascii') === 'RIFF'
        )
    }
    if (!isValidImageBuffer(buffer)) {
        throw new Error('File yang di-reply bukan gambar valid atau corrupt')
    }

    const uploaders = [
        { name: 'Kappa', fn: () => uploadKappaFile(buffer, mimeType, generateFilename) },
        { name: 'Catbox', fn: () => uploadCatbox(buffer, mimeType, generateFilename) },
        { name: 'Qu.ax', fn: () => uploadQu(buffer, mimeType, generateFilename) },
        { name: 'Uguu', fn: () => uploadUguu(buffer, mimeType, generateFilename) },
    ]

    const apikey = global.apikeybetabotz || global.apikeybetabotzCadangan
    let lastError = null

    async function tryOneHost(uploader) {
        let imgUrl = null
        try {
            imgUrl = await uploader.fn()
        } catch (e) {
            throw new Error(`Upload ${uploader.name} gagal: ${e?.message || e}`)
        }
        if (!isValidUrl(imgUrl)) {
            throw new Error(`Upload ${uploader.name} tidak menghasilkan URL valid`)
        }
        imgUrl = imgUrl.trim()

        const apiUrl = `${apiEndpoint}?apikey=${apikey}&durasi=${encodeURIComponent(durasi)}&nama=${encodeURIComponent(nama)}&url=${encodeURIComponent(imgUrl)}`
        const res = await axios.get(apiUrl, { timeout: 25000, responseType: 'arraybuffer', validateStatus: () => true })
        const contentType = res.headers['content-type'] || ''

        let resultBuffer
        if (contentType.includes('application/json')) {
            const json = JSON.parse(Buffer.from(res.data).toString('utf-8'))
            const resultUrl = json?.result?.url || json?.result || json?.url || null
            if (!resultUrl || typeof resultUrl !== 'string') {
                throw new Error(`API menolak (host: ${uploader.name}): ${json?.message || JSON.stringify(json).substring(0, 150)}`)
            }
            const imgRes = await axios.get(resultUrl, { responseType: 'arraybuffer', timeout: 15000 })
            resultBuffer = Buffer.from(imgRes.data)
        } else {
            resultBuffer = Buffer.from(res.data)
        }

        if (!resultBuffer || resultBuffer.length < 500) {
            const asText = resultBuffer ? resultBuffer.toString('utf-8').substring(0, 150) : ''
            throw new Error(`Response tidak valid (host: ${uploader.name}): ${asText || 'buffer kosong'}`)
        }

        return resultBuffer
    }

    for (let round = 1; round <= 2; round++) {
        for (const uploader of uploaders) {
            try {
                const result = await tryOneHost(uploader)
                return result
            } catch (e) {
                lastError = e
                console.error(`[generateFakeCallImage] Round ${round} - ${uploader.name} gagal:`, e?.message || e)
                await delay(800)
                continue
            }
        }
        if (round === 1) {
            console.error('[generateFakeCallImage] Putaran 1 gagal total, coba putaran 2 setelah jeda...')
            await delay(2000)
        }
    }

    throw new Error(lastError?.message || 'Semua percobaan gagal (hosting foto & API tidak merespons dengan benar)')
}

export { generateFakeCallImage };

export default { modulPendukung: true };
