const pluginConfig = {
  name: 'totagpilih',
  category: 'maker',
  command: ['totagpilih'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, raiden } = ctx;
 if (!isVip) return Reply(mess.vip || '⚠️ Fitur ini hanya untuk owner!');

 const targetGcTotag = args[0];
 if (!targetGcTotag) return Reply('❌ Grup tujuan tidak valid.');

 const cachedQuotedTotag = global.totagCache?.[m.sender];
 if (!cachedQuotedTotag) return Reply('⌛ Sesi totag expired. Reply pesan lagi lalu ketik .totag ulang.');

 try {
 const metaTotag = await raiden.groupMetadata(targetGcTotag);
 const membersTotag = metaTotag.participants.map(p => p.id);

 await raiden.sendMessage(targetGcTotag, { forward: cachedQuotedTotag, force: true });

 const tagTextTotag = membersTotag.map(j => `@${j.split('@')[0]}`).join(' ');
 await raiden.sendMessage(targetGcTotag, {
 text: `📢 Pesan dari admin:\n\n${tagTextTotag}`,
 mentions: membersTotag
 });

 Reply(`✅ Berhasil diteruskan + tag semua member ke grup *${metaTotag.subject}* (${membersTotag.length} member).`);
 } catch (e) {
 console.log('Error totagpilih:', e);
 Reply('❌ Gagal mengirim ke grup tersebut, kemungkinan bot sudah dikeluarkan.');
 }

 delete global.totagCache[m.sender];
};

export default handler;
