import __child_process from 'child_process';
import __fs from 'fs';
import axios from 'axios';
import os from 'os';
import path from 'path';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'bratvid2',
  category: 'maker',
  command: ['bratvid2', 'bratvideo2'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);
 if (!text) 
 return m.reply('🤦🏻‍♀️ contoh penggunaan: .bratvid kapan dapat makanan gratis nya');
 
 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 
 try {
 const { join } = path;
 const { tmpdir } = os;
 const { spawn } = __child_process;
 const fs = __fs;
 
 const encodedText = encodeURIComponent(text);
 const apiUrl = `https://api-cloud.my.id/maker/bratvideo?text=${encodedText}`;
 
 const res = await axios.get(apiUrl);
 
 if (!res.data.status || !res.data.result) {
 await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 return Reply('❌ Gagal membuat brat video.');
 }

 const base64Data = res.data.result.split(',')[1] || res.data.result;
 
 const videoBuffer = Buffer.from(base64Data, 'base64');
 
 const tmpMp4 = join(tmpdir(), `brat-${Date.now()}.mp4`);
 const tmpWebp = join(tmpdir(), `brat-${Date.now()}.webp`);
 
 fs.writeFileSync(tmpMp4, videoBuffer);
 
 await new Promise((resolve, reject) => {
 const ffmpeg = spawn('ffmpeg', [
 '-i', tmpMp4,
 '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,fps=15',
 '-loop', '0',
 '-an',
 '-vsync', '0',
 '-s', '512x512',
 '-f', 'webp',
 tmpWebp
 ]);
 ffmpeg.on('close', code => code === 0 ? resolve() : reject(new Error('FFmpeg failed with code ' + code)));
 });
 
 let stickerBuffer = fs.readFileSync(tmpWebp);
 
 try {
 const { Sticker } = (await import('wa-sticker-formatter')).default;
 const sticker = new Sticker(stickerBuffer, {
 pack: global.packname,
 author: global.author,
 type: 'full',
 quality: 100
 });
 stickerBuffer = await sticker.toBuffer();
 } catch (e) {
 console.error('Gagal menambahkan watermark sticker animasi:', e);
 }
 
 await raiden.sendMessage(m.chat, {
 sticker: stickerBuffer,
 contextInfo: {
 isForwarded: true,
 forwardingScore: 999,
 forwardedNewsletterMessageInfo: {
 newsletterJid: global.idSaluran,
 newsletterName: global.namaSaluran,
 serverMessageId: -1
 }
 }
 }, { quoted: m });
 
 await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 
 fs.unlinkSync(tmpMp4);
 fs.unlinkSync(tmpWebp);
 } catch (err) {
 console.error("Sticker Animasi Error:", err);
 m.reply('❌ gagal bikin sticker animasi. Coba lagi besok');
 }
};

export default handler;
