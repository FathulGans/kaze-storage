import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'putihkan',
  category: 'maker',
  command: ['putihkan'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, raiden, uploadKappaFile } = ctx;
if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    if (!/image\//i.test(mime)) {
        return Reply(`❌ Reply ke *gambar* atau kirim gambar dengan caption *${prefix}putihkan*`);
    }
await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });

    const PROMPT_PUTIHKAN = `
    Brighten and smoothen the skin tone of the person in the image naturally, 
    giving a clean, glowing, and healthy white appearance. 
    Keep the original facial features, structure, and expression unchanged. 
    Make the skin look evenly toned and radiant under soft lighting, 
    without making it look artificial or overexposed. 
    Maintain a realistic photographic quality with balanced contrast and warmth.
    `;


    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime || 'image/jpeg');     
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_PUTIHKAN)}`;
const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
const hasilBuffer = Buffer.from(response.data, "binary");

await raiden.sendMessage(
    m.chat,
    { image: hasilBuffer, caption: mess.done },
    { quoted: m }
);

    } catch (e) {
        await Reply("❌ Error: " + e.message);
    } finally {
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    }
};

export default handler;
