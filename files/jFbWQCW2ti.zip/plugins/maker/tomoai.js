import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tomoai',
  category: 'maker',
  command: ['tomoai', 'tomonyet', 'topacar', 'tosatan'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, downloadContentFromMessage, isVip, raiden, uploadKappaFile } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);

    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);


    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!/^image\//.test(mime)) {
        return Reply('Reply atau kirim gambar!');
    }

    try {
await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        let buffer;
        if (q.download) {
            buffer = await q.download();
        } else if (m.message?.imageMessage) {
            const mediaBuffer = await downloadContentFromMessage(m.message, 'image');
            let chunks = [];
            for await (const chunk of mediaBuffer) {
                chunks.push(chunk);
            }
            buffer = Buffer.concat(chunks);
        } else {
            return Reply('Gagal mendapatkan gambar!');
        }

        const pixhostUrl = await uploadKappaFile(buffer, `${command}-${Date.now()}.jpg`);
        
        if (!pixhostUrl) {
            return Reply('Gagal upload gambar ke Pixhost!');
        }

        const encodedUrl = encodeURIComponent(pixhostUrl);
        const apiUrl = `https://api-faa.my.id/faa/${command}?url=${encodedUrl}`;

        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        const resultBuffer = Buffer.from(response.data, 'binary');

        await raiden.sendMessage(
            m.chat,
            { image: resultBuffer, caption: mess.done },
            { quoted: m }
        );

    } catch (e) {
        console.error(`${command} Error:`, e);
        Reply('❌ Gagal memproses gambar!');
    }
    return;
};

export default handler;
