import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'toalbino',
  category: 'maker',
  command: ['toalbino', 'albinokan'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, prefix, raiden, uploadKappaFile } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    if (!/image\//i.test(mime)) {
        return Reply(`❌ Reply ke *gambar* atau kirim gambar dengan caption *${prefix}toalbino*`);
    }
    m.reply("❄️ Sedang mengubah tampilan menjadi albino secara realistis... Mohon tunggu sebentar!");
    await raiden.sendMessage(m.chat, { react: { text: "🪄", key: m.key } });
    const PROMPT_ALBINO = `Realistic albino transformation. Change only the color: make the skin very pale, and the hair, eyebrows, and eyelashes must be the exact same color, namely natural white or platinum blonde. Maintain all facial features, expressions, and original skin texture without any modification. Do not increase the thickness or length of eyelashes and eyebrows; keep them natural and identical to the original photo. For eyelashes and eyebrows, use the original style or texture, do not change anything.`;
    
    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        
        const genName = (mType) => {
            const ext = mType.split('/')[1] || 'jpg';
            return `toalbino_${Date.now()}.${ext}`;
        };
        
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime, genName);     
        if (!userImageUrl) throw new Error("Gagal upload gambar ke server");
        
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_ALBINO)}`;
        const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
        const hasilBuffer = Buffer.from(response.data, "binary");
        await raiden.sendMessage(
            m.chat,
            { image: hasilBuffer, caption: `*Done Albino Version! ✨*` },
            { quoted: m }
        );
    } catch (e) {
        await Reply("❌ Error: " + e.message);
    } finally {
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    }
};

export default handler;
