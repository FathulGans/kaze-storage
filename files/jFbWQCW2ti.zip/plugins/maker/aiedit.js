import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'aiedit',
  category: 'maker',
  command: ['aiedit'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden, uploadKappaFile } = ctx;
    if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    const teks = q.text?.split(' ').slice(1).join(' ') || m.text?.split(' ').slice(1).join(' ');
    
    if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));
    
    if (!teks) return Reply(example("ubah jadi anime"));
    
    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });
    
    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        
        const genName = (mType) => {
            const ext = (mType || '').split('/')[1] || 'jpg';
            return `aiedit_${Date.now()}.${ext}`;
        };
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime, genName);
        if (!userImageUrl) throw new Error("Gagal upload gambar ke server");
        
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(teks)}`;
        
        const response = await axios.get(apiUrl, { 
            responseType: "arraybuffer",
            timeout: 180000
        });
        
        const hasilBuffer = Buffer.from(response.data, "binary");
        
        await raiden.sendMessage(m.chat, {
            image: hasilBuffer,
            caption: mess.done
        }, { quoted: m });
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error('[AIEDIT ERROR]', e);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;
