import __fs from 'fs';
import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'toblonde',
  category: 'maker',
  command: ['toblonde'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, raiden } = ctx;
if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 if (!/image\//i.test(mime)) {
 return Reply(`❌ Reply ke *gambar* atau kirim gambar dengan caption *${prefix}toblonde*`);
 }
 Reply("Tunggu bentar ya!");
 await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });

 const PROMPT_BLONDE = `
 Change only the hair color of the person in the image to blonde, 
 keeping everything else exactly the same — same pose, same facial structure, 
 same expression, same skin tone, same clothing, same background, same lighting. 
 Do not change hairstyle, length, or texture, only the color to a natural-looking blonde. 
 Maintain photo realism as if it's an actual picture of the same person with blonde hair.
 `;

 async function uploadPixhost(buffer, filename = "file.jpg") {
 const fs = __fs;
 const { ImageUploadService } = (await import('node-upload-images')).default;
 const service = new ImageUploadService('pixhost.to');
 const upload = await service.uploadFromBinary(buffer, filename);
 return upload.directLink;
 }

 try {
 const userImageBuffer = await q.download();
 if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
 const userImageUrl = await uploadPixhost(userImageBuffer); 
 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_BLONDE)}`;
const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
const hasilBuffer = Buffer.from(response.data, "binary");

await raiden.sendMessage(
 m.chat,
 { image: hasilBuffer, caption: `*done bosku*` },
 { quoted: m }
);

 } catch (e) {
 await Reply("❌ Error: " + e.message);
 } finally {
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 }
};

export default handler;
