import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tofigure',
  category: 'maker',
  command: ['tofigure'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden, uploadKappaFile } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return Reply(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    
    if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));
    
    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });
    
    const PROMPT_FIGURE = `Using the nano-banana model, a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment. The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base. The computer screen shows the Zbrush modeling process of the figurine. Next to the computer screen is a BANDAI-style toy box with the original painting printed on it.`;

    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        
        const genName = (mType) => {
            const ext = (mType || '').split('/')[1] || 'jpg';
            return `figure_${Date.now()}.${ext}`;
        };
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime, genName);
        if (!userImageUrl) throw new Error("Gagal upload gambar ke server");
        
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_FIGURE)}`;
        
        const response = await axios.get(apiUrl, { 
            responseType: "arraybuffer",
            timeout: 180000
        });
        
        const hasilBuffer = Buffer.from(response.data, "binary");
        
        await raiden.sendMessage(m.chat, { 
            image: hasilBuffer, 
            caption: mess.done
        }, { quoted: m });
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error('[TOFIGURE ERROR]', e);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;
