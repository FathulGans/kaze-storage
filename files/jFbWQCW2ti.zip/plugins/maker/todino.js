import __form_data from 'form-data';
import axios from 'axios';
import fetch from 'node-fetch';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'todino',
  category: 'maker',
  command: ['todino'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden } = ctx;
    if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    
    if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));
    
    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });
    
    const PROMPT_DINO = `
    Create a picture taken with a polaroid camera. 
    Make it look like a 3-grid photobooth composition. 
    The photo should appear natural and casual, without any strong props or clear subject focus. 
    Add a soft blur and consistent lighting effect, resembling a flash in a dark room.
    Do not alter the face of the person in the original image.
    Replace the background with a white curtain. 
    In the photo, the girl should be gently holding the yellow dinosaur's cheek, 
    and the yellow dinosaur should be holding the girl's head affectionately. 
    Add another cute and playful pose in one of the frames to complete the photobooth style.
    The overall aesthetic should look authentic, warm, and slightly vintage, like a real polaroid photo.
    `;

    try {
        async function uploadUguu(buffer, filename = "file.jpg") {
            const FormData = __form_data;
            const form = new FormData();
            form.append("files[]", buffer, { filename });
            const res = await fetch("https://uguu.se/upload.php", { method: "POST", body: form });
            if (!res.ok) throw new Error(`Upload gagal: ${res.status}`);
            const json = await res.json();
            const url = json?.files?.[0]?.url;
            if (!url) throw new Error("Gagal mendapatkan URL dari Uguu");
            return url;
        }

        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        
        const userImageUrl = await uploadUguu(userImageBuffer);
        if (!userImageUrl) throw new Error("Gagal upload gambar ke server");
        
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_DINO)}`;
        
        const response = await axios.get(apiUrl, { 
            responseType: "arraybuffer",
            timeout: 60000
        });
        
        const hasilBuffer = Buffer.from(response.data, "binary");
        
        await raiden.sendMessage(m.chat, { 
            image: hasilBuffer, 
            caption: mess.done
        }, { quoted: m });
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error('[TODINO ERROR]', e);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;
