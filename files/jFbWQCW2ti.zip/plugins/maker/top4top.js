import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'top4top',
  category: 'maker',
  command: ['top4top'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, safeErr, uploadTop4Top } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    
    if (!/image|video|audio|document/.test(mime)) {
        return Reply(`╭─❏ *Top4Top Uploader*
│✧ Format : Reply media dengan caption .top4top
│✧ Support : Gambar, Video, Audio, File
╰──────────❏`);
    }
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    try {
        const buffer = await q.download();
        if (!buffer) throw new Error('Gagal download media');
        
        const generateFilename = (mimeType) => {
            const ext = mimeType.split('/')[1] || 'bin';
            return `archio-${Date.now()}.${ext}`;
        };
        
        const result = await uploadTop4Top(buffer, mime, generateFilename);
        
        if (!result || !result.downloadUrl) {
            throw new Error('Upload gagal');
        }
        
        await Reply(result.downloadUrl);
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[TOP4TOP ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(`╭─❏ *Top4Top Uploader* - Gagal\n│✧ Error : ${safeErr(error)}\n╰──────────❏`);
    }
    return;
};

export default handler;
