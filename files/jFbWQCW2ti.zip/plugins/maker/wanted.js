import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'wanted',
  category: 'maker',
  command: ['wanted', 'buronan', 'posterwanted'],
};

const handler = async (m, konteksInti) => {
    let { Reply, command, daftar, downloadContentFromMessage, isVip, prefix, raiden, text } = konteksInti;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    if (!text) return Reply(`Format salah!\n\nContoh: ${prefix + command} Raiden`);
    if (!m.quoted) return Reply('Reply foto target buronan terlebih dahulu!');

    const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
    if (!quotedMsg.imageMessage) return Reply('Reply foto target buronan terlebih dahulu!');

    const namaTarget = text.trim().toUpperCase();

    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        const stream = await downloadContentFromMessage(quotedMsg.imageMessage, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        const targetBuffer = buffer;

        const { createCanvas, loadImage } = (await import('canvas')).default;
        const targetImg = await loadImage(targetBuffer);

        const W = 800;
        const H = 1150;
        const canvas = createCanvas(W, H);
        const ctx = canvas.getContext('2d');

        ctx.fillStyle = '#3a2312';
        ctx.fillRect(0, 0, W, H);
        
        ctx.strokeStyle = 'rgba(20, 10, 5, 0.4)';
        for (let i = 0; i < H; i += 15) {
            ctx.lineWidth = Math.random() * 4 + 1;
            ctx.beginPath();
            ctx.moveTo(0, i + Math.random() * 20);
            ctx.bezierCurveTo(W / 3, i - 10, 2 * W / 3, i + 30, W, i + Math.random() * 20);
            ctx.stroke();
        }

        const pW = 680;
        const pH = 1010;
        const pX = (W - pW) / 2;
        const pY = 70;

        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
        ctx.shadowBlur = 30;
        ctx.shadowOffsetY = 15;
        ctx.fillStyle = '#000000';
        ctx.fillRect(pX, pY, pW, pH);
        ctx.restore();

        ctx.fillStyle = '#decaa6';
        ctx.fillRect(pX, pY, pW, pH);

        ctx.fillStyle = 'rgba(139, 105, 76, 0.15)';
        for (let i = 0; i < 40; i++) {
            ctx.beginPath();
            ctx.arc(pX + Math.random() * pW, pY + Math.random() * pH, Math.random() * 80 + 20, 0, Math.PI * 2);
            ctx.fill();
        }

        ctx.strokeStyle = '#5c4027';
        ctx.lineWidth = 4;
        ctx.strokeRect(pX + 25, pY + 25, pW - 50, pH - 50);

        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';

        ctx.fillStyle = '#2c1a0c';
        ctx.font = 'bold 100px "Courier New", Courier, monospace';
        ctx.fillText('WANTED', W / 2, pY + 50);

        ctx.font = 'bold 36px "Courier New", Courier, monospace';
        ctx.fillText('DEAD OR ALIVE', W / 2, pY + 160);

        ctx.font = 'bold 42px "Courier New", Courier, monospace';
        ctx.fillText('REWARD $50,000', W / 2, pY + 215);

        const imgW = 460;
        const imgH = 460;
        const imgX = (W - imgW) / 2;
        const imgY = pY + 290;

        ctx.fillStyle = '#2c1a0c';
        ctx.fillRect(imgX - 8, imgY - 8, imgW + 16, imgH + 16);

        ctx.save();
        ctx.filter = 'grayscale(1) brightness(0.9) contrast(1.2)';
        ctx.drawImage(targetImg, imgX, imgY, imgW, imgH);
        ctx.restore();

        ctx.strokeStyle = 'rgba(222, 202, 166, 0.4)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(imgX + 20, imgY + 40); ctx.lineTo(imgX + 150, imgY + 200);
        ctx.moveTo(imgX + imgW - 40, imgY + 30); ctx.lineTo(imgX + imgW - 120, imgY + 130);
        ctx.stroke();

        ctx.fillStyle = '#2c1a0c';
        ctx.font = 'bold 75px "Courier New", Courier, monospace';
        ctx.fillText(namaTarget, W / 2, imgY + imgH + 35);

        ctx.font = 'bold 22px "Courier New", Courier, monospace';
        let lineY = imgY + imgH + 130;
        ctx.fillText('FOR ROBBERY, CATTLE RUSTLING,', W / 2, lineY);
        ctx.fillText('AND GENERAL OUTLAWRY WITHIN THE STATE.', W / 2, lineY + 30);

        ctx.font = 'italic 18px "Courier New", Courier, monospace';
        ctx.fillText('CONTACT SHERIFF OFFICE - DODGE CITY', W / 2, pY + pH - 65);

        function drawNail(nx, ny) {
            ctx.fillStyle = '#4a4a4a';
            ctx.beginPath(); ctx.arc(nx, ny, 12, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#737373';
            ctx.beginPath(); ctx.arc(nx - 3, ny - 3, 4, 0, Math.PI * 2); ctx.fill();
        }
        drawNail(pX + 20, pY + 20);
        drawNail(pX + pW - 20, pY + 20);
        drawNail(pX + 20, pY + pH - 20);
        drawNail(pX + pW - 20, pY + pH - 20);

        const outBuffer = canvas.toBuffer('image/png');

        await raiden.sendMessage(m.chat, {
            image: outBuffer,
            caption: `☠️  *WANTED ALIVE OR DEAD* ☠️\n\nBuronan bernama *${namaTarget}* telah resmi dimasukkan ke dalam daftar pencarian orang!`
        }, { quoted: m });

        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error(e);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;
