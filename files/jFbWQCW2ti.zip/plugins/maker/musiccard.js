import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'musiccard',
  category: 'maker',
  command: ['musiccard', 'musikcard', 'cardmusik'],
};

const handler = async (m, konteksInti) => {
    let { Reply, command, daftar, downloadContentFromMessage, isVip, prefix, raiden, text } = konteksInti;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    if (!text || !text.includes('|')) return Reply(`Format salah!\n\nContoh: ${prefix + command} Ginseng Strip 2002|Yung Lean`);
    if (!m.quoted) return Reply('Reply foto album terlebih dahulu!');

    const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
    if (!quotedMsg.imageMessage) return Reply('Reply foto album terlebih dahulu!');

    const [judul, artis] = text.split('|').map(v => v.trim());
    if (!judul || !artis) return Reply(`Format salah!\n\nContoh: ${prefix + command} Ginseng Strip 2002|Yung Lean`);

    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        const stream = await downloadContentFromMessage(quotedMsg.imageMessage, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        const albumBuffer = buffer;

        const { createCanvas, loadImage } = (await import('canvas')).default;
        const albumImg = await loadImage(albumBuffer);

        const W = 1080;
        const H = 1920; 
        const canvas = createCanvas(W, H);
        const ctx = canvas.getContext('2d');

        function drawRoundRect(context, x, y, width, height, radius) {
            context.beginPath();
            context.moveTo(x + radius, y);
            context.lineTo(x + width - radius, y);
            context.quadraticCurveTo(x + width, y, x + width, y + radius);
            context.lineTo(x + width, y + height - radius);
            context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
            context.lineTo(x + radius, y + height);
            context.quadraticCurveTo(x, y + height, x, y + height - radius);
            context.lineTo(x, y + radius);
            context.quadraticCurveTo(x, y, x + radius, y);
            context.closePath();
        }

        const microC = createCanvas(8, 14);
        const microCtx = microC.getContext('2d');
        microCtx.drawImage(albumImg, 0, 0, 8, 14);

        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, W, H);

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(microC, -100, -100, W + 200, H + 200);

        ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
        ctx.fillRect(0, 0, W, H);

        const cardW = 940; 
        const cardH = 1540; 
        const cardX = (W - cardW) / 2; 
        const cardY = 190; 
        const cardRadius = 75; 

        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 80;
        ctx.shadowOffsetY = 40;
        ctx.fillStyle = '#000';
        drawRoundRect(ctx, cardX, cardY, cardW, cardH, cardRadius);
        ctx.fill();
        ctx.restore();

        drawRoundRect(ctx, cardX, cardY, cardW, cardH, cardRadius);
        ctx.fillStyle = 'rgba(28, 28, 28, 0.65)'; 
        ctx.fill();

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        const padA = 45; 
        const albumX = cardX + padA;
        const albumY = cardY + padA;
        const albumW = cardW - (padA * 2); 
        const albumRadius = 24; 

        ctx.save();
        drawRoundRect(ctx, albumX, albumY, albumW, albumW, albumRadius);
        ctx.clip();
        ctx.drawImage(albumImg, albumX, albumY, albumW, albumW);
        ctx.restore();

        const badgeR = 32; 
        const badgeX = albumX + albumW - badgeR - 22; 
        const badgeY = albumY + albumW - badgeR - 22; 
        
        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = 20;
        ctx.shadowOffsetY = 8;
        ctx.fillStyle = '#1DB954'; 
        ctx.beginPath(); ctx.arc(badgeX, badgeY, badgeR, 0, Math.PI * 2); ctx.fill();
        ctx.shadowColor = 'transparent';

        ctx.save();
        ctx.translate(badgeX, badgeY);
        ctx.rotate(-0.05); 
        ctx.strokeStyle = '#000000';
        ctx.lineCap = 'round';
        ctx.lineWidth = 5;
        ctx.beginPath(); ctx.arc(0, -3, 17, Math.PI + 0.6, Math.PI*2 - 0.6); ctx.stroke();
        ctx.lineWidth = 4;
        ctx.beginPath(); ctx.arc(0, 4, 13, Math.PI + 0.65, Math.PI*2 - 0.65); ctx.stroke();
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(0, 10, 8, Math.PI + 0.7, Math.PI*2 - 0.7); ctx.stroke();
        ctx.restore();

        const textX = albumX; 
        let cy = albumY + albumW + 55; 

        ctx.textBaseline = 'top';

        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.font = '500 24px "-apple-system", "BlinkMacSystemFont", "Helvetica Neue", sans-serif';
        ctx.fillText('iPhone', textX, cy);
        cy += 38;

        ctx.fillStyle = '#ffffff';
        ctx.font = '700 52px "-apple-system", "BlinkMacSystemFont", "Helvetica Neue", sans-serif';
        let judulCut = judul.length > 20 ? judul.slice(0, 18) + '...' : judul;
        ctx.fillText(judulCut, textX, cy);

        const titleWidth = ctx.measureText(judulCut).width;
        const eX = textX + titleWidth + 16; 
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        drawRoundRect(ctx, eX, cy + 10, 30, 30, 6); 
        ctx.fill(); 
        ctx.fillStyle = '#000000';
        ctx.font = '800 18px "-apple-system", "Helvetica Neue", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('E', eX + 15, cy + 15);
        ctx.textAlign = 'left';

        const airX = albumX + albumW - 25;
        ctx.save();
        ctx.translate(airX, cy + 22); 
        
        ctx.fillStyle = '#ffffff'; 
        ctx.beginPath();
        ctx.moveTo(0, 5); ctx.lineTo(-12, 22); ctx.lineTo(12, 22); ctx.fill(); 
        
        ctx.strokeStyle = '#ffffff'; 
        ctx.lineWidth = 3.5;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(0, 25, 12, Math.PI + 0.65, Math.PI*2 - 0.65); ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 25, 21, Math.PI + 0.55, Math.PI*2 - 0.55); ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 25, 30, Math.PI + 0.45, Math.PI*2 - 0.45); ctx.stroke();
        ctx.restore();

        cy += 65;

        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.font = '400 40px "-apple-system", "BlinkMacSystemFont", "Helvetica Neue", sans-serif';
        let artisCut = artis.length > 28 ? artis.slice(0, 25) + '...' : artis;
        ctx.fillText(artisCut, textX, cy);
        
        cy += 85;

        const trackW = albumW; 
        
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        drawRoundRect(ctx, textX, cy, trackW, 8, 4); 
        ctx.fill(); 
        
        const progW = trackW * 0.21; 
        ctx.fillStyle = '#ffffff';
        drawRoundRect(ctx, textX, cy, progW, 8, 4); 
        ctx.fill();
        
        ctx.shadowColor = 'rgba(0,0,0,0.3)';
        ctx.shadowBlur = 8;
        ctx.shadowOffsetY = 2;
        ctx.beginPath(); ctx.arc(textX + progW, cy + 4, 10, 0, Math.PI*2); ctx.fill();
        ctx.shadowColor = 'transparent';
        
        cy += 30;

        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.font = '500 24px "-apple-system", "Helvetica Neue", sans-serif'; 
        ctx.fillText('0:33', textX, cy);
        ctx.textAlign = 'right';
        ctx.fillText('-2:01', textX + trackW, cy);
        ctx.textAlign = 'left';

        cy += 115; 
        const ctrlCY = cy; 
        const centerCardX = cardX + (cardW / 2);

        ctx.fillStyle = '#ffffff';
        drawRoundRect(ctx, centerCardX - 22, ctrlCY - 34, 14, 68, 5); ctx.fill();
        drawRoundRect(ctx, centerCardX + 8, ctrlCY - 34, 14, 68, 5); ctx.fill();

        const gap = 190; 
        const prevX = centerCardX - gap; 
        const nextX = centerCardX + gap;

        drawRoundRect(ctx, prevX - 38, ctrlCY - 25, 6, 50, 3); ctx.fill(); 
        ctx.beginPath(); ctx.moveTo(prevX - 22, ctrlCY); ctx.lineTo(prevX + 10, ctrlCY - 24); ctx.lineTo(prevX + 10, ctrlCY + 24); ctx.fill(); 
        ctx.beginPath(); ctx.moveTo(prevX + 8, ctrlCY); ctx.lineTo(prevX + 40, ctrlCY - 24); ctx.lineTo(prevX + 40, ctrlCY + 24); ctx.fill(); 

        drawRoundRect(ctx, nextX + 32, ctrlCY - 25, 6, 50, 3); ctx.fill(); 
        ctx.beginPath(); ctx.moveTo(nextX + 22, ctrlCY); ctx.lineTo(nextX - 10, ctrlCY - 24); ctx.lineTo(nextX - 10, ctrlCY + 24); ctx.fill(); 
        ctx.beginPath(); ctx.moveTo(nextX - 8, ctrlCY); ctx.lineTo(nextX - 40, ctrlCY - 24); ctx.lineTo(nextX - 40, ctrlCY + 24); ctx.fill(); 

        cy += 160; 

        const volLowX = textX + 15;
        const volHiX = albumX + albumW - 25;
        const volTrackX = textX + 70; 
        const volTrackW = albumW - 130;

        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.beginPath();
        ctx.moveTo(volLowX - 8, cy - 5); ctx.lineTo(volLowX + 1, cy - 5);
        ctx.lineTo(volLowX + 13, cy - 14); ctx.lineTo(volLowX + 13, cy + 14);
        ctx.lineTo(volLowX + 1, cy + 5); ctx.lineTo(volLowX - 8, cy + 5);
        ctx.fill();

        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        drawRoundRect(ctx, volTrackX, cy - 4, volTrackW, 8, 4); ctx.fill();
        
        const volW = volTrackW * 0.55;
        ctx.fillStyle = '#ffffff';
        drawRoundRect(ctx, volTrackX, cy - 4, volW, 8, 4); ctx.fill();
        
        ctx.shadowColor = 'rgba(0,0,0,0.3)';
        ctx.shadowBlur = 10;
        ctx.shadowOffsetY = 3;
        ctx.beginPath(); ctx.arc(volTrackX + volW, cy, 18, 0, Math.PI*2); ctx.fill();
        ctx.shadowColor = 'transparent';

        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.beginPath();
        ctx.moveTo(volHiX - 13, cy - 5); ctx.lineTo(volHiX - 4, cy - 5);
        ctx.lineTo(volHiX + 8, cy - 14); ctx.lineTo(volHiX + 8, cy + 14);
        ctx.lineTo(volHiX - 4, cy + 5); ctx.lineTo(volHiX - 13, cy + 5);
        ctx.fill();
        
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(volHiX + 8, cy, 10, -Math.PI/3, Math.PI/3); ctx.stroke();
        ctx.beginPath(); ctx.arc(volHiX + 8, cy, 18, -Math.PI/3, Math.PI/3); ctx.stroke();

        const outBuffer = canvas.toBuffer('image/png');

        await raiden.sendMessage(m.chat, {
            image: outBuffer,
            caption: `乂  *Music Now Playing*\n\n*Judul:* ${judul}\n*Artis:* ${artis}`
        }, { quoted: m });

        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error(e);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;
