import axios from 'axios';

const pluginConfig = {
  name: 'tosedih',
  category: 'maker',
  command: ['tosedih'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, uploadKappaFile } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    const teks = "make the person look sad, realistic sad expression, crying eyes, unhappy face";    
    if (!/image\//i.test(mime)) {
        return Reply(`❌ Reply ke *gambar* atau kirim gambar dengan caption *${prefix + command}*`);
    }    
    Reply("🎨 Sedang memproses wajah menjadi sedih... Mohon tunggu sebentar!");
    await raiden.sendMessage(m.chat, { react: { text: "😢", key: m.key } });
    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar.");
        const genName = (mType) => {
            const ext = (mType || '').split('/')[1] || 'jpg';
            return `tosedih_${Date.now()}.${ext}`;
        };
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime, genName);
        if (!userImageUrl) throw new Error("Gagal upload gambar ke server");
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(teks)}`;
        const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
        const hasilBuffer = Buffer.from(response.data, "binary");
        await raiden.sendMessage(
            m.chat,
            { image: hasilBuffer, caption: `*Done bosku 😢*` },
            { quoted: m }
        );
    } catch (e) {
        await Reply("❌ Error: " + e.message);
    } finally {
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    }
};

export default handler;
