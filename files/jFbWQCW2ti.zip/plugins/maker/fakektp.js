const pluginConfig = {
  name: 'fakektp',
  category: 'maker',
  command: ['fakektp'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPrem, isVip, prefix, raiden, text, uploadKappaFile } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (checkLimit(m.sender, isPrem(m.sender), isVip)) return Reply(global.mess.limit);

    let contoh = `*Format Penggunaan (Reply/Kirim Foto):*
${prefix + command} Nama|Nik|Provinsi|Kota|TTL|Kelamin|Darah|Alamat|RtRw|Desa|Kecamatan|Agama|Status|Pekerjaan|Warga|Berlaku|Dibuat

*Contoh:*
${prefix + command} Raiden|12345678|Jawa Timur|Surabaya|Jakarta, 01-01-2000|Laki-laki|O|Jl. Mawar|001/002|Mekarsari|Tegalsari|Islam|Belum Kawin|Pelajar|WNI|Seumur Hidup|Surabaya, 20-01-2024`;

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    if (!/image/.test(mime)) return Reply("Mana fotonya? Kirim atau reply foto untuk pas foto KTP!");
    if (!text) return Reply(contoh);

    let split = text.split("|");
    if (split.length < 17) return Reply(contoh);

    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        let media = await q.download();
        let photoUrl = await uploadKappaFile(media, `${m.sender}.jpg`);
        if (!photoUrl) return Reply("❌ Gagal mengupload foto ke Pixhost.");

        addLimit(m.sender, isPrem(m.sender), isVip);

        let [nama, nik, prov, kota, ttl, jk, darah, alamat, rtrw, desa, kec, agama, status, kerja, warga, berlaku, buat] = split;

        let api_url = `${global.fgsi}/api/maker/ktp?apikey=${global.fgsiApikey}&nama=${encodeURIComponent(nama)}&provinsi=${encodeURIComponent(prov)}&kota=${encodeURIComponent(kota)}&nik=${encodeURIComponent(nik)}&ttl=${encodeURIComponent(ttl)}&jenis_kelamin=${encodeURIComponent(jk)}&golongan_darah=${encodeURIComponent(darah)}&alamat=${encodeURIComponent(alamat)}&rtRw=${encodeURIComponent(rtrw)}&kel_desa=${encodeURIComponent(desa)}&kecamatan=${encodeURIComponent(kec)}&agama=${encodeURIComponent(agama)}&status=${encodeURIComponent(status)}&pekerjaan=${encodeURIComponent(kerja)}&kewarganegaraan=${encodeURIComponent(warga)}&masa_berlaku=${encodeURIComponent(berlaku)}&terbuat=${encodeURIComponent(buat)}&pas_photo=${encodeURIComponent(photoUrl)}`;

        await raiden.sendMessage(m.chat, { 
            image: { url: api_url }, 
            caption: `✅ *FAKE KTP SUCCESS*\n\n👤 *Nama:* ${nama}\n🆔 *NIK:* ${nik}\n📍 *Wilayah:* ${kota}, ${prov}` 
        }, { quoted: m });

        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error(e);
        Reply("❌ Terjadi kesalahan saat memproses data.");
    }
};

export default handler;
