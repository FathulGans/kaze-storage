import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tojawa',
  category: 'maker',
  command: ['tojawa'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, prefix, raiden, uploadKappaFile } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    if (!/image\//i.test(mime)) {
        return Reply(`❌ Reply ke *gambar* atau kirim gambar dengan caption *${prefix}tojawa*`);
    }
await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });

    const PROMPT_JAWA = `
    Ubah pakaian orang di foto ini menjadi pakaian adat Jawa yang autentik dan elegan.
    Jika laki-laki, kenakan beskap hitam khas Jawa lengkap dengan blangkon dan pegang keris di pinggangnya.
    Jika perempuan, kenakan kebaya Jawa klasik berwarna lembut dengan sanggul rapi.
    Pastikan hasilnya terlihat seperti foto sungguhan dan mempertahankan wajah, ekspresi, serta rambut asli tanpa perubahan.
    Latar belakang boleh disesuaikan agar tampak seperti suasana budaya Jawa tradisional.
    `;


    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime || 'image/jpeg');
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_JAWA)}`;
const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
const hasilBuffer = Buffer.from(response.data, "binary");

await raiden.sendMessage(
    m.chat,
    { image: hasilBuffer, caption: mess.done },
    { quoted: m }
);
    } catch (e) {
        await Reply("❌ Error: " + e.message);
    } finally {
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    }
};

export default handler;
