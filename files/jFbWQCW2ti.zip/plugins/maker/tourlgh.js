import axios from 'axios';
import crypto from 'crypto';

const pluginConfig = {
  name: 'tourlgh',
  category: 'maker',
  command: ['tourlgh'],
};

const handler = async (m, ctx) => {
    let { Reply, downloadContentFromMessage, raiden } = ctx;
    const githubToken = global.githubToken;
    const owner = 'RahmadPasker';
    const branch = 'main';
    let repos = ['dat1','dat2','dat3','dat4'];
    
    async function ensureRepoExists(repo) {
        try {
            await axios.get(`https://api.github.com/repos/${owner}/${repo}`, {
                headers: { Authorization: `Bearer ${githubToken}` }
            });
        } catch (e) {
            if (e.response?.status === 404) {
                await axios.post(`https://api.github.com/user/repos`,
                    { name: repo, private: false },
                    { headers: { Authorization: `Bearer ${githubToken}` } }
                );
                if (!repos.includes(repo)) repos.push(repo);
            } else throw e;
        }
    }
    
    function generateRepoName() {
        return `dat-${crypto.randomBytes(3).toString('hex')}`;
    }
    
    function getExtension(mimeType) {
        const extensions = {
            'image/jpeg': 'jpg',
            'image/jpg': 'jpg',
            'image/png': 'png',
            'image/gif': 'gif',
            'image/webp': 'webp',
            'video/mp4': 'mp4',
            'video/3gpp': '3gp',
            'video/quicktime': 'mov',
            'audio/mpeg': 'mp3',
            'audio/ogg': 'ogg',
            'audio/aac': 'aac',
            'application/pdf': 'pdf',
            'application/zip': 'zip',
            'application/vnd.rar': 'rar',
            'text/plain': 'txt',
            'application/msword': 'doc'
        };
        return extensions[mimeType] || 'bin';
    }
    
    async function uploadFile(buffer, mimeType) {
        const ext = getExtension(mimeType);
        const code = crypto.randomBytes(3).toString('hex');
        const fileName = `rahmad-elaina-${Date.now()}.${ext}`;
        const filePathGitHub = `uploads/${fileName}`;
        const base64Content = buffer.toString('base64');
        
        let targetRepo = repos[Math.floor(Math.random()*repos.length)];
        
        try {
            await ensureRepoExists(targetRepo);
        } catch {
            targetRepo = generateRepoName();
            await ensureRepoExists(targetRepo);
        }
        
        const response = await axios.put(
            `https://api.github.com/repos/${owner}/${targetRepo}/contents/${filePathGitHub}`,
            { 
                message: `Upload file ${fileName}`, 
                content: base64Content, 
                branch: branch 
            },
            { 
                headers: { 
                    Authorization: `Bearer ${githubToken}`,
                    'Content-Type': 'application/json',
                    'Accept': 'application/vnd.github+json'
                } 
            }
        );
        
        return `https://raw.githubusercontent.com/${owner}/${targetRepo}/${branch}/${filePathGitHub}`;
    }
    
    try {
        const q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || '';
        
        if (!mime) return Reply('Mana filenya? Reply atau kirim file!');
        
        await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let buffer;
        let mimeType = mime;
        
        if (q.download) {
            buffer = await q.download();
        } else if (m.message?.imageMessage) {
            const mediaBuffer = await downloadContentFromMessage(m.message, 'image');
            let chunks = [];
            for await (const chunk of mediaBuffer) {
                chunks.push(chunk);
            }
            buffer = Buffer.concat(chunks);
            mimeType = m.message.imageMessage.mimetype;
        } else if (m.message?.videoMessage) {
            const mediaBuffer = await downloadContentFromMessage(m.message, 'video');
            let chunks = [];
            for await (const chunk of mediaBuffer) {
                chunks.push(chunk);
            }
            buffer = Buffer.concat(chunks);
            mimeType = m.message.videoMessage.mimetype;
        } else if (m.message?.audioMessage) {
            const mediaBuffer = await downloadContentFromMessage(m.message, 'audio');
            let chunks = [];
            for await (const chunk of mediaBuffer) {
                chunks.push(chunk);
            }
            buffer = Buffer.concat(chunks);
            mimeType = m.message.audioMessage.mimetype;
        } else if (m.message?.documentMessage) {
            const mediaBuffer = await downloadContentFromMessage(m.message, 'document');
            let chunks = [];
            for await (const chunk of mediaBuffer) {
                chunks.push(chunk);
            }
            buffer = Buffer.concat(chunks);
            mimeType = m.message.documentMessage.mimetype;
        } else {
            return Reply('File tidak didukung!');
        }
        
        if (!buffer || buffer.length === 0) {
            return Reply('Gagal mendapatkan file!');
        }
        
        if (buffer.length > 25 * 1024 * 1024) {
            return Reply('File terlalu besar! Maksimal 25MB.');
        }
        
        let url = await uploadFile(buffer, mimeType);
        
        const fileSize = (buffer.length / 1024 / 1024).toFixed(2);
        const extension = getExtension(mimeType).toUpperCase();
        
        await raiden.sendMessage(m.chat, {
            text: `✅ *FILE UPLOADED TO GITHUB*\n\n📁 *URL:* ${url}\n📦 *Size:* ${fileSize} MB\n🔤 *Type:* ${extension}\n\n_Direct link tersedia untuk download_`,
            contextInfo: {
                externalAdReply: {
                    title: 'GitHub Upload Success',
                    body: `File ${extension} • ${fileSize}MB`,
                    thumbnailUrl: 'https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png',
                    sourceUrl: url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });
        
    } catch(e) {
        console.error('GitHub Upload Error:', e.response?.data || e.message);
        
        if (e.response?.status === 401) {
            Reply('Token GitHub invalid! Periksa token Anda.');
        } else if (e.response?.status === 403) {
            Reply('Rate limit GitHub terlampaui! Coba lagi nanti.');
        } else if (e.response?.status === 404) {
            Reply('Repository tidak ditemukan! Buat repo dat1, dat2, dst di GitHub.');
        } else {
            Reply(`Gagal upload: ${e.message}`);
        }
    }
    
    return;
};

export default handler;
