import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tochibi',
  category: 'maker',
  command: ['tochibi'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, raiden, uploadKappaFile } = ctx;
if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    if (!/image\//i.test(mime)) {
        return Reply(`❌ Reply ke *gambar* atau kirim gambar dengan caption *${prefix}tochibi*`);
    }
    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });

    const PROMPT_CHIBI = `
    Transform the person in the image into a cute anime chibi version. 
    Keep the same hairstyle, outfit style, and recognizable features, 
    but make the head slightly larger and the body smaller for a chibi proportion. 
    Use soft anime colors, expressive eyes, and a clean illustration look. 
    The final result should look like a high-quality anime chibi artwork.
    `;


    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime || 'image/jpeg');     
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_CHIBI)}`;
const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
const hasilBuffer = Buffer.from(response.data, "binary");

await raiden.sendMessage(
    m.chat,
    { image: hasilBuffer, caption: mess.done },
    { quoted: m }
);
    } catch (e) {
        await Reply("❌ Error: " + e.message);
    } finally {
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    }
};

export default handler;
