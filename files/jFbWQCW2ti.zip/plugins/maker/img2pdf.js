import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'img2pdf',
  category: 'maker',
  command: ['img2pdf', 'imagetopdf', 'gambartopdf'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    
    if (!/image\//i.test(mime)) {
        return Reply(
            `╭─❏ *Image to Pdf* - Gagal
│✧ Alasan : Reply gambar terlebih dahulu
│✧ Format : ${prefix + command}
╰──────────❏`
        )
    }
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    try {
        const imageBuffer = await q.download();
        if (!imageBuffer) {
            throw new Error('Gagal download gambar');
        }
        
        const { PDFDocument } = (await import('pdf-lib')).default;
        const pdfDoc = await PDFDocument.create();
        
        const image = await pdfDoc.embedJpg(imageBuffer);
        const page = pdfDoc.addPage([image.width, image.height]);
        page.drawImage(image, {
            x: 0,
            y: 0,
            width: image.width,
            height: image.height
        });
        
        const pdfBytes = await pdfDoc.save();
        const pdfBuffer = Buffer.from(pdfBytes);
        const fileName = `gambar-${Date.now()}.pdf`;
        const fileSize = (pdfBuffer.length / 1024).toFixed(2);
        
        await raiden.sendMessage(m.chat, {
            document: pdfBuffer,
            mimetype: 'application/pdf',
            fileName: fileName,
            caption: mess.done
        }, { quoted: m });
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[IMG2PDF ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        
        Reply(
            `╭─❏ *Image to Pdf* - Gagal
│✧ Error : ${error.message || 'Gagal membuat pdf'}
╰──────────❏`
        )
    }
};

export default handler;
