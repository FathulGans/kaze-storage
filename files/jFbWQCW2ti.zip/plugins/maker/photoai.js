import __axios from 'axios';
import __form_data from 'form-data';
import __https from 'https';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'photoai',
  category: 'maker',
  command: ['photoai'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, prefix, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);

    if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    const axios = __axios;
    const FormData = __form_data;
    const Jimp = (await import('jimp')).default;
    const fakeUserAgent = (await import('fake-useragent')).default;
    const https = __https;

    const agent = new https.Agent({
        rejectUnauthorized: false
    });

    if (!global.photoaiSessions) global.photoaiSessions = {};

    const PROMPT_LOCK = `Guy in the image\nSubject 2: Girl in the image\nA downward-angled photograph captures the active MacBook screen filling nearly the entire frame, its glossy surface reflecting faint ambient light while revealing subtle pixel-grid texture from the close proximity, with only a thin strip of the keyboard visible along the lower edge. The digital workspace shows a dark-themed Spotify “Liked Songs” window on the left and a large Photo Booth live-preview window on the right, where both Subjects appear side-by-side in a dim bedroom. They are still wearing the same oversized black hoodies, but the hoods rest back enough for their faces to remain fully visible, allowing natural light to fall cleanly across their expressions. The hoodie fabric forms soft folds and textured shadows around their shoulders and necklines, framing their faces without obscuring them. The couple reclines against an off-white wall and lightly rumpled bedding, leaning comfortably toward one another; the Guy holds a phone in his right hand, the clear protective case catching small screen reflections, while the Girl rests closely beside him, their proximity creating realistic overlapping shadows and gentle shared warmth in the frame. Ambient room lighting mixes with the cool glow of the MacBook screen, producing lifelike gradients on their skin, soft directional shading beneath their jawlines, and subtle highlights on foreheads and cheeks. Deep blacks from the interface, cool digital blues, muted greens, and warm skin tones combine into a natural, nocturnal color palette that feels candid and unedited. The full scene carries an HD, ultra-realistic, authentic atmosphere with natural imperfections—tiny screen reflections, soft moiré patterns, slight dust on the glass—mirroring a real late-night moment taken by an iPhone camera. Do not change Subjects’ facial features. Subjects must look 1000% identical to uploaded images.`;

    async function uploadUguu(buffer, filename = "file.jpg") {
        const form = new FormData();
        form.append("files[]", buffer, { filename, contentType: "application/octet-stream" });
        const { data } = await axios.post("https://uguu.se/upload.php", form, {
            headers: { ...form.getHeaders(), "User-Agent": fakeUserAgent() },
            httpsAgent: agent,
            maxBodyLength: Infinity,
            timeout: 60000
        });
        const url = data?.files?.[0]?.url;
        if (!url) throw new Error("Upload ke Uguu gagal");
        return url;
    }

    async function mergePhotos(buf1, buf2) {
        const img1 = await Jimp.read(buf1);
        const img2 = await Jimp.read(buf2);
        const size = 700;
        img1.cover(size, size);
        img2.cover(size, size);
        const gap = 20;
        const canvas = new Jimp(size * 2 + gap, size, 0xffffffff);
        canvas.composite(img1, 0, 0);
        canvas.composite(img2, size + gap, 0);
        return await canvas.getBufferAsync(Jimp.MIME_JPEG);
    }

    const key = `${m.chat}:${m.sender}`;
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";

    if (!global.photoaiSessions[key]) {
        if (!/image\//i.test(mime)) {
            return Reply(`❌ Balas *gambar pertama* dengan caption *${prefix}photoai*`);
        }
        const buf1 = await q.download();
        if (!buf1) return Reply("Gagal download gambar pertama.");
        
        global.photoaiSessions[key] = { buf1 };
        return m.reply(
            "✅ Foto pertama disimpan!\n" +
            `Sekarang balas *gambar kedua* dengan caption *${prefix}photoai* lagi.\n\n` +
            `Ketik *.batalphotoai* untuk membatalkan.`
        );
        
    } else {
        const sess = global.photoaiSessions[key];
        if (!/image\//i.test(mime)) {
            return Reply(`❌ Balas *gambar kedua* dengan caption *${prefix}photoai*`);
        }
        const buf2 = await q.download();
        if (!buf2) return Reply("Gagal download gambar kedua.");

        try {
            await raiden.sendMessage(m.chat, { react: { text: "🔄", key: m.key } });
            await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

            const merged = await mergePhotos(sess.buf1, buf2);
            const mergedUrl = await uploadUguu(merged, "merged.jpg");

            const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(mergedUrl)}&prompt=${encodeURIComponent(PROMPT_LOCK)}`;
const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
const hasilBuffer = Buffer.from(response.data, "binary");

await raiden.sendMessage(
    m.chat,
    { image: hasilBuffer, caption: mess.done },
    { quoted: m }
);
        } catch (e) {
            await Reply("❌ Error: " + e.message);
        } finally {
            delete global.photoaiSessions[key];
            await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        }
    }
};

export default handler;
