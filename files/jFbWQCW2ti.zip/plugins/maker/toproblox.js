import fetch from 'node-fetch';

const pluginConfig = {
  name: 'toproblox',
  category: 'maker',
  command: ['toproblox'],
};

const handler = async (m, ctx) => {
    let { Reply, raiden, safeErr } = ctx;
    await m.reply(`⏳ *Top 10 Roblox Game Trending...*`);

    try {
        const hit = async (url, options, type = "json") => {
            const response = await fetch(url, options);
            if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
            const ab = await response.arrayBuffer();
            return type === "json" ? JSON.parse(Buffer.from(ab).toString()) : Buffer.from(ab);
        };

        const customMappingNumber = (input) => {
            const char = ['𝟢', '𝟣', '𝟤', '𝟥', '𝟦', '𝟧', '𝟨', '𝟩', '𝟪', '𝟩', '𝟪', '𝟫'];
            return String(input).split("").map(v => isNaN(v) ? v : char[v]).join("");
        };

        const api1 = `https://apis.roblox.com/explore-api/v1/get-sort-content?sessionId=17996246-1290-440d-b789-d49484115b9a&sortId=top-playing-now&cpuCores=8&maxResolution=1920x1080&maxMemory=8192&networkType=4g`;
        const json1 = await hit(api1, { method: 'GET' }, 'json');
        const gameList = json1?.games?.slice(0, 10);
        
        if (!gameList || gameList.length === 0) return Reply("❌ Gagal mendapatkan list game.");

        let caption = `*TOP 10 PLAYING NOW GAMES ON ROBLOX 2026*\n\n`;
        
        for (let i = 0; i < gameList.length; i++) {
            const v = gameList[i];
            const likes = v.totalUpVotes + v.totalDownVotes > 0 
                ? ((v.totalUpVotes / (v.totalUpVotes + v.totalDownVotes)) * 100).toFixed(0)
                : "0";
            
            caption += `${i + 1}. ${v.name}\n`;
            caption += `   👥 Player: ${customMappingNumber(v.playerCount.toLocaleString("id-ID"))}\n`;
            caption += `   👍 Likes: ${customMappingNumber(likes)}%\n`;
            caption += `   🎮 Play: .https://www.roblox.com/games/${v.rootPlaceId}\n\n`;
        }
        
        caption += `© ${botname2}`;

        await raiden.sendMessage(m.chat, { 
            text: caption 
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        Reply(`❌ Terjadi kesalahan: ${safeErr(err)}`);
    }
};

export default handler;
