import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tohijab',
  category: 'maker',
  command: ['tohijab', 'hijabpin'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, prefix, raiden, uploadKappaFile } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    if (!/image\//i.test(mime)) {
        return Reply(`❌ Reply ke *gambar* atau kirim gambar dengan caption *${prefix}hijabpin*`);
    }
await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });

    const PROMPT_HIJABPIN = `
    Add a realistic hijab to the person in the image, styled naturally around the head and neck.
    Include a small elegant pin or brooch near the side of the head.
    Keep the facial structure, expression, and lighting exactly the same.
    Make it look like a real photo of someone truly wearing a hijab with a stylish pin.
    `;


    try {
        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
        const userImageUrl = await uploadKappaFile(userImageBuffer, mime || 'image/jpeg');
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_HIJABPIN)}`;
const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
const hasilBuffer = Buffer.from(response.data, "binary");

await raiden.sendMessage(
    m.chat,
    { image: hasilBuffer, caption: mess.done },
    { quoted: m }
);
    } catch (e) {
        await Reply("❌ Error: " + e.message);
    } finally {
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    }
};

export default handler;
