import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'buatgambar',
  category: 'maker',
  command: ['buatgambar', 'generateimage', 'createimage', 'genimage'],
};

const API = 'https://api-cloud.my.id/ai/text2img';

function adalahGambar(buf) {
    if (!buf || buf.length < 12) return false;
    return (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) ||
        (buf[0] === 0x89 && buf.toString('ascii', 1, 4) === 'PNG') ||
        (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP');
}

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    const prompt = String(text || '').trim();
    if (!prompt) {
        return Reply(`Format : .${command} [prompt]\nContoh : .${command} kucing terbang di angkasa`)
    }
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    try {
        const res = await axios.get(`${API}?prompt=${encodeURIComponent(prompt)}&shape=square`, {
            responseType: 'arraybuffer',
            timeout: 120000,
            validateStatus: () => true,
        });
        const buf = Buffer.from(res.data || []);
        if (res.status !== 200 || !adalahGambar(buf)) {
            let pesan = `Server error: ${res.status}`;
            try { const j = JSON.parse(buf.toString('utf8')); pesan = j.message || j.error || pesan; } catch (_) {}
            throw new Error(pesan);
        }
        await raiden.sendMessage(
            m.chat,
            {
                image: buf,
                caption: `${global.mess.done}\nPrompt : ${prompt}`
            },
            { quoted: m }
        );
        addLimit(m.sender, tierAkses.isPrem(m.sender), isVip);
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (error) {
        console.error('Error di buatgambar:', error?.message || error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        let errorMsg = error.message || 'Gagal membuat gambar';
        if (error.code === 'ECONNABORTED') errorMsg = 'Timeout, coba lagi nanti';
        Reply(`${global.mess.error}\nError : ${errorMsg}`)
    }
};

export default handler;
