import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'uguu',
  category: 'maker',
  command: ['uguu'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, safeErr, uploadUguu } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    
    if (!/image|video|audio|document/.test(mime)) {
        return Reply(`╭─❏ *Uguu Uploader*
│✧ Format : Reply media dengan caption .uguu
│✧ Support : Gambar, Video, Audio, File
╰──────────❏`);
    }
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    try {
        const buffer = await q.download();
        if (!buffer) throw new Error('Gagal download media');
        
        const generateFilename = (mimeType) => {
            const ext = mimeType.split('/')[1] || 'bin';
            return `archio-${Date.now()}.${ext}`;
        };
        
        const url = await uploadUguu(buffer, mime, generateFilename);
        
        if (!url) {
            throw new Error('Upload gagal');
        }
        
        await Reply(url);
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[UGUU ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(`╭─❏ *Uguu Uploader* - Gagal\n│✧ Error : ${safeErr(error)}\n╰──────────❏`);
    }
    return;
};

export default handler;
