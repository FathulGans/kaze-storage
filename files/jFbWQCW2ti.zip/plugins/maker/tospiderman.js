import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tospiderman',
  category: 'maker',
  command: ['tospiderman', 'tonaruto', 'tobatman', 'tosuperman', 'toironman', 'tocaptainamerica', 'tothor', 'tohulk', 'towolverine', 'todeadpool', 'toflash', 'toaquaman', 'tocyan', 'tovision', 'toblackpanther', 'tostarlord', 'togroot', 'torocket', 'todracula', 'tofrankenstein', 'towerewolf', 'tozombie', 'tovampire', 'toghost', 'toskeleton', 'todevil', 'toangel', 'tofairy', 'towizard', 'towinged', 'toelf', 'todwarf', 'toorc', 'totroll', 'togiant', 'tominotaur', 'tomedusa', 'tocentaur', 'togriffin', 'tophoenix', 'todragon', 'tounicorn', 'topeacock', 'towolf', 'tofox', 'tobear', 'tolion', 'totiger', 'topanda', 'tokoala', 'topenguin', 'toowl', 'toeagle', 'tofalcon', 'toraven', 'tocrow', 'tosnake', 'toshark', 'tocrocodile', 'tooctopus', 'tojellyfish', 'tostarfish', 'toseahorse', 'todolphin', 'towhale', 'torobot', 'tocyborg', 'toandroid', 'toalien', 'toufo', 'toastronaut', 'tocosmonaut', 'toscuba', 'todiver', 'topirate', 'tocowboy', 'toninja', 'tosamurai', 'toviking', 'toknight', 'toarcher', 'tomage', 'tocleric', 'tobard', 'torogue', 'tomonk', 'tobarbarian', 'tonecromancer', 'todruid', 'toranger', 'topaladin', 'togunslinger', 'tomechanic', 'toscientist', 'todoctor', 'toengineer', 'toartist', 'tosinger', 'todancer', 'toactor', 'todirector', 'towriter', 'tophotographer', 'tochef', 'tobaker', 'tobarista', 'tobartender', 'topilot', 'todriver', 'tosailor', 'tosoldier', 'topoliceman', 'tofirefighter', 'toteacher', 'toprofessor', 'tostudent', 'toprogrammer', 'todesigner', 'totester', 'tomanager', 'toboss', 'toceo', 'tocfo', 'tocoo', 'tocmo', 'tocto', 'tocpo', 'tocko', 'toclown', 'tomime', 'tojester', 'tomagician', 'toillusionist', 'toescapeartist', 'toacrobat', 'tocontortionist', 'toswordswallower', 'tofirebreather', 'tojugger', 'tounicyclist', 'totightrope', 'totrapeze', 'toaerialist', 'tocannon', 'tostilts', 'tomask', 'tomummy', 'tozorro', 'tosherlock', 'tophantom', 'todraco', 'tohannibal', 'tojoker', 'tovenom', 'tocarnage', 'togreen', 'tolizard', 'torhino', 'tovulture', 'toelectro', 'tosandman', 'tomysterio', 'togoblin', 'tochemo', 'toloki', 'tothanos', 'togalactus', 'todarkseid', 'tobrainiac', 'todoomsday', 'tobizarro', 'tometallo', 'toparasite', 'togrodd', 'tocircus', 'toreverse', 'togold', 'tosilver', 'tobronze', 'tocopper', 'tosteel', 'tocarbon', 'tocrystal', 'todiamond', 'tosapphire', 'toruby', 'toemerald', 'totopaz', 'toamethyst', 'toopal', 'toperidot', 'toaquamarine', 'tocitrine', 'totourmaline', 'togarnet', 'tospinel', 'tozircon', 'totanzanite', 'toiolite', 'tohematite', 'tomoonstone', 'tosunstone', 'tostarstone', 'tocomet', 'tometeor', 'toasteroid', 'tonebula', 'togalaxy', 'touniverse', 'toblackhole', 'towormhole', 'toportal', 'totime', 'tospace', 'todimension', 'toparallel', 'toalternate', 'tomultiverse', 'tomegaverse', 'tometaverse', 'toomniverse'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, downloadContentFromMessage, isVip, raiden, uploadKappaFile } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);

    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);


    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!/^image\//.test(mime)) {
        return Reply('❌ Reply atau kirim gambar!');
    }

    try {
        await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });
        
        const namaTransformasi = command.substring(2).replace(/[A-Z]/g, ' $&').toLowerCase().trim();
        const replyMsg = await Reply(`⏳ *Mengubah jadi ${namaTransformasi}...*`);

        let buffer;
        if (q.download) {
            buffer = await q.download();
        } else if (m.message?.imageMessage) {
            const mediaBuffer = await downloadContentFromMessage(m.message, 'image');
            let chunks = [];
            for await (const chunk of mediaBuffer) {
                chunks.push(chunk);
            }
            buffer = Buffer.concat(chunks);
        } else {
            return Reply('❌ Gagal mendapatkan gambar!');
        }

        const pixhostUrl = await uploadKappaFile(buffer, `${command}-${Date.now()}.jpg`);
        
        if (!pixhostUrl) {
            return Reply('❌ Gagal upload gambar ke Pixhost!');
        }

        const promptMap = {
            'tospiderman': `Transform the person in this image into Spider-Man. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to the iconic red and blue Spider-Man suit with web patterns. Add Spider-Man mask but keep the face visible/unmasked. Dynamic pose, high quality, cinematic lighting, photorealistic style.`,
            
            'tonaruto': `Transform the person in this image into Naruto Uzumaki. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to the orange Naruto jumpsuit, add Konoha headband on forehead. Anime art style but keep face realistic/photographic. Dynamic ninja pose, high quality.`,
            
            'tobatman': `Transform the person in this image into Batman. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to the black Batman suit with cape and cowl. The cowl should frame the face without covering it. Dark knight aesthetic, Gothic architecture background, cinematic lighting, photorealistic.`,
            
            'tosuperman': `Transform the person in this image into Superman. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to the blue Superman suit with red cape and S symbol on chest. Heroic pose, flying above Metropolis, comic book style but photorealistic face.`,
            
            'toironman': `Transform the person in this image into Iron Man. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to the red and gold Iron Man armor suit with arc reactor on chest. High-tech mechanical details, glowing repulsors, workshop background, cinematic quality.`,
            
            'tocaptainamerica': `Transform the person in this image into Captain America. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to the star-spangled Captain America uniform with shield. Patriotic theme, WWII era aesthetic, heroic pose, photorealistic style.`,
            
            'tothor': `Transform the person in this image into Thor. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to Asgardian armor, add flowing cape, holding Mjolnir hammer. Lightning effects in background, Norse mythology style, cinematic quality.`,
            
            'tohulk': `Transform the person in this image into Hulk. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Change skin color to green, add muscular physique, torn purple pants. Gamma radiation effects, angry expression but face still recognizable, comic book style.`,
            
            'towolverine': `Transform the person in this image into Wolverine. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to yellow and blue X-Men suit, add adamantium claws extending from hands. Feral expression, mutant power effects, high quality.`,
            
            'todeadpool': `Transform the person in this image into Deadpool. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to red and black Deadpool suit, add katana swords on back. Fourth-wall breaking pose, Marvel anti-hero style, humorous expression, photorealistic.`,
            
            'toflash': `Transform the person in this image into The Flash. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to red Flash suit with lightning bolt symbol, add speed force energy trails. Running pose, dynamic motion blur, DC comics style, photorealistic.`,
            
            'toaquaman': `Transform the person in this image into Aquaman. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to orange and green Aquaman suit, holding trident. Underwater Atlantis background, ocean king aesthetic, cinematic quality.`,
            
            'tocyan': `Transform the person in this image into Cyborg. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change parts of body to robotic/cybernetic enhancements with glowing blue lights. Half-human half-machine aesthetic, Teen Titans style, high tech details.`,
            
            'tovision': `Transform the person in this image into Vision. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change skin tone to red, add yellow gem on forehead, change clothing to green cape and tunic. Synthetic android appearance, Marvel style, photorealistic.`,
            
            'toblackpanther': `Transform the person in this image into Black Panther. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to black vibranium suit with silver patterns, add panther helmet but keep face visible. Wakandan warrior aesthetic, cinematic quality.`,
            
            'tostarlord': `Transform the person in this image into Star-Lord. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to red leather jacket, add helmet with face visible, holding blasters. Guardians of the Galaxy style, space background, photorealistic.`,
            
            'togroot': `Transform the person in this image into Groot. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Transform body into tree-like humanoid form, bark texture, branches growing from body. "I am Groot" pose, Guardians of the Galaxy flora colossus, cinematic quality.`,
            
            'torocket': `Transform the person in this image into Rocket Raccoon. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Transform into anthropomorphic raccoon with tactical gear, holding large gun. Cybernetic enhancements, Guardians of the Galaxy style, photorealistic.`,
            
            'todracula': `Transform the person in this image into Count Dracula. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to elegant black Victorian vampire outfit with red cape. Add pale skin tone, fangs, Transylvanian castle background, gothic horror style.`,
            
            'tofrankenstein': `Transform the person in this image into Frankenstein's monster. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add green skin tone, neck bolts, square head shape, stitches on face. Classic horror movie style, dark laboratory background, photorealistic.`,
            
            'towerewolf': `Transform the person in this image into a werewolf. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add fur, wolf-like features while maintaining facial recognition, claws, fangs. Full moon background, horror fantasy style, cinematic quality.`,
            
            'tozombie': `Transform the person in this image into a zombie. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add undead appearance, pale decaying skin, torn clothes, hunger for brains expression. Horror style, post-apocalyptic background, photorealistic.`,
            
            'tovampire': `Transform the person in this image into an elegant vampire. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to formal Victorian attire, add pale skin, red eyes, fangs. Gothic aesthetic, dark castle background, cinematic quality.`,
            
            'toghost': `Transform the person in this image into a ghost. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Make the body transparent/ethereal, floating pose, haunting expression. Paranormal energy aura, haunted house background, spooky style.`,
            
            'toskeleton': `Transform the person in this image into a living skeleton. **CRITICAL: Keep the original face, facial features, and skull shape EXACTLY the same.** Transform body into visible bones, no flesh, Halloween style. Dark background, spooky atmosphere, photorealistic.`,
            
            'todevil': `Transform the person in this image into a devil. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Add red skin tone, horns on head, tail, pitchfork. Hellfire background, demonic aesthetic, cinematic quality.`,
            
            'toangel': `Transform the person in this image into an angel. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add large white wings on back, glowing halo above head. Heavenly light, divine aura, clouds background, ethereal beauty.`,
            
            'tofairy': `Transform the person in this image into a fairy. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Add translucent wings on back, reduce body size slightly, magical forest background. Glitter dust, enchanting atmosphere, fantasy style.`,
            
            'towizard': `Transform the person in this image into a wizard. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to wizard robes, add pointed hat, magical staff, long beard. Spellbook, magical aura, fantasy RPG style.`,
            
            'towinged': `Transform the person in this image into a winged humanoid. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add large angelic or demonic wings on back, flying pose. Fantasy creature, clouds or sky background, cinematic quality.`,
            
            'toelf': `Transform the person in this image into an elf. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add pointed ears, change clothing to elven fantasy attire. Forest dweller, nature magic, fantasy RPG style, photorealistic.`,
            
            'todwarf': `Transform the person in this image into a dwarf. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Reduce height, add thick beard, change clothing to dwarven armor with axe. Mountain miner, fantasy warrior, cinematic quality.`,
            
            'toorc': `Transform the person in this image into an orc. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add green skin, tusks, tribal warrior appearance, brutal strength. Fantasy race, dark fantasy background, photorealistic.`,
            
            'togoblin': `Transform the person in this image into a goblin. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add green skin, pointy ears, mischievous expression. Small creature, treasure hoarder, fantasy style.`,
            
            'totroll': `Transform the person in this image into a troll. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add large brutish appearance, rough skin, bridge dweller. Fantasy monster, dark cave background, photorealistic.`,
            
            'togiant': `Transform the person in this image into a giant. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Increase size dramatically, cloud-height, mountainous background. Mythological being, epic scale, cinematic quality.`,
            
            'tominotaur': `Transform the person in this image into a minotaur. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add bull features while maintaining facial recognition, large muscular body, labyrinth background. Greek mythology, photorealistic.`,
            
            'tomedusa': `Transform the person in this image into Medusa. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Replace hair with living snakes, add stone gaze effect, Greek mythology gorgon. Stone statues in background, dark fantasy style.`,
            
            'tocentaur': `Transform the person in this image into a centaur. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Transform lower body into horse, upper body remains human with original face. Archer pose, Greek mythology, forest background, photorealistic.`,
            
            'togriffin': `Transform the person in this image into a griffin. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Combine with eagle head features while maintaining face, lion body, wings. Mythical creature, guardian of treasure, cinematic quality.`,
            
            'tophoenix': `Transform the person in this image into a phoenix. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Transform body into firebird with wings of flame, rebirth from ashes effect. Flaming wings, mythical creature, fiery background.`,
            
            'todragon': `Transform the person in this image into a dragon. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add dragon features while maintaining face, wings, scales, fire breath. Medieval fantasy, flying above castle, epic cinematic style.`,
            
            'tounicorn': `Transform the person in this image into a unicorn. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add horn on forehead, horse-like body, rainbow mane. Magical forest, fantasy creature, ethereal beauty.`,
            
            'topeacock': `Transform the person in this image into a peacock. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add colorful peacock feathers display, majestic bird appearance. Garden background, vibrant colors, photorealistic.`,
            
            'towolf': `Transform the person in this image into a wolf. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add wolf fur, ears, snout while maintaining face recognition. Pack animal, forest dweller, howling at moon, photorealistic.`,
            
            'tofox': `Transform the person in this image into a fox. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add fox features, red fur, pointed ears, bushy tail. Cunning animal, forest creature, photorealistic.`,
            
            'tobear': `Transform the person in this image into a bear. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add bear features, powerful build, fur. Forest giant, protective animal, photorealistic.`,
            
            'tolion': `Transform the person in this image into a lion. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add lion features, majestic mane, king of jungle. Savanna background, powerful predator, photorealistic.`,
            
            'totiger': `Transform the person in this image into a tiger. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add tiger features, striped fur, powerful build. Jungle hunter, photorealistic, cinematic.`,
            
            'topanda': `Transform the person in this image into a panda. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add panda features, black and white fur, bamboo eater. Cute animal, bamboo forest, photorealistic.`,
            
            'tokoala': `Transform the person in this image into a koala. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add koala features, eucalyptus eater, tree climber. Australia wildlife, cute animal, photorealistic.`,
            
            'topenguin': `Transform the person in this image into a penguin. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add penguin features, tuxedo appearance, waddling pose. Antarctic bird, ice background, photorealistic.`,
            
            'toowl': `Transform the person in this image into an owl. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add owl features, large eyes, feathers. Wise bird, night hunter, photorealistic.`,
            
            'toeagle': `Transform the person in this image into an eagle. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add eagle features, majestic bird of prey, wings spread. Soaring high, mountain background, photorealistic.`,
            
            'tofalcon': `Transform the person in this image into a falcon. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add falcon features, fastest bird, hunting dive pose. Sky background, photorealistic.`,
            
            'toraven': `Transform the person in this image into a raven. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add raven features, intelligent bird, dark feathers. Mystical, gothic background, photorealistic.`,
            
            'tocrow': `Transform the person in this image into a crow. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add crow features, black bird, ominous appearance. Flocking, dark atmosphere, photorealistic.`,
            
            'tosnake': `Transform the person in this image into a snake. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add snake features, reptile scales, slithering pose. Venomous or constrictor, jungle background, photorealistic.`,
            
            'toshark': `Transform the person in this image into a shark. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add shark features, sharp teeth, fin. Ocean predator, underwater scene, photorealistic.`,
            
            'tocrocodile': `Transform the person in this image into a crocodile. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add crocodile features, reptile scales, powerful jaws. River dweller, photorealistic.`,
            
            'tooctopus': `Transform the person in this image into an octopus. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add octopus features, eight arms, ocean creature. Intelligent, underwater, photorealistic.`,
            
            'tojellyfish': `Transform the person in this image into a jellyfish. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add jellyfish features, translucent body, floating tentacles. Ocean, bioluminescent, photorealistic.`,
            
            'tostarfish': `Transform the person in this image into a starfish. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add starfish features, radial symmetry, sea creature. Ocean floor, photorealistic.`,
            
            'toseahorse': `Transform the person in this image into a seahorse. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add seahorse features, small fish, curled tail. Ocean, photorealistic.`,
            
            'todolphin': `Transform the person in this image into a dolphin. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add dolphin features, intelligent mammal, ocean. Playful, jumping out of water, photorealistic.`,
            
            'towhale': `Transform the person in this image into a whale. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add whale features, largest mammal, ocean. Majestic, breaching water, photorealistic.`,
            
            'torobot': `Transform the person in this image into a robot. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add mechanical parts, metallic body, cybernetic enhancements. Futuristic, sci-fi background, photorealistic.`,
            
            'tocyborg': `Transform the person in this image into a cyborg. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add robotic parts on body while keeping face organic, cybernetic enhancements. Half-human half-machine, futuristic, photorealistic.`,
            
            'toandroid': `Transform the person in this image into an android. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add synthetic skin, artificial human appearance, AI aesthetic. Futuristic, sci-fi, photorealistic.`,
            
            'toalien': `Transform the person in this image into an alien. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add alien features, extraterrestrial being, unknown biology. Sci-fi, space background, photorealistic.`,
            
            'toufo': `Transform the person in this image into a UFO. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Place person inside flying saucer, alien spacecraft. Abduction beam, sci-fi, photorealistic.`,
            
            'toastronaut': `Transform the person in this image into an astronaut. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to NASA space suit with helmet (face visible inside). Zero gravity, space background, photorealistic.`,
            
            'tocosmonaut': `Transform the person in this image into a cosmonaut. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to Russian space suit, Soviet space program style. Space background, photorealistic.`,
            
            'toscuba': `Transform the person in this image into a scuba diver. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to scuba diving gear, oxygen tank, mask (face visible). Underwater, exploring ocean, photorealistic.`,
            
            'todiver': `Transform the person in this image into a deep sea diver. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to heavy deep sea diving suit with helmet (face visible). Ocean depth exploration, photorealistic.`,
            
            'topirate': `Transform the person in this image into a pirate. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to pirate outfit, add eye patch, tricorn hat, parrot on shoulder. Treasure map, ship background, photorealistic.`,
            
            'tocowboy': `Transform the person in this image into a cowboy. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to cowboy hat, boots, vest, lasso. Wild West saloon background, photorealistic.`,
            
            'toninja': `Transform the person in this image into a ninja. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to black ninja outfit, hood (face visible). Stealth pose, throwing stars, Japan background, photorealistic.`,
            
            'tosamurai': `Transform the person in this image into a samurai. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to samurai armor, katana sword. Japanese warrior, honor code, feudal Japan background, photorealistic.`,
            
            'toviking': `Transform the person in this image into a viking. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to viking armor, add horned helmet, axe. Norse warrior, longship, photorealistic.`,
            
            'toknight': `Transform the person in this image into a knight. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to full plate armor, helmet (face visible), sword and shield. Medieval castle background, photorealistic.`,
            
            'toarcher': `Transform the person in this image into an archer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to archer/hunter outfit, bow and arrow. Robin Hood style, forest background, photorealistic.`,
            
            'tomage': `Transform the person in this image into a mage. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to magical robes, add spellcasting effects, magical staff. Elemental magic, fantasy RPG class, photorealistic.`,
            
            'tocleric': `Transform the person in this image into a cleric. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to holy robes, divine magic effects. Religious warrior, healing aura, photorealistic.`,
            
            'tobard': `Transform the person in this image into a bard. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, add musical instrument (lute or flute). Storyteller, charming performer, photorealistic.`,
            
            'torogue': `Transform the person in this image into a rogue. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to dark leather armor, add daggers. Stealth, thief, shadowy figure, photorealistic.`,
            
            'tomonk': `Transform the person in this image into a monk. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to simple monk robes, martial arts pose. Spiritual, hand-to-hand combat, photorealistic.`,
            
            'tobarbarian': `Transform the person in this image into a barbarian. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to fur armor, add large axe. Fierce warrior, tribal rage, photorealistic.`,
            
            'tonecromancer': `Transform the person in this image into a necromancer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to dark robes, death magic effects, raising undead. Dark arts, spooky background, photorealistic.`,
            
            'todruid': `Transform the person in this image into a druid. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to nature-themed robes, nature magic effects, animal companion. Forest guardian, photorealistic.`,
            
            'toranger': `Transform the person in this image into a ranger. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to wilderness explorer outfit, bow, animal companion. Nature expert, photorealistic.`,
            
            'topaladin': `Transform the person in this image into a paladin. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to holy armor, light magic effects. Righteous crusader, divine warrior, photorealistic.`,
            
            'togunslinger': `Transform the person in this image into a gunslinger. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to Western outlaw outfit, dual pistols, quick draw pose. Wild West, photorealistic.`,
            
            'tomechanic': `Transform the person in this image into a mechanic. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to mechanic uniform, add tools, grease stains. Repairing machines, garage background, photorealistic.`,
            
            'toscientist': `Transform the person in this image into a scientist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to lab coat, add test tubes, research equipment. Laboratory background, discovery, photorealistic.`,
            
            'todoctor': `Transform the person in this image into a doctor. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to medical scrubs, add stethoscope. Hospital background, healing profession, photorealistic.`,
            
            'toengineer': `Transform the person in this image into an engineer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to hard hat, safety vest, add blueprint. Construction site, design, photorealistic.`,
            
            'toartist': `Transform the person in this image into an artist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to artist smock, add paint palette, brush, canvas. Creative expression, studio background, photorealistic.`,
            
            'tosinger': `Transform the person in this image into a singer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performance outfit, add microphone. Stage performance, concert background, photorealistic.`,
            
            'todancer': `Transform the person in this image into a dancer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to dance costume, graceful movements pose. Performance art, stage background, photorealistic.`,
            
            'toactor': `Transform the person in this image into an actor. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to dramatic/theatrical outfit, dramatic pose. Movie set, character portrayal, photorealistic.`,
            
            'todirector': `Transform the person in this image into a director. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to director attire, add clapperboard. Film set, creative vision, photorealistic.`,
            
            'towriter': `Transform the person in this image into a writer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to casual writer outfit, add typewriter, books. Literary creation, study background, photorealistic.`,
            
            'tophotographer': `Transform the person in this image into a photographer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to photographer vest, add professional camera. Capturing moments, photorealistic.`,
            
            'tochef': `Transform the person in this image into a chef. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to chef uniform, chef hat. Kitchen background, cooking masterpiece, photorealistic.`,
            
            'tobaker': `Transform the person in this image into a baker. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to baker outfit, add apron, rolling pin. Bakery background, delicious baked goods, photorealistic.`,
            
            'tobarista': `Transform the person in this image into a barista. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to barista apron, add coffee machine, latte art. Café background, photorealistic.`,
            
            'tobartender': `Transform the person in this image into a bartender. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to bartender outfit, add cocktail shaker. Bar background, mixing drinks, photorealistic.`,
            
            'topilot': `Transform the person in this image into a pilot. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to pilot uniform, flight suit. Cockpit background, aviation, photorealistic.`,
            
            'todriver': `Transform the person in this image into a race car driver. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to racing suit, helmet (face visible), fast car. Speedway, racing track, photorealistic.`,
            
            'tosailor': `Transform the person in this image into a sailor. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to naval uniform, ship wheel. Ocean voyage, photorealistic.`,
            
            'tosoldier': `Transform the person in this image into a soldier. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to military uniform, combat gear. Battlefield background, photorealistic.`,
            
            'topoliceman': `Transform the person in this image into a police officer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to police uniform, badge. Law enforcement, city background, photorealistic.`,
            
            'tofirefighter': `Transform the person in this image into a firefighter. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to fire suit, helmet (face visible), hose. Rescue hero, fire background, photorealistic.`,
            
            'toteacher': `Transform the person in this image into a teacher. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional teacher attire, classroom background, chalkboard. Education, photorealistic.`,
            
            'toprofessor': `Transform the person in this image into a professor. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to academic gown, university background. Knowledge, photorealistic.`,
            
            'tostudent': `Transform the person in this image into a student. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to student outfit, add backpack, books. Learning, school background, photorealistic.`,
            
            'toprogrammer': `Transform the person in this image into a programmer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to casual programmer outfit, add computer, code on screen. Software development, office background, photorealistic.`,
            
            'todesigner': `Transform the person in this image into a designer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to designer outfit, add sketchpad, design tools. Creative concepts, visual art, photorealistic.`,
            
            'totester': `Transform the person in this image into a quality tester. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to casual work outfit, checking products. Attention to detail, photorealistic.`,
            
            'tomanager': `Transform the person in this image into a manager. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional business attire, office background. Leadership, business strategy, photorealistic.`,
            
            'toboss': `Transform the person in this image into a boss. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to executive attire, commanding presence. Office, photorealistic.`,
            
            'toceo': `Transform the person in this image into a CEO. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to high-end business suit, corporate leader. Boardroom, photorealistic.`,
            
            'tocfo': `Transform the person in this image into a CFO. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional business attire, financial expert. Money management, office, photorealistic.`,
            
            'tocoo': `Transform the person in this image into a COO. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional business attire, operations management. Efficiency expert, photorealistic.`,
            
            'tocmo': `Transform the person in this image into a CMO. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional business attire, marketing strategy. Brand development, photorealistic.`,
            
            'tocto': `Transform the person in this image into a CTO. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional business attire, technology leadership. Innovation, photorealistic.`,
            
            'tocpo': `Transform the person in this image into a CPO. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional business attire, product development. User experience, photorealistic.`,
            
            'tocko': `Transform the person in this image into a CKO. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to professional business attire, knowledge management. Information systems, photorealistic.`,
            
            'toclown': `Transform the person in this image into a clown. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add clown makeup (paint on face without changing structure), colorful costume, red nose. Circus performer, photorealistic.`,
            
            'tomime': `Transform the person in this image into a mime. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add white face paint (on top of face), black and white striped shirt. Invisible walls, silent performance, photorealistic.`,
            
            'tojester': `Transform the person in this image into a jester. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to colorful jester outfit with bells. Medieval court fool, entertainment, photorealistic.`,
            
            'tomagician': `Transform the person in this image into a magician. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to magician tuxedo, top hat, magic wand. Illusion performance, stage, photorealistic.`,
            
            'toillusionist': `Transform the person in this image into an illusionist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to dramatic performance outfit, mind tricks pose. Grand magic show, photorealistic.`,
            
            'toescapeartist': `Transform the person in this image into an escape artist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performance outfit, add chains, locks. Daring escapes, photorealistic.`,
            
            'toacrobat': `Transform the person in this image into an acrobat. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to acrobat outfit, flexibility pose. Balance, circus performance, photorealistic.`,
            
            'tocontortionist': `Transform the person in this image into a contortionist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performance outfit, extreme flexibility pose. Bending body, photorealistic.`,
            
            'toswordswallower': `Transform the person in this image into a sword swallower. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, dangerous feat with sword. Circus act, photorealistic.`,
            
            'tofirebreather': `Transform the person in this image into a fire breather. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, breathing fire. Dangerous performance, night background, photorealistic.`,
            
            'tojugger': `Transform the person in this image into a juggler. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, multiple objects in air. Coordination, circus, photorealistic.`,
            
            'tounicyclist': `Transform the person in this image into a unicyclist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, balancing on one wheel. Circus skill, photorealistic.`,
            
            'totightrope': `Transform the person in this image into a tightrope walker. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, high wire, balance pole. Circus, photorealistic.`,
            
            'totrapeze': `Transform the person in this image into a trapeze artist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to aerialist outfit, flying through air. Circus aerialist, photorealistic.`,
            
            'toaerialist': `Transform the person in this image into an aerialist. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to aerialist outfit, silk ropes. Aerial acrobatics, photorealistic.`,
            
            'tocannon': `Transform the person in this image into a human cannonball. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, launched from cannon. Daredevil, circus, photorealistic.`,
            
            'tostilts': `Transform the person in this image into a stilt walker. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to performer outfit, tall stilts. Parade performer, photorealistic.`,
            
            'tomask': `Transform the person in this image into a masked figure. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add mysterious mask (covering part of face but still recognizable), mysterious identity. Hidden face, intrigue, photorealistic.`,
            
            'tomummy': `Transform the person in this image into a mummy. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Wrap body in bandages (face partially visible), ancient Egypt. Cursed, pyramid background, photorealistic.`,
            
            'tozorro': `Transform the person in this image into Zorro. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to black Zorro outfit, mask covering eyes, cape, sword. Masked vigilante, Spanish California, photorealistic.`,
            
            'tosherlock': `Transform the person in this image into Sherlock Holmes. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to detective outfit, deerstalker hat, pipe, magnifying glass. Victorian London, photorealistic.`,
            
            'tophantom': `Transform the person in this image into Phantom of the Opera. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add half-face mask (covering part of face), elegant cape. Tragic figure, opera house, photorealistic.`,
            
            'todraco': `Transform the person in this image into Dracula. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to elegant black vampire attire, add pale skin, fangs. Transylvania, classic horror, photorealistic.`,
            
            'tohannibal': `Transform the person in this image into Hannibal Lecter. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to prison jumpsuit or elegant suit, intelligent cannibal expression. Psychological, photorealistic.`,
            
            'tojoker': `Transform the person in this image into Joker. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add Joker makeup (white face paint, red smile, green hair), purple suit. Clown prince of crime, chaotic evil, photorealistic.`,
            
            'tovenom': `Transform the person in this image into Venom. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add black symbiote covering body, white spider symbol, sharp teeth. Spider-man antagonist, photorealistic.`,
            
            'tocarnage': `Transform the person in this image into Carnage. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add red symbiote covering body, chaotic appearance. Psychotic killer, photorealistic.`,
            
            'togreen': `Transform the person in this image into Green Goblin. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to green goblin armor, mask (face visible), goblin glider, pumpkin bombs. Spider-man villain, photorealistic.`,
            
            'tolizard': `Transform the person in this image into Lizard. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add reptilian features, scales, snout while maintaining face recognition. Scientist transformed, photorealistic.`,
            
            'torhino': `Transform the person in this image into Rhino. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add rhino-like armored suit, powerful brute appearance. Spider-man villain, photorealistic.`,
            
            'tovulture': `Transform the person in this image into Vulture. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to vulture tech suit, mechanical wings. Winged villain, photorealistic.`,
            
            'toelectro': `Transform the person in this image into Electro. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add electricity powers effect, glowing blue skin, lightning bolts. Spider-man villain, photorealistic.`,
            
            'tosandman': `Transform the person in this image into Sandman. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Transform body into sand, shape-shifting effect. Spider-man villain, photorealistic.`,
            
            'tomysterio': `Transform the person in this image into Mysterio. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to Mysterio suit, fishbowl helmet (face visible), illusion effects. Illusion master, photorealistic.`,
            
            'togoblin': `Transform the person in this image into Goblin. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add goblin-like features, green skin, pointy ears while maintaining face. Fantasy creature, photorealistic.`,
            
            'tochemo': `Transform the person in this image into Doctor Octopus. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to scientist outfit, add four mechanical arms. Brilliant scientist, Spider-man villain, photorealistic.`,
            
            'toloki': `Transform the person in this image into Loki. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to Asgardian armor with green and gold, horned helmet. God of mischief, trickster, photorealistic.`,
            
            'tothanos': `Transform the person in this image into Thanos. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add purple skin, chin ridges while maintaining face, Infinity Gauntlet. Mad Titan, cosmic threat, photorealistic.`,
            
            'togalactus': `Transform the person in this image into Galactus. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add cosmic entity appearance, purple armor, enormous size. Devourer of worlds, photorealistic.`,
            
            'todarkseid': `Transform the person in this image into Darkseid. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add grey skin, facial ridges while maintaining face, Omega beams. New God, DC villain, photorealistic.`,
            
            'tobrainiac': `Transform the person in this image into Brainiac. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to green alien android appearance, tentacles. Knowledge collector, photorealistic.`,
            
            'todoomsday': `Transform the person in this image into Doomsday. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add bony protrusions, grey skin, monstrous appearance. Creature that killed Superman, photorealistic.`,
            
            'tobizarro': `Transform the person in this image into Bizarro. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add grey skin, reverse Superman symbol, imperfect clone appearance. Opposite of Superman, photorealistic.`,
            
            'tometallo': `Transform the person in this image into Metallo. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same. Do not change the face at all.** Only change parts of body to metallic/cybernetic, add Kryptonite heart. Cyborg villain, photorealistic.`,
            
            'toparasite': `Transform the person in this image into Parasite. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add purple skin, energy draining appearance. Villain, photorealistic.`,
            
            'togrodd': `Transform the person in this image into Gorilla Grodd. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Add gorilla features while maintaining face, super-intelligent ape. Telepathy, DC villain, photorealistic.`,
            
            'tocircus': `Transform the person in this image into a circus performer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to colorful circus outfit. Big top, carnival atmosphere, photorealistic.`,
            
            'toreverse': `Transform the person in this image into a reversed version. **CRITICAL: Keep the original face, facial features, and head shape EXACTLY the same.** Mirror image effect, opposite colors, surreal appearance. Photorealistic.`,
            
            'togold': `Transform the person in this image into a gold statue. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into gold/metallic form, shiny reflective surface. Precious material, photorealistic.`,
            
            'tosilver': `Transform the person in this image into a silver statue. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into silver metallic form, shiny reflective surface. Photorealistic.`,
            
            'tobronze': `Transform the person in this image into a bronze statue. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into bronze statue, ancient metal, patina finish. Photorealistic.`,
            
            'tocopper': `Transform the person in this image into a copper material. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into copper material, reddish metallic, conductive. Photorealistic.`,
            
            'tosteel': `Transform the person in this image into steel. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into steel, industrial metal, strong and durable. Photorealistic.`,
            
            'tocarbon': `Transform the person in this image into carbon fiber. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into carbon fiber material, modern material, lightweight strength. Photorealistic.`,
            
            'tocrystal': `Transform the person in this image into crystal form. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into crystal, transparent, refractive, magical. Photorealistic.`,
            
            'todiamond': `Transform the person in this image into diamond. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into diamond, hardest natural material, brilliant facets. Photorealistic.`,
            
            'tosapphire': `Transform the person in this image into sapphire. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into sapphire gemstone, blue, royal elegance. Photorealistic.`,
            
            'toruby': `Transform the person in this image into ruby. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into ruby gemstone, red, passionate. Photorealistic.`,
            
            'toemerald': `Transform the person in this image into emerald. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into emerald gemstone, green, nature's treasure. Photorealistic.`,
            
            'totopaz': `Transform the person in this image into topaz. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into topaz gemstone, golden, solar energy. Photorealistic.`,
            
            'toamethyst': `Transform the person in this image into amethyst. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into amethyst gemstone, purple, spiritual. Photorealistic.`,
            
            'toopal': `Transform the person in this image into opal. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into opal gemstone, iridescent, rainbow colors. Photorealistic.`,
            
            'toperidot': `Transform the person in this image into peridot. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into peridot gemstone, olive green, space origin. Photorealistic.`,
            
            'toaquamarine': `Transform the person in this image into aquamarine. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into aquamarine gemstone, sea blue, ocean calm. Photorealistic.`,
            
            'tocitrine': `Transform the person in this image into citrine. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into citrine gemstone, yellow, solar power. Photorealistic.`,
            
            'totourmaline': `Transform the person in this image into tourmaline. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into tourmaline gemstone, multi-colored, electric. Photorealistic.`,
            
            'togarnet': `Transform the person in this image into garnet. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into garnet gemstone, deep red, protective. Photorealistic.`,
            
            'tospinel': `Transform the person in this image into spinel. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into spinel gemstone, various colors, misunderstood gem. Photorealistic.`,
            
            'tozircon': `Transform the person in this image into zircon. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into zircon gemstone, brilliant, earth's oldest. Photorealistic.`,
            
            'totanzanite': `Transform the person in this image into tanzanite. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into tanzanite gemstone, blue-violet, rare. Photorealistic.`,
            
            'toiolite': `Transform the person in this image into iolite. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into iolite gemstone, violet-blue, Viking's compass. Photorealistic.`,
            
            'tohematite': `Transform the person in this image into hematite. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into hematite gemstone, metallic gray, grounding. Photorealistic.`,
            
            'tomoonstone': `Transform the person in this image into moonstone. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into moonstone, glowing orb, lunar magic. Photorealistic.`,
            
            'tosunstone': `Transform the person in this image into sunstone. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into sunstone, golden glow, solar energy. Photorealistic.`,
            
            'tostarstone': `Transform the person in this image into starstone. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same.** Transform body into starstone, cosmic patterns, celestial. Photorealistic.`,
            
            'tocomet': `Transform the person in this image into a comet. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add comet-like appearance, tail of light, celestial body. Space background, photorealistic.`,
            
            'tometeor': `Transform the person in this image into a meteor. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add meteor-like appearance, shooting star, space rock. Photorealistic.`,
            
            'toasteroid': `Transform the person in this image into an asteroid. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add asteroid-like appearance, rocky body, asteroid belt. Photorealistic.`,
            
            'tonebula': `Transform the person in this image into a nebula. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add nebula-like appearance, cosmic cloud, star nursery. Colorful space, photorealistic.`,
            
            'togalaxy': `Transform the person in this image into a galaxy. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add galaxy-like appearance, spiral arms, billions of stars. Space background, photorealistic.`,
            
            'touniverse': `Transform the person in this image into the universe. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add cosmic appearance, universe aesthetic. Photorealistic.`,
            
            'toblackhole': `Transform the person in this image into a black hole. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add black hole appearance, gravitational singularity, event horizon. Photorealistic.`,
            
            'towormhole': `Transform the person in this image into a wormhole. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add wormhole appearance, space-time tunnel, interstellar travel. Photorealistic.`,
            
            'toportal': `Transform the person in this image into a portal. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add portal appearance, dimensional gateway, magical entrance. Photorealistic.`,
            
            'totime': `Transform the person in this image into a time traveler. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to futuristic time traveler outfit, add temporal displacement effects, clock motifs. Photorealistic.`,
            
            'tospace': `Transform the person in this image into a space explorer. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing to space suit, cosmic environment, zero gravity. Photorealistic.`,
            
            'todimension': `Transform the person in this image into a dimensional being. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add dimensional appearance, alternate reality effects. Photorealistic.`,
            
            'toparallel': `Transform the person in this image into a parallel universe version. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add parallel universe aesthetic, similar but different appearance. Photorealistic.`,
            
            'toalternate': `Transform the person in this image into an alternate self. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add alternate universe aesthetic, different choices made. Photorealistic.`,
            
            'tomultiverse': `Transform the person in this image into a multiverse traveler. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add multiverse appearance, infinite possibilities. Photorealistic.`,
            
            'tomegaverse': `Transform the person in this image into a megaverse being. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add megaverse appearance, beyond multiverse. Photorealistic.`,
            
            'tometaverse': `Transform the person in this image into a metaverse entity. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add metaverse appearance, digital universe. Photorealistic.`,
            
            'toomniverse': `Transform the person in this image into an omniverse being. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only add omniverse appearance, all of existence. Photorealistic.`
        };

        const prompt = promptMap[command] || `Transform the person in this image into ${command.substring(2).replace(/[A-Z]/g, ' $&').toLowerCase().trim()}. **CRITICAL: Keep the original face, facial features, hair, and head shape EXACTLY the same. Do not change the face at all.** Only change the clothing/appearance while preserving facial identity completely. High quality, photorealistic, detailed transformation.`;
        
        const encodedPrompt = encodeURIComponent(prompt);
        
        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(pixhostUrl)}&prompt=${encodedPrompt}`;
        
        const response = await axios.get(apiUrl, { 
            responseType: 'arraybuffer',
            timeout: 90000
        });
        
        const resultBuffer = Buffer.from(response.data, 'binary');
        
        await raiden.sendMessage(m.chat, { delete: replyMsg.key });
        
        await raiden.sendMessage(
            m.chat,
            { 
                image: resultBuffer, 
                caption: `𐔈⃘ ֹ ׅ 🍓 ֹ *${command.substring(2).toUpperCase()}* ֹ ׅ ୫` 
            },
            { quoted: m }
        );
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error(`${command} Error:`, e);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(`❌ Gagal memproses gambar!\n\nError: ${e.message || 'Unknown error'}`);
    }
    return;
};

export default handler;
