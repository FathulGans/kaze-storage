const pluginConfig = {
  name: 'toimg2',
  category: 'maker',
  command: ['toimg2'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, prefix, raiden, troli } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 let mediaSource = null;
 let downloadFn = null;
 const selfIsSticker = m.isSticker || 
 m.type === 'stickerMessage' || 
 m.message?.stickerMessage;
 const quotedIsSticker = m.quoted && (
 m.quoted.isSticker || 
 m.quoted.type === 'stickerMessage' || 
 m.quoted.mtype === 'stickerMessage' ||
 m.quoted.message?.stickerMessage
 );

 if (selfIsSticker) {
 mediaSource = 'self';
 downloadFn = m.download;
 } else if (quotedIsSticker) {
 mediaSource = 'quoted';
 downloadFn = m.quoted.download;
 }

 if (!mediaSource) {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ *ɢᴀɢᴀʟ*\n\n` +
 `> Tidak ada sticker yang terdeteksi!\n\n` +
 `*Cara penggunaan:*\n` +
 `> 1. Kirim sticker + caption \`${prefix}toimg\`\n` +
 `> 2. Reply sticker dengan \`${prefix}toimg\``);
 return;
 }

 const stickerMsg = mediaSource === 'self' 
 ? m.message?.stickerMessage 
 : m.quoted?.message?.stickerMessage;
 const isAnimated = stickerMsg?.isAnimated;

 if (isAnimated) {
 await raiden.sendMessage(m.chat, { react: { text: "⚠️", key: m.key } });
 Reply(`⚠️ *sᴛɪᴄᴋᴇʀ ᴀɴɪᴍᴀsɪ*\n\n` +
 `> Sticker ini adalah sticker animasi (GIF).\n` +
 `> Gunakan \`${prefix}tovideo\` untuk mengubahnya.`);
 return;
 }

 await raiden.sendMessage(m.chat, { react: { text: "🕕", key: m.key } });
 Reply(`🕕 *ᴍᴇᴍᴘʀᴏsᴇs...*\n\n> Mengubah sticker menjadi gambar...`);

 try {
 const buffer = await downloadFn();

 if (!buffer || buffer.length === 0) {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ *ɢᴀɢᴀʟ*\n\n` +
 `> Tidak dapat mengunduh sticker.\n` +
 `> Sticker mungkin sudah tidak tersedia.`);
 return;
 }

 if (buffer.length < 100) {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ *ꜰɪʟᴇ ᴋᴏʀᴜᴘ*\n\n` +
 `> File sticker tidak valid atau rusak.\n` +
 `> Coba kirim ulang stickernya.`);
 return;
 }

 await raiden.sendMessage(m.chat, {
 image: buffer,
 caption: `✅ *ʙᴇʀʜᴀsɪʟ*\n\n> Sticker berhasil diubah menjadi gambar!`
 }, { quoted: troli });

 } catch (error) {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ *ᴇʀʀᴏʀ*\n\n` +
 `> Terjadi kesalahan saat memproses.\n` +
 `> _${error.message}_`);
 }
};

export default handler;
