import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'sdm',
  category: 'maker',
  command: ['sdm'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, prefix, raiden, uploadKappaFile } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";

    if (!/image\//i.test(mime)) {
        return Reply(`Contoh: ${prefix}sdm (reply gambar)`)
    }

    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });

    const PROMPT_STYLE = `edit the uploaded photo with a dark glitch cyberpunk aesthetic, keep the same person and pose, convert the image to high contrast black and white silhouette style, add strong red background, add horizontal glitch distortion lines across the image, add a black censorship bar across the eyes, dramatic lighting, digital interference effect, hacker aesthetic, minimal detail, modern glitch poster style`;

    try {


        const userImageBuffer = await q.download();
        if (!userImageBuffer) throw new Error("Gagal mengunduh gambar.");

        const userImageUrl = await uploadKappaFile(userImageBuffer, mime || 'image/jpeg');
        if (!userImageUrl) throw new Error("Gagal upload gambar");

        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_STYLE)}`;

        const response = await axios.get(apiUrl, {
            responseType: "arraybuffer",
            timeout: 60000
        });

        const hasilBuffer = Buffer.from(response.data, "binary");

        await raiden.sendMessage(m.chat, {
            image: hasilBuffer,
            caption: `╭╼─┈───┈──⏣
├ ◦ *Style* : Glitch Cyberpunk
╰─╼𔕬─┈───┈──⏣`
        }, { quoted: m });

        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error('[SDM ERROR]', e);

        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

        let errorMsg = e.message || 'Gagal memproses gambar';
        if (e.code === 'ECONNABORTED') {
            errorMsg = 'Timeout, coba lagi nanti';
        }

        await Reply(
            `╭╼─┈───┈──⏣
├ ◦ *Status* : GAGAL
├ ◦ *Error* : ${errorMsg}
╰─╼𔕬─┈───┈──⏣`
        )
    }
};

export default handler;
