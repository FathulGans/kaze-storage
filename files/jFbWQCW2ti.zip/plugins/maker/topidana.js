import __form_data from 'form-data';
import axios from 'axios';
import fetch from 'node-fetch';

const pluginConfig = {
  name: 'topidana',
  category: 'maker',
  command: ['topidana'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isPremium, isVip, raiden } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip))
 return Reply(global.mess.limit);
 
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 
 if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));
 
 await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 await raiden.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });
 
 const PROMPT_PENJARA = `
 Ubah orang di foto ini menjadi tahanan di penjara Indonesia. 
 Gunakan pakaian tahanan khas Indonesia berwarna oranye dengan tulisan “TAHANAN” di dada.
 Tangan orang tersebut diborgol di depan tubuhnya, dan latar belakangnya adalah ruang penjara Indonesia 
 dengan jeruji besi dan pencahayaan realistis.
 Pastikan wajah tetap sama dan tidak diubah, hanya ubah pakaian dan suasananya agar tampak realistis seperti foto sungguhan.
 `;

 try {
 async function uploadUguu(buffer, filename = "file.jpg") {
 const FormData = __form_data;
 const form = new FormData();
 form.append("files[]", buffer, { filename });
 const res = await fetch("https://uguu.se/upload.php", { method: "POST", body: form });
 if (!res.ok) throw new Error(`Upload gagal: ${res.status}`);
 const json = await res.json();
 const url = json?.files?.[0]?.url;
 if (!url) throw new Error("Gagal mendapatkan URL dari Uguu");
 return url;
 }

 const userImageBuffer = await q.download();
 if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
 
 const userImageUrl = await uploadUguu(userImageBuffer);
 if (!userImageUrl) throw new Error("Gagal upload gambar ke server");
 
 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_PENJARA)}`;
 
 const response = await axios.get(apiUrl, { 
 responseType: "arraybuffer",
 timeout: 60000
 });
 
 const hasilBuffer = Buffer.from(response.data, "binary");
 
 await raiden.sendMessage(m.chat, { 
 image: hasilBuffer, 
 caption: mess.done
 }, { quoted: m });
 
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error('[TOPENJARA ERROR]', e);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
};

export default handler;
