import __child_process from 'child_process';
import __fs from 'fs';
import __os from 'os';
import __path from 'path';

const pluginConfig = {
  name: 'tolandscape',
  category: 'maker',
  command: ['tolandscape', 'landscape', 'topotret', 'potret'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, raiden, safeErr, text } = ctx;
 if (!isRegistered(m.sender) && !isVip) 
 return daftar(global.mess.verifikasi);

 if (checkLimit(m.sender, isPremium, isVip)) 
 return Reply(global.mess.limit);

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!/image|video/.test(mime)) {
 return Reply(
 `📐 *${global.botname.toUpperCase()} ADVANCED ROTATOR*\n\n` +
 `Format Penggunaan:\n` +
 `• *${prefix}tolandscape kiri* (Putar ke kiri)\n` +
 `• *${prefix}tolandscape kanan* (Putar ke kanan)\n` +
 `• *${prefix}topotret* (Putar ke posisi tegak)\n\n` +
 `_Note: Reply media Gambar atau Video!_`
 );
 }

 await raiden.sendMessage(m.chat, { react: { text: '🔄', key: m.key } });
 await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

 const { exec } = __child_process;
 const fs = __fs;
 const path = __path;
 const os = __os;

 const isVideo = /video/.test(mime);
 const isToLandscape = command.includes('landscape');
 const ext = isVideo ? "mp4" : "jpg";
 
 const tmpDir = os.tmpdir();
 const tmpIn = path.join(tmpDir, `rot_in_${Date.now()}`);
 const tmpOut = path.join(tmpDir, `rot_out_${Date.now()}.${ext}`);

 try {
 const buffer = await q.download();
 if (!buffer) throw new Error("Gagal mengambil data media.");
 fs.writeFileSync(tmpIn, buffer);

 let rotateFilter = "";
 let directionName = "";

 if (isToLandscape) {
 if (text.toLowerCase().includes('kiri') || text.toLowerCase().includes('left')) {
 rotateFilter = "transpose=2";
 directionName = "Kiri (90° CCW)";
 } else {
 rotateFilter = "transpose=1";
 directionName = "Kanan (90° CW)";
 }
 } else {
 rotateFilter = "transpose=1";
 directionName = "Potret (Vertical)";
 }

 let ffmpegCmd = "";
 if (isVideo) {
 ffmpegCmd = `ffmpeg -i ${tmpIn} -vf "${rotateFilter}" -c:v libx264 -preset veryfast -crf 22 -c:a copy -y ${tmpOut}`;
 } else {
 ffmpegCmd = `ffmpeg -i ${tmpIn} -vf "${rotateFilter}" -y ${tmpOut}`;
 }

 await new Promise((resolve, reject) => {
 exec(ffmpegCmd, (err) => {
 if (err) return reject(`FFmpeg Process Error: ${err.message}`);
 resolve();
 });
 });

 if (!fs.existsSync(tmpOut)) throw new Error("File output tidak terdeteksi.");
 const finalBuffer = fs.readFileSync(tmpOut);

 const caption = `✅ *ADVANCED ROTATION SUCCESS*\n\n` +
 `👤 *User:* @${m.sender.split('@')[0]}\n` +
 `⚙️ *Arah:* ${directionName}\n` +
 `📊 *Format:* ${ext.toUpperCase()}\n\n` +
 `_Media berhasil diputar secara permanen._`;

 if (isVideo) {
 await raiden.sendMessage(m.chat, { 
 video: finalBuffer, 
 caption: caption,
 mimetype: 'video/mp4',
 mentions: [m.sender]
 }, { quoted: m });
 } else {
 await raiden.sendMessage(m.chat, { 
 image: finalBuffer, 
 caption: caption,
 mimetype: 'image/jpeg',
 mentions: [m.sender]
 }, { quoted: m });
 }

 if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
 if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);

 await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 addLimit(m.sender, isPremium, isVip);

 } catch (err) {
 console.error('[ROTATION_SYSTEM_ERROR]', err);
 if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
 if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
 
 await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 return Reply(`❌ *SISTEM GAGAL MEROTASI*\n\n*Pesan Error:* \n\`\`\`${safeErr(err) || err}\`\`\``);
 }
};

export default handler;
