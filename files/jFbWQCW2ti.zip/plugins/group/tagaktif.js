import fs from 'fs';

const pluginConfig = {
  name: 'tagaktif',
  category: 'group',
  command: ['tagaktif', 'tagactive'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, safeErr } = ctx;
 if (!m.isGroup) return Reply('❌ Perintah ini hanya untuk grup!');
 if (!isVip && !m.isAdmin) return Reply('❌ Hanya admin yang bisa menggunakan perintah ini!');
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 
 await raiden.sendMessage(m.chat, { react: { text: "🔔", key: m.key } });
 
 try {
 const levelDBPath = './library/database/level.json';
 if (!fs.existsSync(levelDBPath)) {
 return Reply('❌ Belum ada data chat di grup ini!');
 }
 
 const levelDB = JSON.parse(fs.readFileSync(levelDBPath, 'utf8'));
 const groupData = levelDB[m.chat];
 
 if (!groupData || Object.keys(groupData).length === 0) {
 return Reply('❌ Belum ada data chat di grup ini!');
 }
 
 const groupMetadata = await raiden.groupMetadata(m.chat);
 const participants = groupMetadata.participants;
 
 const adminJids = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').flatMap(p => [p.id, p.jid, p.lid]).filter(Boolean);
 const botJid = raiden.user.id.split(':')[0] + '@s.whatsapp.net';
 
 let activeMembers = [];
 
 for (const [jid, data] of Object.entries(groupData)) {
 if (adminJids.includes(jid)) continue;
 if (jid === botJid || (raiden.user?.lid && jid === raiden.user.lid.split(':')[0].split('@')[0] + '@lid')) continue;
 
 let isStillMember = false;
 for (const p of participants) {
 if ([p.id, p.jid, p.lid].includes(jid)) {
 isStillMember = true;
 break;
 }
 }
 
 if (isStillMember && (data.messages || 0) > 0) {
 activeMembers.push({
 jid: jid,
 messages: data.messages || 0
 });
 }
 }
 
 activeMembers.sort((a, b) => b.messages - a.messages);
 
 const topActive = activeMembers.slice(0, 30);
 
 if (topActive.length === 0) {
 return Reply('❌ Tidak ada member aktif selain admin!');
 }
 
 const totalMessages = activeMembers.reduce((sum, u) => sum + u.messages, 0);
 
 let teks = m.text && m.text.length > 0 ? m.text : '📢 *PENGUMUMAN UNTUK MEMBER AKTIF* 📢\n\nTerima kasih atas partisipasi aktif kalian di grup ini! Pertahankan ya! 💪\n\n';
 
 if (m.text && m.text.length > 0) {
 teks = `${m.text}\n\n━━━━━━━━━━━━━━━━━━━━━\n`;
 }
 
 teks += `📊 *STATISTIK AKTIVITAS*\n`;
 teks += `└ 👥 Total member aktif: ${topActive.length}\n`;
 teks += `└ 💬 Total pesan: ${totalMessages.toLocaleString()}\n\n`;
 teks += `👥 *Daftar Member Aktif:*\n`;
 
 let mentions = [];
 for (let i = 0; i < topActive.length; i++) {
 const user = topActive[i];
 teks += `${i+1}. @${user.jid.split('@')[0]} (${user.messages.toLocaleString()} pesan)\n`;
 mentions.push(user.jid);
 }
 
 if (topActive.length < activeMembers.length) {
 teks += `\n📋 ...dan ${activeMembers.length - topActive.length} member aktif lainnya`;
 }
 
 teks += `\n\n━━━━━━━━━━━━━━━━━━━━━\n`;
 teks += `💬 *Ayo terus aktif dan jaga kekompakan grup!*`;
 
 await raiden.sendMessage(m.chat, {
 text: teks,
 mentions: mentions
 }, { quoted: m });
 
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error('[TAGAKTIF ERROR]', error);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${safeErr(error) || 'Coba lagi nanti'}`);
 }
};

export default handler;
