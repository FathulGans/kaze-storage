import fs from 'fs';

const pluginConfig = {
  name: 'schedule',
  category: 'group',
  command: ['schedule'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix, schedulePath } = ctx;
    if (!m.isGroup) return Reply('❌ Hanya untuk grup!');
    if (!isVip && !m.isAdmin) return Reply('❌ Hanya admin!');
    
    const subcmd = args[0]?.toLowerCase();
    
    if (subcmd === 'add' || subcmd === 'tambah') {
        if (args.length < 3) return Reply(`Format: ${prefix}schedule add <waktu> <pesan>\nContoh: ${prefix}schedule add 30m Selamat pagi semua!`);
        
        const timeStr = args[1];
        const message = args.slice(2).join(' ');
        
        let minutes = 0;
        if (timeStr.endsWith('m')) {
            minutes = parseInt(timeStr);
        } else if (timeStr.endsWith('h')) {
            minutes = parseInt(timeStr) * 60;
        } else if (timeStr.endsWith('d')) {
            minutes = parseInt(timeStr) * 60 * 24;
        } else {
            minutes = parseInt(timeStr);
        }
        
        if (isNaN(minutes) || minutes <= 0) return Reply('Waktu tidak valid!');
        
        const timestamp = Date.now() + (minutes * 60 * 1000);
        const data = JSON.parse(fs.readFileSync(schedulePath));
        
        data.messages.push({
            chat: m.chat,
            type: 'text',
            content: message,
            timestamp: timestamp,
            createdBy: m.sender,
            createdAt: Date.now(),
            scheduledFor: new Date(timestamp).toLocaleString('id-ID')
        });
        
        fs.writeFileSync(schedulePath, JSON.stringify(data, null, 2));
        
        Reply(`✅ Pesan terjadwal ditambahkan!\n⏰ Akan dikirim: ${new Date(timestamp).toLocaleString('id-ID')}\n📝 Pesan: ${message}`);
    }
    else if (subcmd === 'list' || subcmd === 'daftar') {
        const data = JSON.parse(fs.readFileSync(schedulePath));
        const groupMessages = data.messages.filter(msg => msg.chat === m.chat);
        
        if (groupMessages.length === 0) return Reply('📭 Tidak ada jadwal posting di grup ini.');
        
        let text = '📅 *JADWAL POSTING GRUP*\n\n';
        groupMessages.forEach((msg, i) => {
            const timeLeft = Math.max(0, Math.floor((msg.timestamp - Date.now()) / 60000));
            text += `*${i+1}. ${msg.type.toUpperCase()}*\n`;
            text += `⏰ ${msg.scheduledFor}\n`;
            text += `⏳ ${timeLeft} menit lagi\n`;
            text += `📝 ${msg.content.substring(0, 50)}${msg.content.length > 50 ? '...' : ''}\n`;
            text += `👤 @${msg.createdBy.split('@')[0]}\n\n`;
        });
        
        Reply(text);
    }
    else if (subcmd === 'delete' || subcmd === 'hapus') {
        if (!args[1]) return Reply(`Format: ${prefix}schedule delete <nomor>\nGunakan ${prefix}schedule list untuk melihat nomor.`);
        
        const index = parseInt(args[1]) - 1;
        const data = JSON.parse(fs.readFileSync(schedulePath));
        const groupMessages = data.messages.filter(msg => msg.chat === m.chat);
        
        if (isNaN(index) || index < 0 || index >= groupMessages.length) {
            return Reply('❌ Nomor tidak valid!');
        }
        
        const msgToDelete = groupMessages[index];
        data.messages = data.messages.filter(msg => 
            !(msg.chat === msgToDelete.chat && 
              msg.timestamp === msgToDelete.timestamp && 
              msg.content === msgToDelete.content)
        );
        
        fs.writeFileSync(schedulePath, JSON.stringify(data, null, 2));
        
        Reply(`✅ Jadwal posting #${index+1} dihapus!`);
    }
    else if (subcmd === 'clear' || subcmd === 'bersihkan') {
        const data = JSON.parse(fs.readFileSync(schedulePath));
        const beforeCount = data.messages.length;
        
        data.messages = data.messages.filter(msg => msg.chat !== m.chat);
        
        fs.writeFileSync(schedulePath, JSON.stringify(data, null, 2));
        
        Reply(`✅ ${beforeCount - data.messages.length} jadwal posting dibersihkan!`);
    }
    else {
        Reply(`📅 *FITUR JADWAL POSTING*\n\nGunakan:\n• ${prefix}schedule add <waktu> <pesan> - Tambah jadwal\n• ${prefix}schedule list - Lihat jadwal\n• ${prefix}schedule delete <no> - Hapus jadwal\n• ${prefix}schedule clear - Hapus semua\n\n*Format waktu:*\n30m = 30 menit\n2h = 2 jam\n1d = 1 hari`);
    }
    return;
};

export default handler;
