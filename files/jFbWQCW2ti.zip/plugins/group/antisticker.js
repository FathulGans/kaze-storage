const pluginConfig = {
  name: 'antisticker',
  category: 'group',
  command: ['antisticker'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antisticker = true;
        if (!global.db.groups[m.chat].antisticker) {
            global.db.groups[m.chat].antisticker = {};
        }
        Reply(`✅ *antisticker diaktifkan*\n\nBot akan  menghapus gambar yang dikirim oleh anggota grup.`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antisticker = false;
        if (global.db.groups[m.chat].antisticker) {
            global.db.groups[m.chat].antisticker = {};
        }
        Reply(`❌ *antisticker dimatikan*\n\nBot tidak akan menghapus gambar lagi`);
    } else {
        const status = global.db.groups[m.chat].antisticker ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTI STICKER*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antisticker on - untuk mengaktifkan\n• ${prefix}antisticker off - untuk mematikan`);
    }
    return;
};

export default handler;
