import __fs from 'fs';
import __path from 'path';

const pluginConfig = {
  name: 'delfilter',
  category: 'group',
  command: ['delfilter'],
};

const handler = async (m, ctx) => {
    let { args, isVip, raiden } = ctx;
    if (!m.isGroup) return m.reply(global.mess.group);
    
    const groupMetadata = await raiden.groupMetadata(m.chat).catch(e => {});
    const participants = groupMetadata?.participants || [];
    const userAdmin = participants.find(p => [p.id, p.jid, p.lid].includes(m.sender) || (m.senderLid && [p.id, p.lid].includes(m.senderLid)));
    const isAdmin = userAdmin?.admin === 'admin' || userAdmin?.admin === 'superadmin';

    if (!isAdmin && !isVip) return m.reply(global.mess.admin);
    if (!args[0]) return m.reply(`⚠️ Masukkan kata kunci yang mau dihapus!`);

    let keyword = args.join(' ').toLowerCase();
    const fs = __fs;
    const path = __path;
    const dirDB = './library/database';

    if (typeof global.db === 'undefined') global.db = {};
    if (typeof global.db.filter === 'undefined') global.db.filter = {};

    if (global.db.filter[m.chat] && global.db.filter[m.chat][keyword]) {
        let data = global.db.filter[m.chat][keyword];
        
        if (data.type !== 'text' && fs.existsSync(data.url)) {
            try { fs.unlinkSync(data.url); } catch(e) {}
        }

        delete global.db.filter[m.chat][keyword];
        
        if (!fs.existsSync(dirDB)) fs.mkdirSync(dirDB, { recursive: true });
        fs.writeFileSync(path.join(dirDB, 'filter_db.json'), JSON.stringify(global.db.filter, null, 2));

        m.reply(`✅ Filter *"${keyword}"* berhasil dihapus.`);
    } else {
        m.reply(`⚠️ Filter *"${keyword}"* tidak ditemukan.`);
    }
};

export default handler;
