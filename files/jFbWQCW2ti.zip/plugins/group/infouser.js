import akses from '../../src/lib/access.js';
import fs from 'fs';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'infouser',
  category: 'group',
  command: ['infouser', 'userinfo'],
};

const handler = async (m, ctx) => {
    let { Reply, areJidsSameUser, args, blacklist, botNumber, daftar, getUserMaxLimit, getWIBTime, hasPremiumAccess, isVip, loadPremiumAccess, loadStreaks, makeProgressBar, raiden, safeReadJSON } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);

    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);


    let users = []
    if (m.isGroup) {
        if (m.mentionedJid && m.mentionedJid.length) {
            users = m.mentionedJid.map(id => {
                if (id.endsWith('@lid')) {
                    let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
                    return p ? p.jid : null
                } else {
                    return id
                }
            }).filter(Boolean)
        } else if (args[0]) {
            users = [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net']
        } else {
            users = [m.sender]
        }
    } else {
        if (args[0]) {
            users = [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net']
        } else {
            users = [m.sender]
        }
    }

    if (users.length === 0) {
        return Reply('❌ Tidak ada user yang ditemukan!');
    }

    const targetJid = users[0];
    
    let targetName;
    if (m.isGroup) {
        const participant = m.metadata.participants.find(p => p.jid === targetJid || p.id === targetJid);
        if (participant) {
            targetName = participant.notify || participant.name || participant.id.split('@')[0];
        } else {
            targetName = targetJid.split('@')[0];
        }
    } else {
        try {
            const contact = await raiden.getContact(targetJid);
            targetName = contact.name || contact.notify || targetJid.split('@')[0];
        } catch {
            targetName = targetJid.split('@')[0];
        }
    }

    try {
        m.reply('⏳ Mengambil informasi user...');

        let profilePicture;
        try {
            profilePicture = await raiden.profilePictureUrl(targetJid, 'image');
        } catch (e) {
            profilePicture = global.defaultPP;
        }

        let userLevel = { level: 1, xp: 0, messages: 0 };
        let groupActivity = {};
        
        const levelDBPath = './library/database/level.json';
        if (fs.existsSync(levelDBPath)) {
            try {
                const levelDB = JSON.parse(fs.readFileSync(levelDBPath, 'utf8'));
                
                if (m.isGroup && levelDB[m.chat] && levelDB[m.chat][targetJid]) {
                    const userData = levelDB[m.chat][targetJid];
                    userLevel = {
                        level: userData.level || 1,
                        xp: userData.xp || 0,
                        messages: userData.messages || 0
                    };
                }
            } catch (e) { console.error(e); }
        }

        const isPremiumUser = tierAkses.isPrem(targetJid);
        const isBlacklisted = blacklist.some(b => areJidsSameUser(b, targetJid));
        const isRegisteredUser = global.isRegistered(targetJid);

        const usageDB = safeReadJSON('./library/database/limit_usage.json', []);
        const today = getWIBTime().toISOString().split('T')[0];
        const userUsage = usageDB.find(v => areJidsSameUser(v.jid, targetJid));
        const todayLimitUsed = userUsage && userUsage.date === today ? userUsage.count : 0;
        const maxLimit = getUserMaxLimit(targetJid);
        const limitPercentage = Math.min(100, Math.round((todayLimitUsed / maxLimit) * 100));

        const streakDB = loadStreaks();
        let streakInfo = '';
        const userStreaks = Object.entries(streakDB).filter(([key, data]) => {
            const [jid1, jid2] = key.split(':');
            return areJidsSameUser(jid1, targetJid) || areJidsSameUser(jid2, targetJid);
        });
        
        if (userStreaks.length > 0) {
            const totalStreaks = userStreaks.length;
            const highestStreak = Math.max(...userStreaks.map(([_, data]) => data.streak || 0));
            streakInfo = `\n├─ 🔥 *Streak:* ${totalStreaks} hubungan • Tertinggi: ${highestStreak} hari`;
        }

        const premiumAccess = hasPremiumAccess(targetJid);
        let premiumInfo = '';
        if (isPremiumUser || premiumAccess) {
            const premDB = JSON.parse(fs.readFileSync('./library/database/premium.json'));
            const premData = premDB.find(v => areJidsSameUser(v.jid, targetJid));
            
            if (premData) {
                const daysLeft = Math.max(0, Math.floor((premData.expired - Date.now()) / (24 * 60 * 60 * 1000)));
                premiumInfo = `\n├─ 👑 *Premium:* ✅ (${daysLeft} hari tersisa)`;
            } else if (premiumAccess) {
                const accessData = loadPremiumAccess();
                const userAccess = accessData.users[targetJid];
                if (userAccess) {
                    const daysLeft = Math.max(0, Math.floor((userAccess.expires - Date.now()) / (24 * 60 * 60 * 1000)));
                    premiumInfo = `\n├─ 👑 *Premium Access:* ✅ (${daysLeft} hari tersisa)`;
                }
            }
        }

        let afkInfo = '';
        try {
            const afkData = JSON.parse(fs.readFileSync('./library/database/afk.json', 'utf8') || '[]');
            const userAfk = afkData.find(v => areJidsSameUser(v.jid, targetJid));
            if (userAfk) {
                const duration = Date.now() - userAfk.time;
                const hours = Math.floor(duration / (1000 * 60 * 60));
                const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));
                afkInfo = `\n├─ 💤 *AFK:* ✅ (${hours}j ${minutes}m • ${userAfk.reason})`;
            }
        } catch (e) { console.error(e); }

        let tttInfo = '';
        if (global.tttGames && m.isGroup) {
            const gameKey = m.chat;
            const game = global.tttGames[gameKey];
            if (game && (areJidsSameUser(game.playerX, targetJid) || areJidsSameUser(game.playerO, targetJid))) {
                const role = areJidsSameUser(game.playerX, targetJid) ? '❌ (X)' : '⭕ (O)';
                const status = game.status === 'playing' ? 'Sedang bermain' : 'Menunggu';
                tttInfo = `\n├─ 🎮 *Tic Tac Toe:* ${role} • ${status}`;
            }
        }

        const userDBPath = './library/database/user.json';
        let registrationDate = 'Tidak terdaftar';
        if (fs.existsSync(userDBPath)) {
            try {
                const userDB = JSON.parse(fs.readFileSync(userDBPath, 'utf8'));
                const userData = userDB.find(v => areJidsSameUser(v.jid, targetJid));
                if (userData && userData.date) {
                    registrationDate = new Date(userData.date).toLocaleDateString('id-ID', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                }
            } catch (e) { console.error(e); }
        }

        const isOwnerUser = akses.isVip(targetJid, botNumber);
        const status = isOwnerUser ? (akses.isCreator(targetJid, botNumber) ? '👑 Creator' : '💎 VIP') : 
                      isPremiumUser || premiumAccess ? '⭐ Premium' : 
                      isRegisteredUser ? '✅ Terdaftar' : '❌ Belum terdaftar';

        const limitBar = makeProgressBar(todayLimitUsed, maxLimit, 10);

        const infoText = `╭─⬣「 *INFORMASI USER* 」⬣
│
├─ 📱 *Nomor:* ${targetJid.split('@')[0]}
├─ 🆔 *User ID:* ${targetJid}
├─ 🏷️ *Status:* ${status}
│
├─ 📊 *Statistik Grup Ini*
│  ├─ 📈 Level: ${userLevel.level}
│  ├─ ⭐ XP: ${userLevel.xp}
│  ├─ 💬 Pesan: ${userLevel.messages}
│  ├─ 📊 Limit: ${todayLimitUsed}/${maxLimit}
│  │  ${limitBar}
│  └─ 📈 Penggunaan: ${limitPercentage}%${premiumInfo}${streakInfo}${afkInfo}${tttInfo}
├─ 🛡️ *Keamanan*
│  ├─ ${isBlacklisted ? '🔴' : '🟢'} Blacklist: ${isBlacklisted ? 'Ya' : 'Tidak'}
│  └─ 📅 Terdaftar: ${registrationDate}
│
├─ 🔗 *Kontak*
│  ├─ 👤 Profile: wa.me/${targetJid.split('@')[0]}
│  └─ 📞 Chat: https://wa.me/${targetJid.split('@')[0]}?text=Halo
│
╰─⬣

_ⓘ Data diperbarui: ${new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}_`;

        await raiden.sendMessage(m.chat, {
            image: { url: profilePicture },
            caption: infoText,
            mentions: [targetJid]
        }, { quoted: m });

    } catch (error) {
        console.error('User Info Error:', error);
        Reply('❌ Gagal mendapatkan informasi user.');
    }
    return;
};

export default handler;
