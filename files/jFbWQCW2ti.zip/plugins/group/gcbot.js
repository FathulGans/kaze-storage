const pluginConfig = {
  name: 'gcbot',
  category: 'group',
  command: ['gcbot', 'grupbot'],
};

const handler = async (m, ctx) => {
    let { daftar, isVip, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    await raiden.sendMessage(m.chat, {
        text: `Silahkan bergabung ke grup official *${global.botname}* untuk mendapatkan informasi update terbaru dan berdiskusi bersama :\n\n${global.linkGrup}`
    }, { quoted: m })
};

export default handler;
