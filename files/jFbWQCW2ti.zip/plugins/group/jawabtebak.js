import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'jawabtebak',
  category: 'group',
  command: ['jawabtebak'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, text } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


    if (!global.tebakJawaban) return Reply("⚠️ Belum ada soal tebak! Ketik *.tebakkah* dulu!");
    let jawabanUser = text.toLowerCase().trim();
    if (jawabanUser === global.tebakJawaban) {
        Reply("✅ *Benar! Jawaban lo tepat!*");
    } else {
        Reply(`❌ *Salah!* Clue: Jawabannya ada ${global.tebakJawaban.length} huruf.`);
    }
};

export default handler;
