import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'truth',
  category: 'group',
  command: ['truth'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);
    
const truths = [
    'Apa hal paling memalukan yang pernah kamu lakukan?',
    'Siapa orang yang paling sering kamu kepoin di sosial media?',
    'Kapan terakhir kali kamu bohong dan tentang apa?',
    'Apa kebiasaan jorok yang kamu miliki?',
    'Pernahkah kamu naksir sahabat sendiri?',
    'Apa hal tergila yang pernah kamu lakukan demi cinta?',
    'Jika kamu bisa bertukar hidup dengan seseorang selama sehari, siapa orang itu?',
    'Apa fantasi terliarmu?',
    'Pernahkah kamu ngompol saat sudah besar?',
    'Apa aib terbesar yang kamu sembunyikan?'
];
const randomTruth = truths[Math.floor(Math.random() * truths.length)];
Reply(`*TRUTH* 🗣️\n\nJawab dengan jujur:\n*${randomTruth}*`);
};

export default handler;
