const pluginConfig = {
  name: 'autolevel',
  category: 'group',
  command: ['autolevel', 'autolv'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, saveMainGroups, text } = ctx;
    if (!m.isGroup) return Reply('❌ Perintah ini hanya untuk grup');
    if (!isVip && !m.isAdmin) return Reply('❌ Hanya admin grup');
    
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    if (!text) {
        const status = global.db.groups[m.chat].autolevel ? '✅ AKTIF' : '❌ NONAKTIF';
        
        return Reply(
            `╭─❏ 𝗔𝘂𝘁𝗼 𝗟𝗲𝘃𝗲𝗹 - 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀
│✧ Status : ${status}
╰──────────❏

╭─❏ *Penggunaan:*
│✧ autolevel on - Aktifkan
│✧ autolevel off - Nonaktifkan
│✧ autolevel set <pesan> - Custom pesan
╰──────────❏

╭─❏ *Variabel Set:*
│✧ @user - Mention user
│✧ @level - Level baru
│✧ @xp - XP saat ini
│✧ @xp_needed - XP dibutuhkan
│✧ @messages - Total pesan
│✧ @bar - Progress bar
╰──────────❏`
        );
    }
    
    const args = text.split(' ');
    const action = args[0].toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].autolevel = true;
        saveMainGroups();
        Reply('╭─❏ 𝗔𝘂𝘁𝗼 𝗟𝗲𝘃𝗲𝗹\n│✧ Status : ✅ AKTIF\n╰──────────❏');
    } 
    else if (action === 'off') {
        global.db.groups[m.chat].autolevel = false;
        saveMainGroups();
        Reply('╭─❏ 𝗔𝘂𝘁𝗼 𝗟𝗲𝘃𝗲𝗹\n│✧ Status : ❌ NONAKTIF\n╰──────────❏');
    }
    else if (action === 'set') {
        const customMessage = args.slice(1).join(' ');
        if (!customMessage) return Reply('❌ Masukkan pesan custom');
        
        global.db.groups[m.chat].autolevelMessage = customMessage;
        saveMainGroups();
        
        const preview = customMessage
            .replace(/@user/g, `@${m.sender.split('@')[0]}`)
            .replace(/@level/g, '10')
            .replace(/@xp/g, '1500')
            .replace(/@xp_needed/g, '500')
            .replace(/@messages/g, '100')
            .replace(/@bar/g, '[███████░░░░░░░░] 45%');
        
        Reply(`╭─❏ 𝗔𝘂𝘁𝗼 𝗟𝗲𝘃𝗲𝗹 - 𝗣𝗲𝘀𝗮𝗻 𝗖𝘂𝘀𝘁𝗼𝗺
│✧ Preview : 
${preview.split('\n').map(line => `│✧ ${line}`).join('\n')}
╰──────────❏`);
    }
    else {
        Reply('❌ Gunakan: on / off / set');
    }
    return;
};

export default handler;
