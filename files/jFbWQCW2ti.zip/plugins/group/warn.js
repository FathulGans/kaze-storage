import akses from '../../src/lib/access.js';

const pluginConfig = {
  name: 'warn',
  category: 'group',
  command: ['warn'],
};

const handler = async (m, ctx) => {
    let { Reply, botNumber, isVip, loadWarnDB, raiden, saveWarnDB, text } = ctx;
    if (!m.isGroup) return Reply('❌ Hanya grup');
    if (!m.isAdmin && !isVip) return Reply('❌ Admin only');
    if (!m.isBotAdmin) return Reply('❌ Bot bukan admin');
    
    let target;
    if (m.mentionedJid?.length > 0) {
        target = m.mentionedJid[0];
        if (target.endsWith('@lid')) {
            const participant = m.metadata.participants.find(p => p.id === target || p.lid === target);
            target = participant?.jid || target;
        }
    } else if (m.quoted) {
        target = m.quoted.sender;
    } else if (text) {
        const number = text.split(' ')[0].replace(/[^0-9]/g, '');
        if (number) target = number + '@s.whatsapp.net';
    }
    
    if (!target) return Reply('❌ Tag/reply user');
    
    const isTargetAdmin = m.metadata.participants.some(p => [p.id, p.jid, p.lid].includes(target) && p.admin);
    if (isTargetAdmin && !isVip) return Reply('❌ Tidak bisa warn admin');
    if (akses.isVip(target, botNumber)) return Reply('❌ Tidak bisa warn VIP');
    
    const warnDB = loadWarnDB();
    
    if (!warnDB[m.chat]) warnDB[m.chat] = {};
    if (!warnDB[m.chat][target]) {
        warnDB[m.chat][target] = {
            count: 0,
            warnings: [],
            name: m.metadata.participants.find(p => [p.id, p.jid, p.lid].includes(target))?.notify || target.split('@')[0]
        };
    }
    
    const userData = warnDB[m.chat][target];
    userData.count += 1;
    userData.warnings.push({
        timestamp: Date.now(),
        warnedBy: m.sender,
        warnedByName: m.pushName || m.sender.split('@')[0],
        reason: text.split(' ').slice(1).join(' ') || 'Tidak ada alasan'
    });
    
    saveWarnDB(warnDB);
    
    const maxWarn = 4;
    if (userData.count >= maxWarn) {
        await Reply(`⚠️ ${target.split('@')[0]} ${maxWarn} warn, dikeluarkan`, [target]);
        await raiden.groupParticipantsUpdate(m.chat, [target], 'remove');
        delete warnDB[m.chat][target];
        saveWarnDB(warnDB);
    } else {
        await Reply(`⚠️ Warn ${userData.count}/${maxWarn} untuk ${target.split('@')[0]}`, [target]);
    }
};

export default handler;
