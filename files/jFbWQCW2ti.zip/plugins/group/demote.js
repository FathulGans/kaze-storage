const pluginConfig = {
  name: 'demote',
  category: 'group',
  command: ['demote', 'promote'],
};

const handler = async (m, ctx) => {
    let { Reply, command, example, isVip, raiden, text } = ctx;
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isVip && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await raiden.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await raiden.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return Reply(example("@tag/6285###"))
}
};

export default handler;
