import { sleep } from '../../library/function.js';

const pluginConfig = {
  name: 'siderkick',
  category: 'group',
  command: ['siderkick', 'kicksider'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden } = ctx;
    if (!m.isGroup) return Reply('Perintah ini hanya untuk grup');
    if (!isVip && !m.isAdmin) return Reply('Hanya admin grup');
    if (!m.isBotAdmin) return Reply('Bot bukan admin');
    
    try {
        const groupMetadata = await raiden.groupMetadata(m.chat);
        const participants = groupMetadata.participants;
        
        const sevenDays = 86400000 * 7;
        const now = Date.now();
        
        let kickList = [];
        
        for (let participant of participants) {
            let memberJid = participant.jid || participant.id;
            let isAdmin = participant.admin !== null;
            
            if (isAdmin) continue;
            
            if (memberJid.endsWith('@lid')) {
                let realParticipant = participants.find(p => p.id === memberJid);
                if (realParticipant && realParticipant.jid) {
                    memberJid = realParticipant.jid;
                } else {
                    memberJid = globalThis.lidKeNomor(memberJid);
                }
            }
            
            if (!memberJid.endsWith('@s.whatsapp.net')) {
                memberJid = memberJid + '@s.whatsapp.net';
            }
            
            if (!global.db.groups[m.chat]) global.db.groups[m.chat] = { users: {} };
            if (!global.db.groups[m.chat].users) global.db.groups[m.chat].users = {};
            
            let userData = global.db.groups[m.chat].users[memberJid];
            
            if (!userData) {
                global.db.groups[m.chat].users[memberJid] = {
                    messages: 0,
                    lastMessage: 0,
                    name: participant.notify || memberJid.split('@')[0],
                    firstSeen: now
                };
                userData = global.db.groups[m.chat].users[memberJid];
            }
            
            let shouldKick = false;
            let reason = '';
            
            if (userData.lastMessage > 0) {
                let inactiveDays = Math.floor((now - userData.lastMessage) / 86400000);
                if (inactiveDays > 7) {
                    shouldKick = true;
                    reason = `${inactiveDays} hari tidak chat`;
                }
            } else {
                let memberAge = Math.floor((now - userData.firstSeen) / 86400000);
                if (memberAge > 7) {
                    shouldKick = true;
                    reason = `${memberAge} hari belum pernah chat`;
                }
            }
            
            if (shouldKick) {
                kickList.push({
                    jid: memberJid,
                    name: userData.name || participant.notify || memberJid.split('@')[0],
                    reason: reason
                });
            }
        }
        
        if (kickList.length === 0) {
            return Reply('Tidak ada member yang perlu dikick');
        }
        
        let warningText = `⚠️ *KICK WARNING*\n\n`;
        warningText += `${kickList.length} member akan dikick:\n\n`;
        
        let mentionJids = [];
        for (let i = 0; i < Math.min(kickList.length, 10); i++) {
            let member = kickList[i];
            warningText += `${i+1}. @${member.jid.split('@')[0]}\n   ${member.name}\n   ${member.reason}\n\n`;
            mentionJids.push(member.jid);
        }
        
        if (kickList.length > 10) {
            warningText += `📋 +${kickList.length - 10} member lainnya\n\n`;
        }
        
        warningText += `⏳ Proses mulai dalam 5 detik...`;
        
        await raiden.sendMessage(m.chat, {
            text: warningText,
            mentions: mentionJids
        }, { quoted: m });
        
        await sleep(5000);
        
        let success = 0;
        let failed = 0;
        
        for (let member of kickList) {
            try {
                await raiden.groupParticipantsUpdate(m.chat, [member.jid], 'remove');
                success++;
                await sleep(1200);
            } catch (e) {
                failed++;
            }
        }
        
        let resultMsg = `✅ *KICK COMPLETE*\n\n`;
        resultMsg += `• Berhasil: ${success}\n`;
        resultMsg += `• Gagal: ${failed}\n`;
        resultMsg += `• Total: ${kickList.length}`;
        
        Reply(resultMsg);
        
    } catch (error) {
        console.error('Siderkick error:', error);
        Reply('Gagal melakukan kick');
    }
    return;
};

export default handler;
