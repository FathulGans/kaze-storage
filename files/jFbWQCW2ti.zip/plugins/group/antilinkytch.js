const pluginConfig = {
  name: 'antilinkytch',
  category: 'group',
  command: ['antilinkytch'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antilinkytch = true;
        if (!global.db.groups[m.chat].antilinkytch) {
            global.db.groups[m.chat].antilinkytch = {};
        }
        Reply(`✅ *MODE ANTI LINK CHANNEL YOUTUBE DIAKTIFKAN*`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antilinkytch = false;
        if (global.db.groups[m.chat].antilinkytch) {
            global.db.groups[m.chat].antilinkytch = {};
        }
        Reply(`❌ *MODE ANTI LINK CHANNEL YOUTUBE DIMATIKAN*`);
    } else {
        const status = global.db.groups[m.chat].antilinkytch ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTI LINK CHANNEL YOUTUBE MODE*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antilinkytch on - untuk mengaktifkan\n• ${prefix}antilinkytch off - untuk mematikan`);
    }
    return;
};

export default handler;
