import { sleep } from '../../library/function.js';

const pluginConfig = {
  name: 'kick',
  category: 'group',
  command: ['kick', 'kik'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, raiden, text } = ctx;
    if (!m.isGroup) return Reply(mess.group);
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    if (!m.isBotAdmin) return Reply(mess.botAdmin);
    let users = []
    if (m.isGroup) {
        if (m.mentionedJid.length) {
            users = m.mentionedJid.map(id => {
                if (id.endsWith('@lid')) {
                    let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
                    return p ? p.jid : null
                } else {
                    return id
                }
            }).filter(Boolean)
        } else if (m.quoted) {
            users = [m.quoted.sender]
        } else if (text) {
            users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net']
        }
    }

    if (!users.length) return Reply(`❌ *Tag, reply, atau tulis nomor yang mau dikick!*\n\nContoh:\n${prefix}kick @tag\n${prefix}kick 628xxxx\n${prefix}kick (reply pesan orang)`);
    for (let user of users) {
        let onWa = await raiden.onWhatsApp(user.split("@")[0])
        if (!onWa?.length) {
            Reply(`⚠️ Nomor *${user.split("@")[0]}* tidak terdaftar di WhatsApp!`)
            continue
        }
        try {
            await raiden.groupParticipantsUpdate(m.chat, [user], 'remove')
            await sleep(800)
            await Reply(`✅ Berhasil mengeluarkan *@${user.split('@')[0]}*`, { mentions: [user] })
        } catch (e) {
            Reply(`❌ Gagal mengeluarkan *@${user.split('@')[0]}*`, { mentions: [user] })
        }
    }
};

export default handler;
