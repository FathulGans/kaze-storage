const pluginConfig = {
  name: 'listnama',
  category: 'group',
  command: ['listnama'],
};

const handler = async (m, ctx) => {
    let { Reply, prefix, raiden, text, troli } = ctx;
 if (!m.isGroup) return Reply('❌ Hanya untuk grup!')
 if (!text) return Reply(`❌ Masukkan kata kunci nomor!\nContoh: *${prefix}listnama 6281*`)
 const _kw = text.toLowerCase()
 const _ptcps = m.metadata?.participants || []
 const _matches = _ptcps.filter(p => (p.jid || (p.id || '')).split('@')[0].includes(_kw))
 if (!_matches.length) return Reply(`❌ Tidak ada member dengan kata kunci *"${text}"*.`)
 const _mentions = _matches.map(p => p.jid || globalThis.lidKeNomor(p.id || '')).filter(Boolean)
 const _list = _matches.map((p, i) => `${i+1}. @${(p.jid || p.id || '').split('@')[0]}`).join('\n')
 await raiden.sendMessage(m.chat, {
 text: `🔍 *Hasil Pencarian: "${text}"*\n\nDitemukan ${_matches.length} member:\n\n${_list}`,
 mentions: _mentions
 }, { quoted: troli })
};

export default handler;
