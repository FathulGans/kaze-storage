const pluginConfig = {
  name: 'kudetagc',
  category: 'group',
  command: ['kudetagc'],
};

const handler = async (m, ctx) => {
    let { Reply, isSenderPartner, isVip, raiden } = ctx;
if (!m.isGroup) return Reply(global.mess.group||'⚠️ Hanya di grup!');
if (!m.isBotAdmin) return Reply(global.mess.botAdmin);
if (!isVip && !isSenderPartner) return Reply(global.mess.vip||'❌ Hanya owner bot!');
try {
    const _kdP = await raiden.groupMetadata(m.chat).then(g=>g.participants);
    const _kdA = _kdP.filter(p=>p.admin==='admin').map(p=>p.id);
    if (!_kdA.length) return Reply('❌ Tidak ada admin yang bisa di-demote.');
    await raiden.groupParticipantsUpdate(m.chat,_kdA,'demote');
    await raiden.groupParticipantsUpdate(m.chat,[raiden.user.id],'promote').catch(()=>{});
    Reply(`✅ *Kudeta grup berhasil!*\n\n👑 Bot jadi satu-satunya admin.\n🔻 ${_kdA.length} admin lama di-demote.`);
} catch(e) { Reply('❌ Gagal kudeta: '+e.message); }
};

export default handler;
