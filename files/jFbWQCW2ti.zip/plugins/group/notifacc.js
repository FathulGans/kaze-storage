const pluginConfig = {
  name: 'notifacc',
  category: 'group',
  command: ['notifacc'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip } = ctx;
if (!m.isGroup) return Reply(global.mess.group||'⚠️ Hanya di grup!');
if (!isVip && !m.isAdmin) return Reply(global.mess.admin);
if (!global.db.groups) global.db.groups = {};
if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
global.db.groups[m.chat]['notifacc'] = !global.db.groups[m.chat]['notifacc'];
const _naOn = global.db.groups[m.chat]['notifacc'];
Reply(`🔔 *Notif Acc Member ${_naOn?'ON ✅':'OFF ❌'}*\n\n${_naOn?'Bot akan notif saat ada member baru masuk.':'Notifikasi masuk grup dinonaktifkan.'}`);
};

export default handler;
