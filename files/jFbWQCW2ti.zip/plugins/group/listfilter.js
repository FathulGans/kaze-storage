const pluginConfig = {
  name: 'listfilter',
  category: 'group',
  command: ['listfilter'],
};

const handler = async (m, ctx) => {
    let { generateWAMessageFromContent, proto, raiden } = ctx;
    if (!m.isGroup) return m.reply(global.mess.group);

    if (typeof global.db === 'undefined') global.db = {};
    if (typeof global.db.filter === 'undefined') global.db.filter = {};

    if (!global.db.filter[m.chat] || Object.keys(global.db.filter[m.chat]).length === 0) {
        return m.reply('⚠️ Belum ada filter di grup ini.');
    }

    let filters = global.db.filter[m.chat];
    let rows = [];

    for (let keyword in filters) {
        let data = filters[keyword];
        let icon = data.type === 'text' ? '📝'
            : data.type === 'image' ? '🖼️'
            : data.type === 'video' ? '🎥'
            : data.type === 'sticker' ? '🎨'
            : data.type === 'audio' ? '🎵' : '📁';

        rows.push({
            title: keyword.toUpperCase(),
            description: `${icon} Tipe: ${data.type.toUpperCase()}`,
            id: `filter_${keyword}`
        });
    }

    rows = rows.slice(0, 24);

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `Halo King! Ada *${Object.keys(filters).length}* filter aktif di grup ini.\nPilih keyword di bawah untuk melihat isinya.`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `© ${global.botname}`
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '📋 Pilih Filter',
                                    sections: [
                                        {
                                            title: '🗂️ DAFTAR KEYWORD',
                                            highlight_label: '',
                                            rows: rows
                                        }
                                    ]
                                })
                            }
                        ],
                        messageParamsJson: ''
                    })
                })
            }
        }
    }, {
        userJid: raiden.user.id,
        quoted: m
    });

    await raiden.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

export default handler;
