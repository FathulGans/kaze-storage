const pluginConfig = {
  name: 'swgc',
  category: 'group',
  command: ['swgc'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden, text } = ctx;
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    const caption = (text || "").trim();
    const jid = m.chat;

    if (!m.isGroup) return Reply(mess.group);
    if (!/image|video|audio/.test(mime) && !caption) return Reply(example("dengan reply media"));

    try {
        await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        const { sendGroupStatus } = (await import('../../src/lib/group_status.js')).default;
        const isi = /image/.test(mime) ? { image: await quoted.download(), caption }
            : /video/.test(mime) ? { video: await quoted.download(), caption }
            : /audio/.test(mime) ? { audio: await quoted.download() }
            : { text: caption };
        await sendGroupStatus(raiden, jid, isi);
        Reply(mess.done);
    } catch (e) {
        console.error("swgc", e);
        Reply(mess.error);
    }
};

export default handler;
