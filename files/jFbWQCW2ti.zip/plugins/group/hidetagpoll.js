import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'hidetagpoll',
  category: 'group',
  command: ['hidetagpoll'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, text } = ctx;
if (!isRegistered(m.sender) && !isVip)
return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);  
  
  
if (!m.isGroup) return Reply(mess.group);  
if (!isVip && !m.isAdmin) return Reply(mess.admin);  
  
const members = m.metadata.participants.map(v => v.id);  
  
if (!text) return Reply("❌ Format salah!\n\nGunakan: .hidetagpoll pertanyaan|jawaban1,jawaban2,jawaban3\n\n\nContoh:\n.hidetagpoll Menu makan siang?|Nasi Goreng,Mie Ayam,Bakso,Soto\n.hidetagpoll Pilihan warna?|Merah,Biru,Hijau,Kuning");  
  
const parts = text.split("|");  
if (parts.length < 2) return Reply("❌ Format salah! Pisahkan pertanyaan dan jawaban dengan tanda '|'\n\nContoh: .hidetagpoll Pilihan warna?|Merah,Biru,Hijau");  
  
const question = parts[0].trim();  
const answersRaw = parts[1].trim();  
  
if (!question) return Reply("❌ Pertanyaan tidak boleh kosong!");  
if (!answersRaw) return Reply("❌ Jawaban tidak boleh kosong!");  
  
const pollOptions = answersRaw.split(",").map(opt => opt.trim()).filter(opt => opt);  
  
if (pollOptions.length < 2) return Reply("❌ Minimal 2 jawaban untuk poll!");  
if (pollOptions.length > 12) return Reply("❌ Maksimal 12 jawaban untuk poll!");  
  
try {  
    await raiden.sendMessage(m.chat, {   
        text: `📊 *POLLING HIDETAG*\n\n${question}\n\nTotal: ${members.length} member`,   
        mentions: members   
    });  
      
    setTimeout(async () => {  
        await raiden.sendMessage(m.chat, {  
            poll: {  
                name: `📊 ${question.substring(0, 60)}${question.length > 60 ? '...' : ''}`,  
                values: pollOptions,  
                selectableCount: 1  
            }  
        });  
    }, 1500);  
      
} catch (e) {  
    console.error("Hidetagpoll Error:", e);  
    Reply("❌ Gagal membuat poll. Pastikan format benar!");  
}
};

export default handler;
