import __axios from 'axios';

const pluginConfig = {
  name: 'ff',
  category: 'group',
  command: ['ff'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, text } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 let target = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : m.sender);
 if (target.endsWith('@lid') && m.metadata?.participants) {
 let p = m.metadata.participants.find(x => x.lid === target || x.id === target);
 if (p) target = p.jid;
 }

 const axios = __axios;
 const GROQ_API_KEY = global.groqApiKey;

 if (!text) {
 return Reply(`╭─❏ *FREE FIRE*\n│ Silakan masukkan nama karakter FF!\n│\n│ ▸ *Contoh:* ${prefix + command} Chrono\n╰──────────❏`);
 }

 await m.react('🔍');

 try {
 const prompt = `
Act as a Professional Garena Free Fire (FF) Analyst. 
Provide detailed information about the Character: "${text}".
Use Indonesian Language.

STRICT FORMAT (WAJIB PAKAI BOX STYLE INI):
╭─❏ *CHARACTER OBSERVATION*
│ 👤 *NAME:* [Karakter Name]
│ 🧬 *ABILITY:* [Ability Name]
│ ⚙️ *TYPE:* [Active/Passive]
│ ✨ *SPECIALTY:* [Specialty]
│ 🚻 *GENDER:* [Gender]
│
│ 📝 *DESCRIPTION:*
│ [Tulis 2-3 kalimat penjelasan kemampuan & background]
╰──────────❏
Powered by ${global.botname}`;

 const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
 model: "llama-3.3-70b-versatile",
 messages: [
 { role: "system", content: "You are an expert Free Fire analyst. Always reply using the box style format." },
 { role: "user", content: prompt }
 ],
 temperature: 0.3
 }, {
 headers: { 
 'Authorization': `Bearer ${GROQ_API_KEY}`, 
 'Content-Type': 'application/json' 
 },
 timeout: 30000
 });

 const result = response.data.choices[0]?.message?.content;
 if (!result) throw new Error("Karakter tidak ditemukan.");

 await m.react('🔫');
 await Reply(result.trim());

 } catch (error) {
 console.error(error);
 await m.react('❌');
 Reply(`╭─❏ *ERROR INFO*\n│ Karakter "${text}" tidak ditemukan.\n│ Silakan coba nama karakter lain.\n╰──────────❏`);
 }
};

export default handler;
