const pluginConfig = {
  name: 'setppgcpanjang',
  category: 'group',
  command: ['setppgcpanjang', 'setppgclong'],
};

const handler = async (m, ctx) => {
    let { Reply, S_WHATSAPP_NET, command, isVip, jimp, prefix, raiden } = ctx;
    if (!m.isGroup) return Reply('❌ Command ini hanya untuk grup!')
    if (!isVip && !m.isAdmin) return Reply('❌ Hanya admin atau owner yang bisa!')
    if (!m.isBotAdmin) return Reply('❌ Bot harus admin untuk ubah foto grup!')
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''
    if ((/image/g.test(mime) && !/webp/g.test(mime))) {
        async function pepe(media) {
            const jim2 = await (await jimp()).read(media)
            const min = jim2.getWidth()
            const max = jim2.getHeight()
            const cropped = jim2.crop(0, 0, min, max)
            return {
                img: await cropped.scaleToFit(720, 720).getBufferAsync((await jimp()).MIME_JPEG),
                preview: await cropped.normalize().getBufferAsync((await jimp()).MIME_JPEG)
            }
        }
        try {
            await Reply('⏳ Mengubah foto grup...')
            let media = await q.download()
            let { img } = await pepe(media)
            await raiden.query({
                tag: 'iq',
                attrs: {
                    target: m.chat,
                    to: S_WHATSAPP_NET,
                    type: 'set',
                    xmlns: 'w:profile:picture'
                },
                content: [
                    {
                        tag: 'picture',
                        attrs: { type: 'image' },
                        content: img
                    }
                ]
            })
            Reply(`✅ sukses mengganti profil grup secara penuh bang`)
        } catch (e) {
            console.log(e)
            Reply('❌ Gagal mengubah foto grup.')
        }
    } else {
        Reply(`\nKirim/reply gambar dengan caption *${prefix + command}*`)
    }
};

export default handler;
