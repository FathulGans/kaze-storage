import tictactoe from '../../src/lib/tictactoe.js';

const pluginConfig = {
  name: 'tttclean',
  category: 'group',
  command: ['tttclean', 'tttcleanup'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip } = ctx;
    if (!isVip) return Reply('Command owner only');
    const result = await tictactoe.handleCleanup(Reply);
    if (result) Reply(result);
    return;
};

export default handler;
