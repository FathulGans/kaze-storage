const pluginConfig = {
  name: 'antilinkall',
  category: 'group',
  command: ['antilinkall'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, saveMainGroups, text } = ctx;
    if (!m.isGroup) return
    if (!m.isAdmin && !isVip) return Reply('❌ Hanya admin grup!');
    
    if (!text) {
        const isActiveDelete = global.db.groups[m.chat]?.antilinkalldelete || false;
        const isActiveKick = global.db.groups[m.chat]?.antilinkallkick || false;
        
        let statusDelete = isActiveDelete ? '✅ AKTIF' : '❌ NONAKTIF';
        let statusKick = isActiveKick ? '✅ AKTIF' : '❌ NONAKTIF';
        
        return Reply(`🔧 *ANTI LINK ALL SETTINGS*\n\nDelete Mode: ${statusDelete}\nKick Mode: ${statusKick}\n\nPilihan:\n• delete - hanya hapus pesan\n• kick - hapus pesan + kick user\n\nContoh:\n${prefix}antilinkall delete on\n${prefix}antilinkall kick off`);
    }
    
    const argsText = text.toLowerCase().split(' ');
    if (argsText.length < 2) return Reply(`Format: ${prefix}antilinkall <delete/kick> <on/off>`);
    
    const mode = argsText[0];
    const action = argsText[1];
    
    if (mode !== 'delete' && mode !== 'kick') {
        return Reply('❌ Mode tidak valid! Pilih: delete atau kick');
    }
    
    if (action !== 'on' && action !== 'off') {
        return Reply('❌ Action tidak valid! Pilih: on atau off');
    }
    
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    if (mode === 'delete') {
        global.db.groups[m.chat].antilinkalldelete = (action === 'on');
        saveMainGroups();
        Reply(`✅ Anti Link All delete ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
    } else if (mode === 'kick') {
        global.db.groups[m.chat].antilinkallkick = (action === 'on');
        saveMainGroups();
        Reply(`✅ Anti Link All kick ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
    }
    return;
};

export default handler;
