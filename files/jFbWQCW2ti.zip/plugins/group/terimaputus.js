import fs from 'fs';

const pluginConfig = {
  name: 'terimaputus',
  category: 'group',
  command: ['terimaputus'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, raiden } = ctx;
    if (!m.isGroup) return Reply(global.mess.group)
    if (!isRegistered(m.sender)) return daftar(global.mess.verifikasi)

    const sender = m.sender
    if (!global.putusProposals) return Reply('❌ Tidak ada permintaan putus untukmu.')

    let matchedProposal = null
    let proposalId = null

    const normalize = (jid) => globalThis.lidKeNomor(jid)

    for (const id in global.putusProposals) {
        const proposal = global.putusProposals[id]
        if (normalize(proposal.target) === normalize(sender)) {
            matchedProposal = proposal
            proposalId = id
            break
        }
    }

    if (!matchedProposal) return Reply('❌ Tidak ada permintaan putus untukmu.')

    const couplesPath = './library/database/couples.json'
    const couplesData = JSON.parse(fs.readFileSync(couplesPath))
    
    let targetKey = null
    for (const key in couplesData) {
        const data = couplesData[key]
        if ((normalize(data.user1) === normalize(matchedProposal.requester) && normalize(data.user2) === normalize(sender)) ||
            (normalize(data.user2) === normalize(matchedProposal.requester) && normalize(data.user1) === normalize(sender))) {
            targetKey = key
            break
        }
    }

    if (targetKey) {
        delete couplesData[targetKey]
        fs.writeFileSync(couplesPath, JSON.stringify(couplesData, null, 2))
    }

    delete global.putusProposals[proposalId]

    await raiden.sendMessage(m.chat, {
        text: `🥀 *HUBUNGAN BERAKHIR* 🥀\n\nHubungan antara @${matchedProposal.requester.split('@')[0]} dan @${sender.split('@')[0]} telah resmi berakhir.\n\nSemoga kalian menemukan kebahagiaan masing-masing.`,
        mentions: [matchedProposal.requester, sender]
    }, { quoted: m })
};

export default handler;
