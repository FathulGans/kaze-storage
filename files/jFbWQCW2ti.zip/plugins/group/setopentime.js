const pluginConfig = {
  name: 'setopentime',
  category: 'group',
  command: ['setopentime'],
};

const handler = async (m, ctx) => {
    let { Reply, botNumber, example, isVip, loadJadwal, raiden, saveJadwal, text } = ctx;
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isVip) return Reply(mess.admin);
    if (!m.isBotAdmin) return Reply('❌ Bot harus menjadi admin agar bisa membuka/menutup grup!');
    
    if (!text) return Reply(example("05:00"));
    
    let [openJam, openPesan] = text.split('|');
    openJam = openJam.trim();
    
    if (!/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/.test(openJam)) return Reply("❌ Format jam salah! Gunakan HH:MM (contoh: 05:00)");
    
    let dbJadwal2 = loadJadwal();
    if (!dbJadwal2[m.chat]) dbJadwal2[m.chat] = {};
    
    dbJadwal2[m.chat].openTime = openJam;
    dbJadwal2[m.chat].bot = String(botNumber || '').split('@')[0];
    if (openPesan) dbJadwal2[m.chat].openMessage = openPesan.trim();
    delete dbJadwal2[m.chat].lastOpen;
    delete dbJadwal2[m.chat].lastOpenTime;
    
    saveJadwal(dbJadwal2);
    try {
        const { refreshAllTimers } = (await import('../../src/lib/autogc.js')).default;
        refreshAllTimers(raiden);
    } catch (e) { console.error(e); }
    
    Reply(`✅ Open Time diset jam ${openJam} WIB`);
};

export default handler;
