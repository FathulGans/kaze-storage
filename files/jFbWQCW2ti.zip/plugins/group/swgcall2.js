import fs from 'fs';

const pluginConfig = {
  name: 'swgcall2',
  category: 'group',
  command: ['swgcall2', 'statusgrupall'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, raiden, text } = ctx;
 if (!isVip) return Reply(global.mess.vip);

 if (!global.swgcBufferV2) global.swgcBufferV2 = new Map();

 if (text === '--all' || text === '--allcf') {
 const isCF = text === '--allcf';
 const data = global.swgcBufferV2.get(m.sender);
 if (!data) return Reply("⚠️ *Data Expired:* Silakan kirim ulang media.");
 
 await raiden.sendMessage(m.chat, { react: { text: '🚀', key: m.key } });
 const groups = await raiden.groupFetchAllParticipating();
 const groupIds = Object.keys(groups);
 let count = 0;

 for (let id of groupIds) {
 try {
 await (await import('../../src/lib/group_status.js')).default.sendGroupStatus(raiden, id, data.content, { cf: isCF });
 count++;
 await new Promise(r => setTimeout(r, 4000));
 } catch (e) { console.error(e); }
 }
 global.swgcBufferV2.delete(m.sender);
 return Reply(`✅ *Broadcast ${isCF ? 'Close Friend' : ''} Selesai:* Total ${count} grup.`);
 }

 if (text.startsWith('--select|')) {
 const [_, targetId, mode] = text.split('|');
 const isCF = mode === 'cf';
 const data = global.swgcBufferV2.get(m.sender);
 if (!data) return Reply("⚠️ *Data Expired.*");

 try {
 await (await import('../../src/lib/group_status.js')).default.sendGroupStatus(raiden, targetId, data.content, { cf: isCF });
 return Reply(`✅ *Berhasil:* Story terkirim ke grup pilihan.`);
 } catch (e) { return Reply(`❌ Gagal: ${e.message}`); }
 }

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 let payload = {};

 if (/image/.test(mime)) {
 payload.image = await q.download();
 payload.caption = text || "";
 } else if (/video/.test(mime)) {
 payload.video = await q.download();
 payload.caption = text || "";
 } else if (/audio/.test(mime)) {
 payload.audio = await q.download();
 payload.mimetype = "audio/mp4";
 payload.ptt = true;
 } else if (text) {
 payload.text = text;
 } else {
 return Reply(`🚀 *GLOBAL STORY ENGINE V2*\n\nReply media atau masukkan teks untuk memulai.`);
 }

 global.swgcBufferV2.set(m.sender, { content: payload });

 const groups = await raiden.groupFetchAllParticipating();
 const groupList = Object.entries(groups);
 
 const rows = groupList.map(([id, meta]) => ({
 title: meta.subject || "Grup",
 description: `ID: ${id}`,
 id: `${prefix}swgcall2 --select|${id}|pub`
 }));

 await raiden.sendMessage(m.chat, {
 text: `🚀 *GLOBAL STORY ENGINE V2*\n\n` +
 `📦 *Media:* ${payload.text ? 'Teks' : 'File Media'}\n` +
 `🏠 *Total Grup:* ${groupList.length}\n\n` +
 `_Silakan pilih metode pengiriman di bawah:_`,
 contextInfo: {
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: global.idSaluran,
 newsletterName: global.namaSaluran || global.botname,
 serverId: 200
 }
 },
 buttons: [
 {
 buttonId: `${prefix}swgcall2 --all`,
 buttonText: { displayText: '📢 Semua Grup (Public)' },
 type: 1
 },
 {
 buttonId: `${prefix}swgcall2 --allcf`,
 buttonText: { displayText: '💚 Semua Grup (Close Friend)' },
 type: 1
 },
 {
 buttonId: 'swgc_pick',
 buttonText: { displayText: '🏠 Pilih Grup Tertentu' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: "Daftar Grup",
 sections: [{ title: "PILIH TUJUAN", rows }]
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: m });
};

export default handler;
