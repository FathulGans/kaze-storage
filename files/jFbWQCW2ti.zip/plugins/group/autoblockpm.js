const pluginConfig = {
  name: 'autoblockpm',
  category: 'group',
  command: ['autoblockpm', 'antipm', 'autoblock'],
};

const handler = async (m, ctx) => {
    let { Reply, command, isVip, prefix, text } = ctx;
    if (!isVip) return Reply(mess.vip);

    if (typeof global.db.settings.autoBlockPm === 'undefined') {
        global.db.settings.autoBlockPm = false;
    }

    const statusSkrg = global.db.settings.autoBlockPm;

    if (!text) {
        return Reply(
            `╭─❏ *AUTO BLOCK PM*\n` +
            `│\n` +
            `│ Status: ${statusSkrg ? '✅ *AKTIF*' : '❌ *MATI*'}\n` +
            `│\n` +
            `│ 📌 *Cara pakai:*\n` +
            `│ • ${prefix + command} on  → aktifkan\n` +
            `│ • ${prefix + command} off → matikan\n` +
            `│\n` +
            `│ ℹ️ Setiap nomor yang PM bot\n` +
            `│    akan otomatis diblokir &\n` +
            `│    notif dikirim ke owner + grup.\n` +
            `╰──────────❏`
        );
    }

    const aksi = text.toLowerCase();

    if (aksi === 'on') {
        global.db.settings.autoBlockPm = true;
        await m.reply(
            `╭─❏ *AUTO BLOCK PM*\n` +
            `│\n` +
            `│ ✅ Berhasil *DIAKTIFKAN*!\n` +
            `│\n` +
            `│ Setiap orang yang PM bot akan:\n` +
            `│ 🔴 Otomatis diblokir\n` +
            `│ 📩 Notif dikirim ke owner\n` +
            `│ 📋 Log dikirim ke grup (idgc)\n` +
            `│\n` +
            `╰──────────❏`
        );
    } else if (aksi === 'off') {
        global.db.settings.autoBlockPm = false;
        await m.reply(
            `╭─❏ *AUTO BLOCK PM*\n` +
            `│\n` +
            `│ ❌ Berhasil *DIMATIKAN*!\n` +
            `│\n` +
            `╰──────────❏`
        );
    } else {
        await m.reply(`Format salah, gunakan: ${prefix + command} on/off`);
    }
};

export default handler;
