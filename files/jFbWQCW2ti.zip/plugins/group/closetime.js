const pluginConfig = {
  name: 'closetime',
  category: 'group',
  command: ['closetime'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, text } = ctx;
    if (!m.isGroup) return Reply('❌ Command ini hanya untuk grup!');
    if (!m.isAdmin && !isVip) return Reply('❌ Hanya admin grup!');
    if (!m.isBotAdmin) return Reply('❌ Bot harus menjadi admin!');
    
    if (!text) return Reply('Format: .closetime <waktu> <detik/menit/jam/hari>\nContoh: .closetime 10 menit');
    
    const args = text.split(' ');
    if (args.length < 2) return Reply('Format: .closetime <waktu> <detik/menit/jam/hari>\nContoh: .closetime 10 menit');
    
    const waktu = parseInt(args[0]);
    const unit = args[1].toLowerCase();
    
    if (isNaN(waktu) || waktu <= 0) return Reply('❌ Waktu harus berupa angka positif!');
    
    let timer;
    if (unit === 'detik') {
        timer = waktu * 1000;
    } else if (unit === 'menit') {
        timer = waktu * 60000;
    } else if (unit === 'jam') {
        timer = waktu * 3600000;
    } else if (unit === 'hari') {
        timer = waktu * 86400000;
    } else {
        return Reply('❌ Pilih unit waktu: detik/menit/jam/hari\nContoh: .closetime 10 menit');
    }
    
    Reply(`⏰ *Close Time ${waktu} ${unit}* dimulai dari sekarang\nGrup akan ditutup otomatis setelah waktu habis.`);
    
    setTimeout(async () => {
        try {
            await raiden.groupSettingUpdate(m.chat, 'announcement');
            await Reply(`🔒 *TEPAT WAKTU*\nGrup telah ditutup oleh sistem.\nSekarang hanya admin yang dapat mengirim pesan.`);
        } catch (error) {
            await Reply('❌ Gagal menutup grup. Pastikan bot masih admin.');
        }
    }, timer);
};

export default handler;
