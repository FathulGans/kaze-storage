import fs from 'fs';

const pluginConfig = {
  name: 'hukum',
  category: 'group',
  command: ['hukum', 'hukummember'],
};

const handler = async (m, ctx) => {
    let { Reply, args, hukumPath, isVip, raiden } = ctx;
    if (!m.isGroup) return Reply(global.mess.group);
    if (!isVip && !m.isAdmin) return Reply(global.mess.admin);
    if (!m.isBotAdmin) return Reply(global.mess.botAdmin);

    let users = [];
    if (m.mentionedJid.length) {
        users = m.mentionedJid.map(id => {
            if (id.endsWith('@lid')) {
                let p = m.metadata.participants.find(x => x.lid === id || x.id === id);
                return p ? p.jid : null;
            } else {
                return id;
            }
        }).filter(Boolean);
    } else if (m.quoted) {
        users = [m.quoted.sender];
    } else if (args[0]) {
        users = [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'];
    }

    if (!users.length) return Reply(`Tag atau reply user dan tentukan durasi!\nContoh: .hukum @user 1j`);
    
    let target = users[0];
    let durationStr = args.find(a => a.match(/[0-9]+[hjmshjs]/i)) || '1j';
    
    const parseTime = (str) => {
        let num = parseInt(str);
        if (str.endsWith('h') || str.endsWith('j')) return num * 3600000;
        if (str.endsWith('m')) return num * 60000;
        if (str.endsWith('s')) return num * 1000;
        return num * 3600000;
    };

    let ms = parseTime(durationStr.toLowerCase());
    let dbHukum = JSON.parse(fs.readFileSync(hukumPath));
    if (!dbHukum[m.chat]) dbHukum[m.chat] = { hukum: {}, bangrup: [] };
    
    dbHukum[m.chat].hukum[target] = {
        expired: Date.now() + ms,
        duration: durationStr
    };
    
    fs.writeFileSync(hukumPath, JSON.stringify(dbHukum, null, 2));
    await raiden.sendMessage(m.chat, { 
        text: `✅ User @${target.split('@')[0]} berhasil dihukum selama ${durationStr}. Setiap pesannya akan otomatis dihapus`, 
        mentions: [target] 
    }, { quoted: m });
};

export default handler;
