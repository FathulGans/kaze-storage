const pluginConfig = {
  name: 'setnamagc',
  category: 'group',
  command: ['setnamagc'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, text } = ctx;
    if (!m.isGroup) return Reply('❌ Command ini hanya untuk grup!');
    if (!isVip && !m.isAdmin) return Reply('❌ Hanya admin atau owner yang bisa!');
    if (!m.isBotAdmin) return Reply('❌ Bot harus admin untuk ubah nama grup!');
    
    if (!text) return Reply('❌ Masukkan nama grup baru!\nContoh: .setnamagc Grup Komunitas Kita');
    
    try {
        m.reply('⏳ Mengubah nama grup...');
        
        if (text.length > 100) {
            return Reply('❌ Nama terlalu panjang! Maksimal 100 karakter.');
        }
        
        await raiden.groupUpdateSubject(m.chat, text);
        
        Reply('✅ Nama grup berhasil diubah menjadi: ' + text);
    } catch (error) {
        console.error('Set Name Error:', error);
        
        if (error.message.includes('conflict') || error.data === 409) {
            Reply('⚠️ WhatsApp API sedang membatasi perubahan nama.\nCoba lagi dalam beberapa menit.');
        } else {
            Reply('❌ Gagal mengubah nama grup. Pastikan bot memiliki permission yang cukup.');
        }
    }
    return;
};

export default handler;
