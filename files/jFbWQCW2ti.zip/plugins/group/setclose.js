const pluginConfig = {
  name: 'setclose',
  category: 'group',
  command: ['setclose'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, text } = ctx;
  if (!m.isGroup) return Reply(mess.group);
  if (!isVip && !m.isAdmin) return Reply(mess.admin);
  
  if (!text) return Reply('Format: .setclose <pesan>');
  
  if (!global.db.groups) global.db.groups = {};
  if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
  
  global.db.groups[m.chat].closeMessage = text;
  
  Reply(`✅ Pesan close grup diset: "${text}"`);
};

export default handler;
