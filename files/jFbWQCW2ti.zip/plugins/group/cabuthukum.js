import fs from 'fs';

const pluginConfig = {
  name: 'cabuthukum',
  category: 'group',
  command: ['cabuthukum'],
};

const handler = async (m, ctx) => {
    let { Reply, args, hukumPath, isVip, raiden } = ctx;
    if (!m.isGroup) return Reply(global.mess.group);
    if (!isVip && !m.isAdmin) return Reply(global.mess.admin);
    let users = [];
    if (m.mentionedJid.length) {
        users = m.mentionedJid.map(id => {
            if (id.endsWith('@lid')) {
                let p = m.metadata.participants.find(x => x.lid === id || x.id === id);
                return p ? p.jid : null;
            } else {
                return id;
            }
        }).filter(Boolean);
    } else if (m.quoted) {
        users = [m.quoted.sender];
    } else if (args[0]) {
        users = [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'];
    }

    if (!users.length) return Reply(`Tag user atau reply pesan nya yang ingin dibebaskan dari hukum!`);
    let target = users[0];
    
    let dbHukum = JSON.parse(fs.readFileSync(hukumPath));
    if (!dbHukum[m.chat] || !dbHukum[m.chat].hukum[target]) return Reply(`User tidak sedang dalam masa hukum`);
    
    delete dbHukum[m.chat].hukum[target];
    fs.writeFileSync(hukumPath, JSON.stringify(dbHukum, null, 2));
    
    await raiden.sendMessage(m.chat, { 
        text: `✅ Hukuman @${target.split('@')[0]} telah dicabut`, 
        mentions: [target] 
    }, { quoted: m });
};

export default handler;
