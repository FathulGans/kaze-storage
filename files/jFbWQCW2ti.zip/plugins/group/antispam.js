const pluginConfig = {
  name: 'antispam',
  category: 'group',
  command: ['antispam'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antispam = true;
        if (!global.db.groups[m.chat].antispam) {
            global.db.groups[m.chat].antispam = {};
        }
        Reply(`✅ *MODE ANTI SPAM DIAKTIFKAN*`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antispam = false;
        if (global.db.groups[m.chat].antispam) {
            global.db.groups[m.chat].antispam = {};
        }
        Reply(`❌ *MODE ANTI SPAM DIMATIKAN*`);
    } else {
        const status = global.db.groups[m.chat].antispam ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTI SPAM MODE*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antispam on - untuk mengaktifkan\n• ${prefix}antispam off - untuk mematikan`);
    }
    return;
};

export default handler;
