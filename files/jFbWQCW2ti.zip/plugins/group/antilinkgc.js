const pluginConfig = {
  name: 'antilinkgc',
  category: 'group',
  command: ['antilinkgc'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, saveMainGroups, text } = ctx;
    if (!m.isGroup) return
    if (!m.isAdmin && !isVip) return Reply('❌ Hanya admin grup!');
    
    if (!text) {
        const isActiveDelete = global.db.groups[m.chat]?.antilinkgcdelete || false;
        const isActiveKick = global.db.groups[m.chat]?.antilinkgckick || false;
        
        let statusDelete = isActiveDelete ? '✅ AKTIF' : '❌ NONAKTIF';
        let statusKick = isActiveKick ? '✅ AKTIF' : '❌ NONAKTIF';
        
        return Reply(`🔧 *ANTI LINK GRUP SETTINGS*\n\nDelete Mode: ${statusDelete}\nKick Mode: ${statusKick}\n\nPilihan:\n• delete - hanya hapus pesan\n• kick - hapus pesan + kick user\n\nContoh:\n${prefix}antilinkgc delete on\n${prefix}antilinkgc kick off`);
    }
    
    const argsText = text.toLowerCase().split(' ');
    if (argsText.length < 2) return Reply(`Format: ${prefix}antilinkgc <delete/kick> <on/off>`);
    
    const mode = argsText[0];
    const action = argsText[1];
    
    if (mode !== 'delete' && mode !== 'kick') {
        return Reply('❌ Mode tidak valid! Pilih: delete atau kick');
    }
    
    if (action !== 'on' && action !== 'off') {
        return Reply('❌ Action tidak valid! Pilih: on atau off');
    }
    
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    if (mode === 'delete') {
        global.db.groups[m.chat].antilinkgcdelete = (action === 'on');
        saveMainGroups();
        Reply(`✅ Anti Link Grup delete ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
    } else if (mode === 'kick') {
        global.db.groups[m.chat].antilinkgckick = (action === 'on');
        saveMainGroups();
        Reply(`✅ Anti Link Grup kick ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
    }
    return;
};

export default handler;
