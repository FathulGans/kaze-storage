const pluginConfig = {
  name: 'autodownload',
  category: 'group',
  command: ['autodownload'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].autodownload = true;
        if (!global.db.groups[m.chat].autodownload) {
            global.db.groups[m.chat].autodownload = {};
        }
        Reply(`✅ *auto download diaktifkan*`);
    } else if (action === 'off') {
        global.db.groups[m.chat].autodownload = false;
        if (global.db.groups[m.chat].autodownload) {
            global.db.groups[m.chat].autodownload = {};
        }
        Reply(`❌ *auto download dimatikan*`);
    } else {
        const status = global.db.groups[m.chat].autodownload ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING AUTO DOWNLOAD*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}autodownload on - untuk mengaktifkan\n• ${prefix}autodownload off - untuk mematikan`);
    }
    return;
};

export default handler;
