const pluginConfig = {
  name: 'delultah',
  category: 'group',
  command: ['delultah'],
};

const handler = async (m, ctx) => {
    let { Reply, saveUltahDb } = ctx;
    if (!m.isGroup) return Reply(mess.group);
    
    if (!global.ultahdb[m.chat] || !global.ultahdb[m.chat][m.sender]) {
        return Reply(`❌ Kamu belum mendaftarkan ulang tahun.`);
    }

    delete global.ultahdb[m.chat][m.sender];
    saveUltahDb();
    Reply(`✅ Data ulang tahunmu berhasil dihapus.`);
};

export default handler;
