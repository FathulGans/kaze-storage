const pluginConfig = {
  name: 'antiaudio',
  category: 'group',
  command: ['antiaudio'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antiaudio = true;
        if (!global.db.groups[m.chat].antiaudio) {
            global.db.groups[m.chat].antiaudio = {};
        }
        Reply(`✅ *anti audio diaktifkan*\n\nBot akan  menghapus audio yang dikirim oleh anggota grup.`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antiaudio = false;
        if (global.db.groups[m.chat].antiaudio) {
            global.db.groups[m.chat].antiaudio = {};
        }
        Reply(`❌ *anti audio dimatikan*\n\nBot tidak akan menghapus audio lagi`);
    } else {
        const status = global.db.groups[m.chat].antiaudio ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTI AUDIO*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antiaudio on - untuk mengaktifkan\n• ${prefix}antiaudio off - untuk mematikan`);
    }
    return;
};

export default handler;
