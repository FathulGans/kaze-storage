const pluginConfig = {
  name: 'statsgrup',
  category: 'group',
  command: ['statsgrup'],
};

const handler = async (m, ctx) => {
    let { Reply } = ctx;
 if (!m.isGroup) return Reply('❌ Hanya untuk grup!')
 const _meta = m.metadata
 if (!_meta) return Reply('❌ Gagal mengambil data grup.')
 const _ptcps = _meta.participants || []
 const _admins = _ptcps.filter(p => p.admin === 'admin' || p.admin === 'superadmin')
 const _sadmins = _ptcps.filter(p => p.admin === 'superadmin')
 const _regular = _ptcps.filter(p => !p.admin)
 const _created = _meta.creation ? new Date(_meta.creation * 1000).toLocaleDateString('id-ID') : '?'
 const _desc = _meta.desc ? (_meta.desc.length > 100 ? _meta.desc.substring(0, 100) + '...' : _meta.desc) : 'Tidak ada deskripsi'
 Reply(`╭─⬣「 📊 *sᴛᴀᴛs ɢʀᴜᴘ* 」⬣
│
│ 📌 *Nama:* ${_meta.subject || '-'}
│ 👥 *Total Member:* ${_ptcps.length}
│ 👑 *Owner:* ${_sadmins.length}
│ 🛡️ *Admin:* ${_admins.length}
│ 👤 *Member Biasa:* ${_regular.length}
│ 📅 *Dibuat:* ${_created}
│ 🔒 *Kirim Pesan:* ${_meta.announce ? 'Hanya Admin' : 'Semua Member'}
│ ✏️ *Edit Info:* ${_meta.restrict ? 'Hanya Admin' : 'Semua Member'}
│
│ 📝 *Deskripsi:*
│ ${_desc}
│
╰─⬣ _sʜᴀᴅᴏᴡ ʙᴏᴛ_`)
};

export default handler;
