import __baileys from '../../src/lib/baileys-compat.js';
import __stream from 'stream';
import fs from 'fs';
import path from 'path';
import util from 'util';

const pluginConfig = {
  name: 'addfilter',
  category: 'group',
  command: ['addfilter'],
};

const handler = async (m, ctx) => {
    let { args, isVip, prefix, raiden } = ctx;
    if (!m.isGroup) return m.reply(global.mess.group);

    const groupMetaF = await raiden.groupMetadata(m.chat).catch(() => ({}));
    const participantsF = groupMetaF?.participants || [];
    const userAdminF = participantsF.find(p => [p.id, p.jid, p.lid].includes(m.sender) || (m.senderLid && [p.id, p.lid].includes(m.senderLid)));
    const isAdminF = userAdminF?.admin === 'admin' || userAdminF?.admin === 'superadmin';
    if (!isAdminF && !isVip) return m.reply(global.mess.admin);

    if (!args[0]) return m.reply(
        `⚠️ *Format salah!*\n\n` +
        `📌 *Cara pakai:*\n` +
        `• *${prefix}addfilter keyword* + reply foto/video/stiker/audio\n` +
        `• *${prefix}addfilter keyword | caption* + reply foto/video\n` +
        `• *${prefix}addfilter keyword | teks* (tanpa reply = filter teks)\n\n` +
        `📝 *Contoh:*\n` +
        `• .addfilter rules (reply foto)\n` +
        `• .addfilter rules | Ini peraturan grup kami\n` +
        `• .addfilter selamat | Selamat datang di grup!`
    );

    const fullText = args.join(' ');
    let keyword, customCaption;
    if (fullText.includes('|')) {
        const parts = fullText.split('|');
        keyword = parts[0].trim().toLowerCase();
        customCaption = parts.slice(1).join('|').trim();
    } else {
        keyword = fullText.trim().toLowerCase();
        customCaption = '';
    }

    if (!keyword) return m.reply('⚠️ Keyword tidak boleh kosong!');

    const { downloadContentFromMessage } = __baileys;
    const { pipeline } = __stream;
    const { promisify } = util;
    const streamPipeline = promisify(pipeline);

    const dirMedia = './library/media/filter';
    const dirDB = './library/database';
    if (!fs.existsSync(dirMedia)) fs.mkdirSync(dirMedia, { recursive: true });
    if (!fs.existsSync(dirDB)) fs.mkdirSync(dirDB, { recursive: true });

    if (typeof global.db === 'undefined') global.db = {};
    if (typeof global.db.filter === 'undefined') global.db.filter = {};
    if (typeof global.db.filter[m.chat] === 'undefined') global.db.filter[m.chat] = {};

    m.reply('⏳ Sedang memproses filter...');

    try {
        let newData = {};
        let q = m.quoted ? m.quoted : null;
        let mimeType = q ? ((q.msg || q).mimetype || '') : '';
        let msgType = '';
        let ext = '';
        let downloadType = '';

        if (mimeType) {
            if (/webp/.test(mimeType))        { msgType = 'sticker';  downloadType = 'sticker';  ext = '.webp'; }
            else if (/image/.test(mimeType))  { msgType = 'image';    downloadType = 'image';    ext = '.jpg';  }
            else if (/video/.test(mimeType))  { msgType = 'video';    downloadType = 'video';    ext = '.mp4';  }
            else if (/audio/.test(mimeType))  { msgType = 'audio';    downloadType = 'audio';    ext = '.mp3';  }
            else                               { msgType = 'document'; downloadType = 'document'; ext = '.bin'; }
        } else if (customCaption) {
            msgType = 'text';
        } else if (q && q.text) {
            msgType = 'text';
        } else {
            return m.reply('⚠️ Reply foto/video/stiker/audio, atau tambahkan teks setelah "|" untuk filter teks.\n\nContoh:\n.addfilter rules | Ini teks filter\n.addfilter gambar (sambil reply foto)');
        }

        if (msgType === 'text') {
            const isiTeks = customCaption || (q ? q.text : '') || '';
            if (!isiTeks) return m.reply('⚠️ Teks filter tidak boleh kosong!');
            newData = { type: 'text', content: isiTeks };
        } else {
            const filename = `${m.chat.split('@')[0]}_${keyword.replace(/\s+/g, '_')}_${Date.now()}${ext}`;
            const filepath = path.join(dirMedia, filename);
            const msgSource = q.msg || q;
            const stream = await downloadContentFromMessage(msgSource, downloadType);
            const writeStream = fs.createWriteStream(filepath);
            await streamPipeline(stream, writeStream);

            const finalCaption = customCaption || q.text || '';

            if (msgType === 'sticker') {
                newData = { type: 'sticker', url: filepath };
            } else if (msgType === 'image') {
                newData = { type: 'image', url: filepath, caption: finalCaption };
            } else if (msgType === 'video') {
                newData = { type: 'video', url: filepath, caption: finalCaption };
            } else if (msgType === 'audio') {
                newData = { type: 'audio', url: filepath, ptt: (q.msg || q).ptt || false };
            } else if (msgType === 'document') {
                newData = { type: 'document', url: filepath, mimetype: mimeType, filename: (q.msg || q).fileName || `${keyword}${ext}` };
            }
        }

        global.db.filter[m.chat][keyword] = newData;
        fs.writeFileSync(path.join(dirDB, 'filter_db.json'), JSON.stringify(global.db.filter, null, 2));

        const tipeLabel = {
            text: '📝 Teks', image: '🖼️ Foto', video: '🎥 Video',
            sticker: '🎨 Stiker', audio: '🎵 Audio', document: '📁 Dokumen'
        }[msgType] || msgType;

        const captionInfo = (msgType !== 'text' && (newData.caption || '')) 
            ? `\n📄 Caption: _${newData.caption}_` : '';

        m.reply(
            `✅ *FILTER BERHASIL DISIMPAN!*\n\n` +
            `🔑 Keyword: *${keyword}*\n` +
            `${tipeLabel}${captionInfo}\n\n` +
            `_Ketik "${keyword}" di grup untuk memicu filter ini._`
        );

    } catch (e) {
        console.error('[ADDFILTER ERROR]', e);
        m.reply(`❌ Gagal menyimpan filter: ${e.message}`);
    }
};

export default handler;
