import fs from 'fs';

const pluginConfig = {
  name: 'toplevel',
  category: 'group',
  command: ['toplevel', 'leaderboard', 'lb'],
};

const handler = async (m, konteksInti) => {
    let { Reply, getXPToNextLevel, levelDBPath, raiden } = konteksInti;
    if (!m.isGroup) return Reply('Perintah ini hanya untuk grup');

    const levelDB = JSON.parse(fs.readFileSync(levelDBPath));
    const groupData = levelDB[m.chat];

    if (!groupData || Object.keys(groupData).length === 0) {
        return Reply('Belum ada data level di grup ini');
    }

    let groupMetadata = null;
    try {
        groupMetadata = await raiden.groupMetadata(m.chat);
    } catch (e) { console.error(e); }

    const users = Object.entries(groupData)
        .map(([jid, data]) => ({ jid, ...data }))
        .sort((a, b) => {
            if (a.level !== b.level) return b.level - a.level;
            return b.xp - a.xp;
        })
        .slice(0, 10);

    const getName = (jid) => {
        if (groupMetadata?.participants) {
            const p = groupMetadata.participants.find(x => [x.id, x.jid, x.lid].includes(jid));
            if (p?.notify) return p.notify;
            if (p?.name) return p.name;
        }
        return jid.split('@')[0];
    };

    const { createCanvas, loadImage } = (await import('canvas')).default;

    const W = 1000;
    const HEADER_H = 100;
    const PODIUM_SECTION_H = 300;
    const ROW_H = 72;
    const REST_HEADER_H = 44;
    const FOOTER_H = 48;
    const rest = users.slice(3);
    const H = HEADER_H + PODIUM_SECTION_H + (rest.length > 0 ? REST_HEADER_H + rest.length * ROW_H + 10 : 0) + FOOTER_H + 20;

    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    const drawRR = (x, y, w, h, r) => {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    };

    const drawChibi = (cx, cy, idx, sc = 1) => {
        const skinTones = ['#ffe0bd', '#ffcd94', '#f5cfa0', '#e8b88a', '#c68642'];
        const hairColors = ['#1a1a1a', '#8b4513', '#ffd700', '#4a3728', '#9b59b6', '#ff6b6b', '#2ecc71', '#1a1a1a', '#c0392b', '#2c3e50'];
        const bodyColors = ['#fbbf24', '#38bdf8', '#f472b6', '#34d399', '#a78bfa', '#fb923c', '#e879f9', '#22d3ee', '#60a5fa', '#ff6b9d'];
        const expressions = [
            { eye: 'star', mouth: 'open', blush: true },
            { eye: 'happy', mouth: 'smile', blush: true },
            { eye: 'normal', mouth: 'smirk', blush: false },
            { eye: 'sleepy', mouth: 'smile', blush: true },
            { eye: 'normal', mouth: 'open', blush: false },
            { eye: 'happy', mouth: 'smile', blush: true },
            { eye: 'normal', mouth: 'smile', blush: true },
            { eye: 'sleepy', mouth: 'smirk', blush: false },
            { eye: 'happy', mouth: 'open', blush: true },
            { eye: 'star', mouth: 'smile', blush: true },
        ];
        const expr = expressions[idx % expressions.length];
        const skin = skinTones[idx % skinTones.length];
        const hair = hairColors[idx % hairColors.length];
        const body = bodyColors[idx % bodyColors.length];

        ctx.save();
        ctx.translate(cx, cy);
        ctx.scale(sc, sc);

        ctx.fillStyle = 'rgba(0,0,0,0.10)';
        ctx.beginPath();
        ctx.ellipse(0, 50, 24, 6, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = body; ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(-20, 16, 7, 10, -0.3, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.ellipse(20, 16, 7, 10, 0.3, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

        drawRR(-18, 4, 36, 32, 9);
        ctx.fillStyle = body; ctx.fill();
        ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2;
        drawRR(-18, 4, 36, 32, 9); ctx.stroke();

        ctx.fillStyle = body; ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(-9, 40, 9, 12, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.ellipse(9, 40, 9, 12, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#1a1a2e';
        ctx.beginPath(); ctx.ellipse(-9, 47, 7, 4, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(9, 47, 7, 4, 0, 0, Math.PI * 2); ctx.fill();

        ctx.fillStyle = skin; ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(0, -10, 22, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

        ctx.fillStyle = hair; ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, -14, 22, Math.PI, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.ellipse(-22, -12, 8, 10, -0.3, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.ellipse(22, -12, 8, 10, 0.3, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.ellipse(0, -32, 10, 6, 0, 0, Math.PI * 2); ctx.fill();

        if (expr.eye === 'normal') {
            ctx.fillStyle = '#fff'; ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.ellipse(-8, -10, 6, 7.5, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.ellipse(8, -10, 6, 7.5, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
            ctx.fillStyle = '#1a1a2e';
            ctx.beginPath(); ctx.arc(-7, -10, 3.5, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(9, -10, 3.5, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.beginPath(); ctx.arc(-5.5, -12, 1.3, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(10.5, -12, 1.3, 0, Math.PI * 2); ctx.fill();
        } else if (expr.eye === 'happy') {
            ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.arc(-8, -7, 6.5, Math.PI, Math.PI * 2); ctx.stroke();
            ctx.beginPath(); ctx.arc(8, -7, 6.5, Math.PI, Math.PI * 2); ctx.stroke();
        } else if (expr.eye === 'sleepy') {
            ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.arc(-8, -10, 6.5, 0, Math.PI); ctx.stroke();
            ctx.beginPath(); ctx.arc(8, -10, 6.5, 0, Math.PI); ctx.stroke();
        } else if (expr.eye === 'star') {
            const drawStar = (sx, sy, r) => {
                ctx.beginPath();
                for (let s = 0; s < 5; s++) {
                    const a1 = (s * 4 * Math.PI / 5) - Math.PI / 2;
                    const a2 = ((s * 4 + 2) * Math.PI / 5) - Math.PI / 2;
                    if (s === 0) ctx.moveTo(sx + r * Math.cos(a1), sy + r * Math.sin(a1));
                    else ctx.lineTo(sx + r * Math.cos(a1), sy + r * Math.sin(a1));
                    ctx.lineTo(sx + r * 0.45 * Math.cos(a2), sy + r * 0.45 * Math.sin(a2));
                }
                ctx.closePath();
            };
            drawStar(-8, -10, 7); ctx.fillStyle = '#fbbf24'; ctx.fill();
            drawStar(8, -10, 7); ctx.fillStyle = '#fbbf24'; ctx.fill();
        }

        if (expr.blush) {
            ctx.fillStyle = 'rgba(255,120,120,0.35)';
            ctx.beginPath(); ctx.ellipse(-17, -4, 6, 4, 0, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.ellipse(17, -4, 6, 4, 0, 0, Math.PI * 2); ctx.fill();
        }

        if (expr.mouth === 'smile') {
            ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(0, 2, 7, 0.2, Math.PI - 0.2); ctx.stroke();
        } else if (expr.mouth === 'open') {
            ctx.fillStyle = '#1a1a2e';
            ctx.beginPath(); ctx.ellipse(0, 4, 5.5, 4.5, 0, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#ff9999';
            ctx.beginPath(); ctx.ellipse(0, 5, 3.5, 2.8, 0, 0, Math.PI * 2); ctx.fill();
        } else if (expr.mouth === 'smirk') {
            ctx.strokeStyle = '#1a1a2e'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(3, 4, 6, 0.5, Math.PI - 0.8); ctx.stroke();
        }

        ctx.restore();
    };

    ctx.fillStyle = '#fef9f0';
    ctx.fillRect(0, 0, W, H);

    for (let i = 0; i < 20; i++) {
        const px = (i * 137 + 50) % W;
        const py = (i * 97 + 30) % H;
        const pr = 12 + (i % 5) * 8;
        const dc = ['rgba(255,107,157,0.06)', 'rgba(56,189,248,0.06)', 'rgba(251,191,36,0.06)', 'rgba(52,211,153,0.06)', 'rgba(167,139,250,0.06)'];
        ctx.fillStyle = dc[i % dc.length];
        ctx.beginPath(); ctx.arc(px, py, pr, 0, Math.PI * 2); ctx.fill();
    }

    const gs = 44;
    ctx.strokeStyle = 'rgba(0,0,0,0.035)';
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += gs) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
    for (let y = 0; y < H; y += gs) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

    ctx.fillStyle = '#ff6b9d'; ctx.fillRect(0, 0, W, 7);
    ctx.fillStyle = '#fbbf24'; ctx.fillRect(0, 7, W, 4);
    ctx.fillStyle = '#38bdf8'; ctx.fillRect(0, 11, W, 3);

    ctx.fillStyle = '#fbbf24';
    ctx.fillRect(30 + 5, 18 + 5, W - 60, HEADER_H - 18);
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(30, 18, W - 60, HEADER_H - 18);
    ctx.strokeStyle = '#ff6b9d';
    ctx.lineWidth = 3;
    ctx.strokeRect(30, 18, W - 60, HEADER_H - 18);

    const crownSz = 56;
    ctx.fillStyle = '#ff6b9d';
    ctx.fillRect(55 + 3, 28 + 3, crownSz, crownSz);
    ctx.fillStyle = '#fbbf24';
    ctx.fillRect(55, 28, crownSz, crownSz);
    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(55, 28, crownSz, crownSz);
    ctx.fillStyle = '#1a1a2e';
    ctx.font = 'bold 24px "Courier New", monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('LV', 55 + crownSz / 2, 28 + crownSz / 2);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 34px "Courier New", monospace';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText('LEVEL LEADERBOARD', 124, 52);

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(124, 76); ctx.lineTo(124 + 380, 76); ctx.stroke();

    const groupName = (groupMetadata?.subject || 'GROUP').toUpperCase();
    const gnDisp = groupName.length > 20 ? groupName.slice(0, 18) + '..' : groupName;
    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 13px "Courier New", monospace';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(`[ ${gnDisp} ]`, W - 48, 42);
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 12px "Courier New", monospace';
    ctx.fillText(`TOP ${users.length} PLAYERS`, W - 48, 65);

    const top3 = users.slice(0, Math.min(3, users.length));

    const PODIUM_TOP_Y = HEADER_H + 14;
    const CHIBI_H = 90;
    const NAMETAG_H = 30;
    const NAMETAG_GAP = 6;
    const podiumAccents = ['#fbbf24', '#94a3b8', '#cd7c3a'];
    const podiumBaseHeights = [130, 160, 100];
    const orderMap = top3.length === 1 ? [0] : top3.length === 2 ? [1, 0] : [1, 0, 2];
    const podiumXList = top3.length === 1 ? [W / 2] : top3.length === 2 ? [W / 2 - 160, W / 2 + 160] : [W / 2 - 210, W / 2, W / 2 + 210];
    const rankLabels = ['1ST', '2ND', '3RD'];

    const maxPodH = Math.max(...orderMap.map(ui => podiumBaseHeights[ui]));
    const podBaseLineY = PODIUM_TOP_Y + PODIUM_SECTION_H - 10;

    for (let pi = 0; pi < orderMap.length; pi++) {
        const ui = orderMap[pi];
        if (ui >= top3.length) continue;
        const user = top3[ui];
        const accent = podiumAccents[ui];
        const podH = podiumBaseHeights[ui];
        const podW = top3.length === 1 ? 260 : 240;
        const px = podiumXList[pi];
        const podX = px - podW / 2;
        const podY = podBaseLineY - podH;

        ctx.fillStyle = accent;
        ctx.fillRect(podX + 5, podY + 5, podW, podH);
        ctx.fillStyle = accent + '55';
        ctx.fillRect(podX, podY, podW, podH);
        ctx.strokeStyle = accent;
        ctx.lineWidth = 2.5;
        ctx.strokeRect(podX, podY, podW, podH);

        ctx.fillStyle = '#1a1a2e';
        ctx.font = `bold ${podW < 200 ? '32' : '42'}px "Courier New", monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`${user.level}`, px, podY + podH / 2 - 12);

        ctx.fillStyle = accent;
        ctx.font = 'bold 11px "Courier New", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('LEVEL', px, podY + podH / 2 + 16);

        const xpNeeded = getXPToNextLevel(user.level);
        const progress = Math.min(100, Math.floor((user.xp / xpNeeded) * 100));
        const miniBarW = podW - 32;
        const miniBarY = podY + podH - 24;
        ctx.fillStyle = 'rgba(0,0,0,0.18)';
        ctx.fillRect(podX + 16, miniBarY, miniBarW, 10);
        ctx.strokeStyle = '#1a1a2e';
        ctx.lineWidth = 1;
        ctx.strokeRect(podX + 16, miniBarY, miniBarW, 10);
        ctx.fillStyle = accent;
        ctx.fillRect(podX + 16, miniBarY, miniBarW * (progress / 100), 10);

        ctx.fillStyle = '#1a1a2e';
        ctx.font = 'bold 9px "Courier New", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`${progress}%`, px, miniBarY + 5);

        const ntY = podY - NAMETAG_GAP - NAMETAG_H;
        ctx.fillStyle = accent;
        ctx.fillRect(podX + 4, ntY + 4, podW, NAMETAG_H);
        ctx.fillStyle = '#1a1a2e';
        ctx.fillRect(podX, ntY, podW, NAMETAG_H);
        ctx.strokeStyle = accent;
        ctx.lineWidth = 2;
        ctx.strokeRect(podX, ntY, podW, NAMETAG_H);

        const rankBadgeW = 38;
        ctx.fillStyle = accent;
        ctx.fillRect(podX, ntY, rankBadgeW, NAMETAG_H);
        ctx.fillStyle = '#1a1a2e';
        ctx.font = 'bold 11px "Courier New", monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(rankLabels[ui], podX + rankBadgeW / 2, ntY + NAMETAG_H / 2);

        const rawName = getName(user.jid);
        const maxChars = Math.floor((podW - rankBadgeW - 16) / 8.5);
        const nDisp = rawName.length > maxChars ? rawName.slice(0, maxChars - 2) + '..' : rawName;
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 13px "Courier New", monospace';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(nDisp, podX + rankBadgeW + 8, ntY + NAMETAG_H / 2);

        const chibY = ntY - CHIBI_H + 10;
        drawChibi(px, chibY, ui, 0.85);
    }

    if (rest.length > 0) {
        const listStartY = HEADER_H + PODIUM_SECTION_H + 16;

        ctx.fillStyle = '#1a1a2e';
        ctx.fillRect(30 + 4, listStartY + 4, W - 60, REST_HEADER_H);
        ctx.fillStyle = '#a78bfa';
        ctx.fillRect(30, listStartY, W - 60, REST_HEADER_H);
        ctx.strokeStyle = '#1a1a2e';
        ctx.lineWidth = 2.5;
        ctx.strokeRect(30, listStartY, W - 60, REST_HEADER_H);

        ctx.fillStyle = '#1a1a2e';
        ctx.font = 'bold 13px "Courier New", monospace';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText('RANK   PLAYER', 68, listStartY + REST_HEADER_H / 2);
        ctx.textAlign = 'right';
        ctx.fillText('LEVEL       XP BAR       MSG', W - 50, listStartY + REST_HEADER_H / 2);

        const rowAccents = ['#38bdf8', '#34d399', '#f472b6', '#fb923c', '#e879f9', '#22d3ee', '#60a5fa'];

        for (let i = 0; i < rest.length; i++) {
            const user = rest[i];
            const realRank = i + 4;
            const ry = listStartY + REST_HEADER_H + i * ROW_H;
            const rc = rowAccents[i % rowAccents.length];

            ctx.fillStyle = i % 2 === 0 ? '#fff9f5' : '#ffffff';
            ctx.fillRect(30, ry, W - 60, ROW_H);
            ctx.strokeStyle = '#e0e0e0';
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(30, ry + ROW_H); ctx.lineTo(W - 30, ry + ROW_H); ctx.stroke();

            ctx.fillStyle = rc;
            ctx.fillRect(30, ry, 5, ROW_H);

            const rnkBX = 42;
            const rnkBY = ry + (ROW_H - 36) / 2;
            ctx.fillStyle = rc;
            ctx.fillRect(rnkBX + 3, rnkBY + 3, 36, 36);
            ctx.fillStyle = '#1a1a2e';
            ctx.fillRect(rnkBX, rnkBY, 36, 36);
            ctx.fillStyle = rc;
            ctx.font = 'bold 13px "Courier New", monospace';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(String(realRank).padStart(2, '0'), rnkBX + 18, rnkBY + 18);

            drawChibi(104, ry + ROW_H / 2 - 22, realRank - 1, 0.48);

            const rawName = getName(user.jid);
            const nDisp = rawName.length > 16 ? rawName.slice(0, 14) + '..' : rawName;
            ctx.fillStyle = '#1a1a2e';
            ctx.font = 'bold 15px "Courier New", monospace';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(nDisp, 134, ry + ROW_H / 2 - 9);

            ctx.fillStyle = 'rgba(0,0,0,0.38)';
            ctx.font = '10px "Courier New", monospace';
            ctx.fillText(`${user.messages || 0} msg`, 134, ry + ROW_H / 2 + 11);

            const xpNeeded = getXPToNextLevel(user.level);
            const progress = Math.min(100, Math.floor((user.xp / xpNeeded) * 100));

            const lvBadgeX = W - 300;
            ctx.fillStyle = rc;
            ctx.fillRect(lvBadgeX + 3, ry + (ROW_H - 30) / 2 + 3, 68, 30);
            ctx.fillStyle = '#1a1a2e';
            ctx.fillRect(lvBadgeX, ry + (ROW_H - 30) / 2, 68, 30);
            ctx.strokeStyle = rc;
            ctx.lineWidth = 1.5;
            ctx.strokeRect(lvBadgeX, ry + (ROW_H - 30) / 2, 68, 30);
            ctx.fillStyle = rc;
            ctx.font = 'bold 14px "Courier New", monospace';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(`LV.${user.level}`, lvBadgeX + 34, ry + ROW_H / 2);

            const barX = lvBadgeX + 78;
            const barW = W - barX - 42;
            const barH = 14;
            const barY = ry + (ROW_H - barH) / 2;
            ctx.fillStyle = 'rgba(0,0,0,0.07)';
            ctx.fillRect(barX, barY, barW, barH);
            ctx.strokeStyle = '#1a1a2e';
            ctx.lineWidth = 1;
            ctx.strokeRect(barX, barY, barW, barH);
            ctx.fillStyle = rc;
            ctx.fillRect(barX, barY, barW * (progress / 100), barH);

            ctx.fillStyle = '#1a1a2e';
            ctx.font = 'bold 10px "Courier New", monospace';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(`${progress}%`, barX + barW / 2, barY + barH / 2);
        }

        ctx.strokeStyle = '#1a1a2e';
        ctx.lineWidth = 2;
        ctx.strokeRect(30, listStartY + REST_HEADER_H, W - 60, rest.length * ROW_H);
    }

    const ftY = H - FOOTER_H + 8;
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(30 + 4, ftY + 4, W - 60, 34);
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(30, ftY, W - 60, 34);
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(30, ftY, W - 60, 34);

    const ftDots = ['#ff6b9d', '#fbbf24', '#38bdf8', '#34d399'];
    for (let i = 0; i < 4; i++) {
        ctx.fillStyle = ftDots[i];
        ctx.beginPath(); ctx.arc(54 + i * 18, ftY + 17, 5, 0, Math.PI * 2); ctx.fill();
    }

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 12px "Courier New", monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('POWERED BY LEVEL SYSTEM  //  KEEP CHATTING, KEEP LEVELING UP!', W / 2 + 20, ftY + 17);

    ctx.fillStyle = '#ff6b9d';
    ctx.fillRect(0, H - 5, W, 5);

    const buffer = canvas.toBuffer('image/png');
    const mentions = users.map(u => u.jid);

    await raiden.sendMessage(m.chat, {
        image: buffer,
        caption: `Top ${users.length} Leaderboard ${groupMetadata?.subject || ''}`,
        mentions: mentions
    }, { quoted: m });
};

export default handler;
