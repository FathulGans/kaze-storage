import { sleep } from '../../library/function.js';

const pluginConfig = {
  name: 'add',
  category: 'group',
  command: ['add', 'addmember'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, raiden, text } = ctx;
    if (!m.isGroup) return Reply(mess.group);
    if (!isVip) return Reply(`maaf kak, karena fitur ini rawan banned, maka fitur ini hanya bisa diakses oleh owner bot`);
    if (!m.isBotAdmin) return Reply(mess.botAdmin);
    let users = []
    if (m.isGroup) {
        if (m.mentionedJid.length) {
            users = m.mentionedJid.map(id => {
                if (id.endsWith('@lid')) {
                    let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
                    return p ? p.jid : null
                } else {
                    return id
                }
            }).filter(Boolean)
        } else if (m.quoted) {
            users = [m.quoted.sender]
        } else if (text) {
            users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net']
        }
    }
    if (!users.length) return Reply(`❌ *ketik nomor yang mau diadd ke grup ini!*\n\nContoh:\n${prefix}add 628xxx`);
    for (let user of users) {
        let onWa = await raiden.onWhatsApp(user.split("@")[0])
        if (!onWa?.length) {
            Reply(`⚠️ Nomor *${user.split("@")[0]}* tidak terdaftar di WhatsApp!`)
            continue
        }
        try {
            await raiden.groupParticipantsUpdate(m.chat, [user], 'add')
            await sleep(800)
            await Reply(`✅ Berhasil menambahkan *@${user.split('@')[0]}*`, { mentions: [user] })
        } catch (e) {
            Reply(`❌ Gagal menambahkan *@${user.split('@')[0]}*`, { mentions: [user] })
        }
    }
};

export default handler;
