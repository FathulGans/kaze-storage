import tictactoe from '../../src/lib/tictactoe.js';

const pluginConfig = {
  name: 'tttresign',
  category: 'group',
  command: ['tttresign', 'tttsurrender'],
};

const handler = async (m, ctx) => {
    let { Reply } = ctx;
    const result = await tictactoe.handleResign(m, Reply);
    if (result) Reply(result);
    return;
};

export default handler;
