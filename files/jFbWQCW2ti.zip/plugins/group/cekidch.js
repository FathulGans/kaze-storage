const pluginConfig = {
  name: 'cekidch',
  category: 'group',
  command: ['cekidch', 'idch'],
};

const handler = async (m, ctx) => {
    let { example, generateWAMessageFromContent, makeQuotedContact, prepareWAMessageMedia, proto, raiden, text } = ctx;
  if (!text) return m.reply(example("linkchnya"))
  if (!text.includes("https://whatsapp.com/channel/")) 
    return m.reply("❌ Link tautan tidak valid!")

  try {
    let result = text.split('https://whatsapp.com/channel/')[1].split(/[?&]/)[0]
    let res = await raiden.newsletterMetadata("invite", result).catch(e => null)

    if (!res) return m.reply("❌ Gagal mengambil data channel!")

    let teks = `
╔──☉ *INFORMASI CHANNEL* 
│✎ *Nama*      : ${res.name || "-"}
│✎ *Followers* : ${res.subscribers || 0}
│✎ *Status*    : ${res.state || "-"}
│✎ *Verified*  : ${res.verification == "VERIFIED" ? "✅ Terverifikasi" : "❌ Belum"}
╚────────────☉
`.trim()

    let img = await prepareWAMessageMedia(
      { image: { url: global.image.menu }},
      { upload: raiden.waUploadToServer }
    )

    const quotedContact = makeQuotedContact(m);

    const msgii = await generateWAMessageFromContent(m.chat, {
      viewOnceMessageV2Extension: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
              text: "🔎 *Cek ID Channel*\n\nBerikut detail channel WhatsApp yang kamu minta. Gunakan tombol di bawah untuk menyalin ID atau membuka channel resmi kami."
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
              text: `${global.botname || 'RaidenAI'} • Channel Lookup`
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
              title: teks,
              hasMediaAttachment: true,
              ...img
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [
                {
                  "name": "cta_copy",
                  "buttonParamsJson": `{\"display_text\":\"📋 Salin ID Channel\",\"id\":\"${res.id}\",\"copy_code\":\"${res.id}\"}`
                },
                {
              "name": "cta_url",
              "buttonParamsJson": `{\"display_text\":\"📢 ${global.namaSaluran}\",\"url\":\"${global.linkSaluran}\",\"merchant_url\":\"${global.linkSaluran}\"}`
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender, quoted: quotedContact })

    await raiden.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
    return m.reply(`✅ Informasi channel berhasil dikirim.`);
  } catch (e) {
    console.error(e)
    return m.reply("❌ Terjadi kesalahan saat mengambil data channel!")
  }
};

export default handler;
