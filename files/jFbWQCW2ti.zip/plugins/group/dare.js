import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'dare',
  category: 'group',
  command: ['dare'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);
    
const dares = [
    'Kirim pesan ke mantan dan bilang "aku masih sayang kamu". Screenshot hasilnya!',
    'Update status "Aku Mencintaimu, [tag orang ke-3 di kontakmu]" selama 1 jam.',
    'Telepon crush kamu dan nyanyikan lagu "Balonku Ada Lima".',
    'Tirukan suara hewan selama 1 menit di voice note.',
    'Posting foto alay-mu di story WA.',
    'Ganti nama profil WhatsApp-mu menjadi "Babu Cinta" selama 24 jam.',
    'Chat orang random dan ajak kenalan.',
    'Prank chat salah satu admin grup.',
    'Buat video TikTok dengan filter paling aneh.',
    'Spam chat temanmu dengan emoji 💩 sebanyak 5 kali.'
];
const randomDare = dares[Math.floor(Math.random() * dares.length)];
Reply(`*DARE* 🔥\n\nLakukan tantangan ini:\n*${randomDare}*`);
};

export default handler;
