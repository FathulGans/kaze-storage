const pluginConfig = {
  name: 'left',
  category: 'group',
  command: ['left'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].left = true;
        if (!global.db.groups[m.chat].left) {
            global.db.groups[m.chat].left = {};
        }
        Reply(`✅ *left diaktifkan*`);
    } else if (action === 'off') {
        global.db.groups[m.chat].left = false;
        if (global.db.groups[m.chat].left) {
            global.db.groups[m.chat].left = {};
        }
        Reply(`❌ *left dimatikan*`);
    } else {
        const status = global.db.groups[m.chat].left ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING LEFT*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}left on - untuk mengaktifkan\n• ${prefix}left off - untuk mematikan`);
    }
    return;
};

export default handler;
