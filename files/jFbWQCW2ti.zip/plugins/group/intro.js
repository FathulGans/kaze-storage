const pluginConfig = {
  name: 'intro',
  category: 'group',
  command: ['intro'],
};

const handler = async (m, ctx) => {
    let { Reply, generateWAMessageFromContent, prepareWAMessageMedia, proto, raiden } = ctx;
    if (!m.isGroup) return Reply('❌ Command ini hanya untuk grup!');
    
    let introTemplate;
    
    if (global.db.groups[m.chat] && global.db.groups[m.chat].intro && global.db.groups[m.chat].intro.template) {
        introTemplate = global.db.groups[m.chat].intro.template;
    } else {
        introTemplate = `╔──☉ INTRO MEMBER
│ ✦ Nama: •••
│ ✦ Umur: •••
│ ✦ Gender: •••
│ ✦ Askot: •••
╚────────────☉`;
    }
    
    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `🎀 Template intro siap pakai! Klik tombol di bawah untuk *copy paste*.`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `${botname2}`
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: true,
                        imageMessage: (await prepareWAMessageMedia(
                            { image: { url: global.image.menu } }, 
                            { upload: raiden.waUploadToServer }
                        )).imageMessage
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text":"Copy Intro","id":"copy_intro","copy_code":"${introTemplate}"}`
                            }
                        ]
                    })
                })
            }
        }
    }, {});

    await raiden.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

export default handler;
