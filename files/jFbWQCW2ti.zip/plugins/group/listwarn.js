const pluginConfig = {
  name: 'listwarn',
  category: 'group',
  command: ['listwarn'],
};

const handler = async (m, ctx) => {
    let { Reply, loadWarnDB } = ctx;
    if (!m.isGroup) return Reply('❌ Hanya grup');
    
    const warnDB = loadWarnDB();
    if (!warnDB[m.chat] || Object.keys(warnDB[m.chat]).length === 0) {
        return Reply('❌ Tidak ada warn di grup ini');
    }
    
    let message = '📋 Daftar Warn\n';
    const users = Object.entries(warnDB[m.chat]);
    
    users.forEach(([jid, data], index) => {
        message += `${index + 1}. ${data.name}\n`;
        message += `   ⚠️ ${data.count} warn\n`;
    });
    
    message += `\nTotal: ${users.length} user`;
    
    const mentions = users.map(([jid]) => jid);
    await Reply(message, mentions);
};

export default handler;
