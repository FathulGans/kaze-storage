const pluginConfig = {
  name: 'setintro',
  category: 'group',
  command: ['setintro'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, text } = ctx;
    if (!m.isGroup) return Reply('❌ Command ini hanya untuk grup!');
    if (!m.isAdmin && !isVip) return Reply('❌ Hanya admin grup!');
    
    if (!text) return Reply('Format: .setintro <template_intro>\nContoh: .setintro ╔──☉ INTRO\n├ ◦ Nama: •••\n├ ◦ Umur: •••\n╚────────────☉');
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    if (!global.db.groups[m.chat].intro) global.db.groups[m.chat].intro = {};
    
    global.db.groups[m.chat].intro.template = text;
    global.db.groups[m.chat].intro.setBy = m.sender;
    global.db.groups[m.chat].intro.setAt = Date.now();
    
    await Reply('✅ Template intro berhasil disimpan!\nGunakan .intro untuk menampilkan template ini.');
};

export default handler;
