const pluginConfig = {
  name: 'alarm',
  category: 'group',
  command: ['alarm'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, kirimAman, raiden, soketTerkini, text, troli } = ctx;
if (!m.isGroup) return Reply(global.mess.group||'⚠️ Hanya di grup!');
if (!isVip && !m.isAdmin) return Reply(global.mess.admin);
if (!text) return Reply('Format: *.alarm HH:MM|pesan*\nContoh: .alarm 08:00|Jangan lupa absen!\nKetik *.alarm off* untuk mematikan.');
if (text.trim().toLowerCase()==='off') {
    if (global._alarmDB?.[m.chat]?.interval) clearInterval(global._alarmDB[m.chat].interval);
    if (global._alarmDB) delete global._alarmDB[m.chat];
    return Reply('⏰ Alarm berhasil dimatikan!');
}
if (!text.includes('|')) return Reply('Format: *.alarm HH:MM|pesan*');
const [_almT,..._almP] = text.split('|');
const [_almH,_almM] = _almT.trim().split(':').map(Number);
if (isNaN(_almH)||isNaN(_almM)||_almH>23||_almM>59) return Reply('❌ Format waktu tidak valid! Gunakan HH:MM');
const _almPesan = _almP.join('|').trim()||'Waktunya alarm!';
if (!global._alarmDB) global._alarmDB = {};
if (global._alarmDB[m.chat]?.interval) clearInterval(global._alarmDB[m.chat].interval);
const _almInt = setInterval(async()=>{
    if (!soketTerkini(raiden)) { clearInterval(_almInt); return; }
    const _n = new Date(); if(_n.getHours()===_almH&&_n.getMinutes()===_almM){
    await kirimAman(raiden, m.chat,{text:`⏰ *ALARM!*\n\n${_almPesan}\n\n_${new Date().toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}_`}, { quoted: troli }, 'alarm').catch(e => console.error('[alarm]', e?.message || e));}
},30000);
global._alarmDB[m.chat] = { jam:`${String(_almH).padStart(2,'0')}:${String(_almM).padStart(2,'0')}`, pesan:_almPesan, interval:_almInt };
Reply(`⏰ *Alarm berhasil diset!*\n\n🕐 Waktu: ${String(_almH).padStart(2,'0')}:${String(_almM).padStart(2,'0')}\n💬 Pesan: ${_almPesan}\n\nKetik *.alarm off* untuk mematikan.`);
};

export default handler;
