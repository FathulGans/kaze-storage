const pluginConfig = {
  name: 'linkgc',
  category: 'group',
  command: ['linkgc'],
};

const handler = async (m, ctx) => {
    let { Reply, raiden } = ctx;
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await raiden.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await raiden.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
};

export default handler;
