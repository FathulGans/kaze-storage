const pluginConfig = {
  name: 'tagme',
  category: 'group',
  command: ['tagme'],
};

const handler = async (m, ctx) => {
    let { daftar, isVip, raiden, troli } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    raiden.sendMessage(m.chat, {
        text: `Halo peler @${m.sender.split('@')[0]}!`,
        mentions: [m.sender]
    }, { quoted: troli });
};

export default handler;
