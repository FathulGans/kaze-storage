const pluginConfig = {
  name: 'antidelete',
  category: 'group',
  command: ['antidelete'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antidelete = true;
        if (!global.db.groups[m.chat].antideleteMessages) {
            global.db.groups[m.chat].antideleteMessages = {};
        }
        Reply(`✅ *Antidelete diaktifkan*\n\nBot akan menyimpan dan mengembalikan pesan yang dihapus oleh anggota grup.`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antidelete = false;
        if (global.db.groups[m.chat].antideleteMessages) {
            global.db.groups[m.chat].antideleteMessages = {};
        }
        Reply(`❌ *Antidelete dimatikan*\n\nPesan yang dihapus tidak akan disimpan lagi.`);
    } else {
        const status = global.db.groups[m.chat].antidelete ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTIDELETE*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antidelete on - untuk mengaktifkan\n• ${prefix}antidelete off - untuk mematikan`);
    }
    return;
};

export default handler;
