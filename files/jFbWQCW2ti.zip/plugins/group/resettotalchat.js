import fs from 'fs';

const pluginConfig = {
  name: 'resettotalchat',
  category: 'group',
  command: ['resettotalchat'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden } = ctx;
    if (!m.isGroup) return Reply(mess.group);
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    const levelDBPath = './library/database/level.json';
    if (!fs.existsSync(levelDBPath)) return Reply('❌ Database tidak ditemukan');
    
    const levelDB = JSON.parse(fs.readFileSync(levelDBPath));
    
    if (!levelDB[m.chat] || Object.keys(levelDB[m.chat]).length === 0) {
        return Reply('❌ Tidak ada data chat yang perlu di-reset');
    }
    
    let totalMessages = 0;
    let activeMembers = 0;
    
    for (const jid in levelDB[m.chat]) {
        const messages = levelDB[m.chat][jid].messages || 0;
        if (messages > 0) {
            activeMembers++;
            totalMessages += messages;
        }
    }
    
    levelDB[m.chat] = {};
    fs.writeFileSync(levelDBPath, JSON.stringify(levelDB, null, 2));
    
    await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    
    Reply(`✅ Statistik pesan di-reset\n\nData dihapus:\n- Member aktif: ${activeMembers}\n- Total pesan: ${totalMessages.toLocaleString()}\n\nStatistik mulai dari 0 lagi.`);
};

export default handler;
