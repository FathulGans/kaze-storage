const pluginConfig = {
  name: 'antifoto',
  category: 'group',
  command: ['antifoto'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antifoto = true;
        if (!global.db.groups[m.chat].antifoto) {
            global.db.groups[m.chat].antifoto = {};
        }
        Reply(`✅ *antifoto diaktifkan*\n\nBot akan  menghapus gambar yang dikirim oleh anggota grup.`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antifoto = false;
        if (global.db.groups[m.chat].antifoto) {
            global.db.groups[m.chat].antifoto = {};
        }
        Reply(`❌ *antifoto dimatikan*\n\nBot tidak akan menghapus gambar lagi`);
    } else {
        const status = global.db.groups[m.chat].antifoto ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTI FOTO*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antifoto on - untuk mengaktifkan\n• ${prefix}antifoto off - untuk mematikan`);
    }
    return;
};

export default handler;
