const pluginConfig = {
  name: 'antivideo',
  category: 'group',
  command: ['antivideo'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antivideo = true;
        if (!global.db.groups[m.chat].antivideo) {
            global.db.groups[m.chat].antivideo = {};
        }
        Reply(`✅ *anti video diaktifkan*\n\nBot akan  menghapus video yang dikirim oleh anggota grup.`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antivideo = false;
        if (global.db.groups[m.chat].antivideo) {
            global.db.groups[m.chat].antivideo = {};
        }
        Reply(`❌ *anti video dimatikan*\n\nBot tidak akan menghapus video lagi`);
    } else {
        const status = global.db.groups[m.chat].antivideo ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTI VIDEO*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antivideo on - untuk mengaktifkan\n• ${prefix}antivideo off - untuk mematikan`);
    }
    return;
};

export default handler;
