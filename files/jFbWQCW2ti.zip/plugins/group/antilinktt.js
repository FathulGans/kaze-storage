const pluginConfig = {
  name: 'antilinktt',
  category: 'group',
  command: ['antilinktt'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].antilinktt = true;
        if (!global.db.groups[m.chat].antilinktt) {
            global.db.groups[m.chat].antilinktt = {};
        }
        Reply(`✅ *MODE ANTI LINK TIKTOK DIAKTIFKAN*`);
    } else if (action === 'off') {
        global.db.groups[m.chat].antilinktt = false;
        if (global.db.groups[m.chat].antilinktt) {
            global.db.groups[m.chat].antilinktt = {};
        }
        Reply(`❌ *MODE ANTI LINK TIKTOK DIMATIKAN*`);
    } else {
        const status = global.db.groups[m.chat].antilinktt ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING ANTI LINK TIKTOK MODE*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}antilinktt on - untuk mengaktifkan\n• ${prefix}antilinktt off - untuk mematikan`);
    }
    return;
};

export default handler;
