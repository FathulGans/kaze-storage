const pluginConfig = {
  name: 'jawabasah',
  category: 'group',
  command: ['jawabasah'],
};

const handler = async (m, ctx) => {
    let { Reply, text } = ctx;
    if (!global.asahJawaban) return Reply("⚠️ Belum ada soal asah otak! Ketik *.asahotak* dulu!");
    let jawabanUser = text.toLowerCase().trim();
    if (jawabanUser === global.asahJawaban) {
        Reply("✅ *Benar! Otak lo waras dan tajem!*");
    } else {
        Reply(`❌ *Salah!* Clue: Jawabannya ${global.asahJawaban.length} huruf.`);
    }
};

export default handler;
