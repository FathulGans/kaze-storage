import fs from 'fs';
import moment from 'moment-timezone';

const pluginConfig = {
  name: 'setwelcome',
  category: 'group',
  command: ['setwelcome'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, raiden, text, welcomeDB, welcomePath } = ctx;
 if (!m.isGroup) return Reply(mess.group);
 if (!m.isAdmin && !isVip) return Reply(mess.admin);

 const teksWelcome = (text || '').trim();

 if (!teksWelcome) {
 const sekarang = welcomeDB[m.chat]?.welcomeText || '(belum diatur, pakai teks default)';
 return Reply(`*Format:* ${prefix}setwelcome <template_pesan>

*Variabel yang tersedia:*
- @user : tag user yang join
- @group : nama grup
- @totalmember : total member grup saat ini
- @datenow : hari, tanggal, jam (WIB)

*Contoh:*
- ${prefix}setwelcome Halo @user, selamat datang di @group. Kamu member ke-@totalmember, @datenow

*Reset ke default:* ${prefix}setwelcome reset

*Teks saat ini:*
${sekarang}`);
 }

 if (teksWelcome.toLowerCase() === 'reset') {
 if (welcomeDB[m.chat]) delete welcomeDB[m.chat].welcomeText;
 fs.writeFileSync(welcomePath, JSON.stringify(welcomeDB, null, 2));
 return Reply('*Teks welcome dikembalikan ke default.*');
 }

 if (teksWelcome.length > 1000) return Reply('Teks welcome terlalu panjang, maksimal 1000 karakter.');

 if (!welcomeDB[m.chat]) welcomeDB[m.chat] = {};
 welcomeDB[m.chat].welcomeText = teksWelcome;

 fs.writeFileSync(welcomePath, JSON.stringify(welcomeDB, null, 2));
 const previewDate = moment().tz('Asia/Jakarta').format('dddd, DD MMMM YYYY HH:mm:ss [WIB]');
 const previewText = teksWelcome
 .replace(/@user/g, `@${m.sender.split('@')[0]}`)
 .replace(/@group/g, m.metadata?.subject || 'Nama Grup')
 .replace(/@totalmember/g, () => m.metadata?.participants?.length || 0)
 .replace(/@datenow/g, previewDate);

 await raiden.sendMessage(m.chat, {
 text: `*Teks welcome berhasil disimpan!*\n\n*Preview:*\n${previewText}`,
 mentions: [m.sender]
 }, { quoted: m });
};

export default handler;
