import fs from 'fs';

const pluginConfig = {
  name: 'topaktif',
  category: 'group',
  command: ['topaktif', 'leaderboardchat', 'lbchat'],
};

const handler = async (m, konteksInti) => {
    let { Reply, daftar, isPremium, isVip, raiden, safeErr } = konteksInti;
 if (!m.isGroup) return Reply('❌ Perintah ini hanya untuk grup!');
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
 
 await raiden.sendMessage(m.chat, { react: { text: "📊", key: m.key } });
 
 try {
 const levelDBPath = './library/database/level.json';
 if (!fs.existsSync(levelDBPath)) {
 return Reply('❌ Belum ada data chat di grup ini!');
 }
 
 const levelDB = JSON.parse(fs.readFileSync(levelDBPath, 'utf8'));
 const groupData = levelDB[m.chat];
 
 if (!groupData || Object.keys(groupData).length === 0) {
 return Reply('❌ Belum ada data chat di grup ini!\n\nMulai chatting agar data tercatat.');
 }
 
 let groupMetadata = null;
 try { groupMetadata = await raiden.groupMetadata(m.chat); } catch (e) { console.error(e); }
 
 const users = Object.entries(groupData)
 .map(([jid, data]) => ({ 
 jid: jid, 
 messages: data.messages || 0,
 level: data.level || 1,
 xp: data.xp || 0
 }))
 .sort((a, b) => b.messages - a.messages)
 .slice(0, 15);
 
 if (users.length === 0) return Reply('❌ Belum ada data member aktif!');
 
 const totalMessages = Object.values(groupData).reduce((sum, d) => sum + (d.messages || 0), 0);
 const totalMembers = Object.keys(groupData).length;
 
 const { createCanvas, loadImage } = (await import('canvas')).default;
 
 const W = 1080;
 const HEADER_H = 170;
 const ROW_H = 95;
 const FOOTER_H = 55;
 const H = HEADER_H + users.length * ROW_H + FOOTER_H;
 
 const canvas = createCanvas(W, H);
 const ctx = canvas.getContext('2d');
 
 function roundRect(x, y, w, h, r) {
 if (w < 2 * r) r = w / 2;
 if (h < 2 * r) r = h / 2;
 ctx.beginPath();
 ctx.moveTo(x + r, y);
 ctx.lineTo(x + w - r, y);
 ctx.quadraticCurveTo(x + w, y, x + w, y + r);
 ctx.lineTo(x + w, y + h - r);
 ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
 ctx.lineTo(x + r, y + h);
 ctx.quadraticCurveTo(x, y + h, x, y + h - r);
 ctx.lineTo(x, y + r);
 ctx.quadraticCurveTo(x, y, x + r, y);
 ctx.closePath();
 }
 
 function drawStar(cx, cy, r, spikes) {
 let rot = Math.PI / 2 * 3;
 let step = Math.PI / spikes;
 ctx.beginPath();
 for (let i = 0; i < spikes; i++) {
 let x1 = cx + Math.cos(rot) * r;
 let y1 = cy + Math.sin(rot) * r;
 let x2 = cx + Math.cos(rot + step / 2) * (r * 0.5);
 let y2 = cy + Math.sin(rot + step / 2) * (r * 0.5);
 if (i === 0) ctx.moveTo(x1, y1);
 else ctx.lineTo(x1, y1);
 ctx.lineTo(x2, y2);
 rot += step;
 }
 ctx.closePath();
 ctx.fill();
 }
 
 const bgGrad = ctx.createLinearGradient(0, 0, W, H);
 bgGrad.addColorStop(0, '#0a0e1a');
 bgGrad.addColorStop(0.5, '#12182a');
 bgGrad.addColorStop(1, '#0a0e1a');
 ctx.fillStyle = bgGrad;
 ctx.fillRect(0, 0, W, H);
 
 ctx.fillStyle = 'rgba(59,130,246,0.08)';
 for (let x = 0; x < W; x += 45) {
 for (let y = 0; y < H; y += 45) {
 ctx.beginPath();
 ctx.arc(x, y, 2, 0, Math.PI * 2);
 ctx.fill();
 }
 }
 
 ctx.strokeStyle = 'rgba(59,130,246,0.05)';
 ctx.lineWidth = 1;
 for (let x = 0; x <= W; x += 90) {
 ctx.beginPath();
 ctx.moveTo(x, 0);
 ctx.lineTo(x, H);
 ctx.stroke();
 }
 for (let y = 0; y <= H; y += 90) {
 ctx.beginPath();
 ctx.moveTo(0, y);
 ctx.lineTo(W, y);
 ctx.stroke();
 }
 
 const headerGlow = ctx.createRadialGradient(W / 2, 0, 0, W / 2, 0, 400);
 headerGlow.addColorStop(0, 'rgba(59,130,246,0.25)');
 headerGlow.addColorStop(1, 'rgba(59,130,246,0)');
 ctx.fillStyle = headerGlow;
 ctx.fillRect(0, 0, W, HEADER_H);
 
 ctx.shadowColor = 'rgba(59,130,246,0.3)';
 ctx.shadowBlur = 20;
 ctx.fillStyle = 'rgba(18,25,45,0.95)';
 roundRect(35, 20, W - 70, HEADER_H - 25, 18);
 ctx.fill();
 ctx.shadowBlur = 0;
 
 ctx.strokeStyle = 'rgba(59,130,246,0.4)';
 ctx.lineWidth = 1.5;
 roundRect(35, 20, W - 70, HEADER_H - 25, 18);
 ctx.stroke();
 
 const accentGrad = ctx.createLinearGradient(35, 0, W - 35, 0);
 accentGrad.addColorStop(0, 'rgba(59,130,246,0)');
 accentGrad.addColorStop(0.3, '#3b82f6');
 accentGrad.addColorStop(0.7, '#10b981');
 accentGrad.addColorStop(1, 'rgba(16,185,129,0)');
 ctx.fillStyle = accentGrad;
 roundRect(35, 20, W - 70, 3, 2);
 ctx.fill();
 
 const waveX = W / 2 - 60;
 const waveY = 58;
 for (let i = 0; i < 5; i++) {
 const height = 12 + i * 4;
 ctx.fillStyle = i % 2 === 0 ? '#3b82f6' : '#10b981';
 ctx.fillRect(waveX + i * 12, waveY + (24 - height / 2), 6, height);
 ctx.fillRect(waveX - (i + 1) * 12, waveY + (24 - height / 2), 6, height);
 }
 
 ctx.fillStyle = '#ffffff';
 ctx.font = 'bold 34px "Segoe UI", Arial';
 ctx.textAlign = 'center';
 ctx.shadowColor = '#3b82f6';
 ctx.shadowBlur = 12;
 ctx.fillText('TOP AKTIF', W / 2, 88);
 ctx.shadowBlur = 0;
 
 const groupName = groupMetadata?.subject ? groupMetadata.subject.slice(0, 38) : 'Group Chat';
 ctx.fillStyle = 'rgba(180,200,255,0.65)';
 ctx.font = '14px Arial';
 ctx.fillText(`✦ ${groupName} ✦`, W / 2, 118);
 
 ctx.fillStyle = 'rgba(100,200,255,0.5)';
 ctx.font = '12px Arial';
 ctx.fillText(`${users.length} Member Aktif | 💬 ${totalMessages.toLocaleString()} Pesan | 👥 ${totalMembers} Total`, W / 2, 150);
 
 let caption = `💬 *TOP ${users.length} MEMBER AKTIF*\n`;
 if (groupMetadata?.subject) caption += `📌 Grup: *${groupMetadata.subject}*\n`;
 caption += `📊 Total Pesan: ${totalMessages.toLocaleString()}\n`;
 caption += `👥 Total Member: ${totalMembers}\n\n`;
 let mentions = [];
 
 for (let i = 0; i < users.length; i++) {
 const user = users[i];
 const Y = HEADER_H + i * ROW_H;
 const isTop3 = i < 3;
 const maxMsg = users[0]?.messages || 1;
 const progress = Math.min(Math.floor((user.messages / maxMsg) * 100), 100);
 
 let rankColor, rankGlow, rankBg;
 if (i === 0) { rankColor = '#fbbf24'; rankGlow = 'rgba(251,191,36,0.3)'; rankBg = 'rgba(251,191,36,0.08)'; }
 else if (i === 1) { rankColor = '#d1d5db'; rankGlow = 'rgba(209,213,219,0.25)'; rankBg = 'rgba(209,213,219,0.06)'; }
 else if (i === 2) { rankColor = '#cd7c3c'; rankGlow = 'rgba(205,124,60,0.25)'; rankBg = 'rgba(180,83,9,0.08)'; }
 else { rankColor = '#6b7280'; rankGlow = 'rgba(107,114,128,0.15)'; rankBg = 'rgba(107,114,128,0.05)'; }
 
 ctx.shadowColor = rankGlow;
 ctx.shadowBlur = isTop3 ? 12 : 0;
 ctx.fillStyle = isTop3 ? rankBg : (i % 2 === 0 ? 'rgba(25,35,55,0.75)' : 'rgba(20,28,45,0.75)');
 roundRect(35, Y + 5, W - 70, ROW_H - 10, 12);
 ctx.fill();
 
 if (isTop3) {
 ctx.strokeStyle = rankColor + '66';
 ctx.lineWidth = 1.2;
 roundRect(35, Y + 5, W - 70, ROW_H - 10, 12);
 ctx.stroke();
 }
 ctx.shadowBlur = 0;
 
 const accentGradRow = ctx.createLinearGradient(35, Y + 5, 35 + 5, Y + 5);
 accentGradRow.addColorStop(0, rankColor);
 accentGradRow.addColorStop(1, 'rgba(0,0,0,0)');
 ctx.fillStyle = accentGradRow;
 roundRect(35, Y + 5, 5, ROW_H - 10, 2);
 ctx.fill();
 
 const ROW_MID_Y = Y + (ROW_H - 10) / 2 + 5;
 
 const rankX = 85;
 ctx.shadowColor = rankGlow;
 ctx.shadowBlur = isTop3 ? 15 : 8;
 ctx.fillStyle = rankColor + '22';
 ctx.beginPath();
 ctx.arc(rankX, ROW_MID_Y, 22, 0, Math.PI * 2);
 ctx.fill();
 ctx.strokeStyle = rankColor;
 ctx.lineWidth = 2;
 ctx.stroke();
 ctx.shadowBlur = 0;
 
 ctx.fillStyle = rankColor;
 ctx.font = `bold ${isTop3 ? 26 : 22}px Arial`;
 ctx.textAlign = 'center';
 ctx.fillText(`${i + 1}`, rankX, ROW_MID_Y + 8);
 
 const avatarX = 150;
 const avatarR = 30;
 
 ctx.save();
 ctx.beginPath();
 ctx.arc(avatarX, ROW_MID_Y, avatarR, 0, Math.PI * 2);
 ctx.closePath();
 ctx.clip();
 
 try {
 let ppUrl = '';
 try { ppUrl = await raiden.profilePictureUrl(user.jid, 'image'); } catch (e) { console.error(e); }
 if (ppUrl) {
 const avatarImg = await loadImage(ppUrl);
 ctx.drawImage(avatarImg, avatarX - avatarR, ROW_MID_Y - avatarR, avatarR * 2, avatarR * 2);
 } else {
 ctx.fillStyle = '#2d3555';
 ctx.fillRect(avatarX - avatarR, ROW_MID_Y - avatarR, avatarR * 2, avatarR * 2);
 }
 } catch {
 ctx.fillStyle = '#2d3555';
 ctx.fillRect(avatarX - avatarR, ROW_MID_Y - avatarR, avatarR * 2, avatarR * 2);
 }
 ctx.restore();
 
 ctx.shadowColor = rankGlow;
 ctx.shadowBlur = isTop3 ? 10 : 5;
 ctx.strokeStyle = rankColor;
 ctx.lineWidth = isTop3 ? 2.5 : 1.5;
 ctx.beginPath();
 ctx.arc(avatarX, ROW_MID_Y, avatarR + 3, 0, Math.PI * 2);
 ctx.stroke();
 ctx.shadowBlur = 0;
 
 let displayName = user.jid.split('@')[0];
 if (groupMetadata?.participants) {
 const p = groupMetadata.participants.find(x => [x.id, x.jid, x.lid].includes(user.jid));
 if (p?.notify) displayName = p.notify;
 }
 
 const nameX = 210;
 ctx.fillStyle = '#ffffff';
 ctx.font = `bold ${isTop3 ? 19 : 17}px "Segoe UI", Arial`;
 ctx.textAlign = 'left';
 const clippedName = displayName.length > 22 ? displayName.slice(0, 20) + '..' : displayName;
 ctx.fillText(clippedName, nameX, ROW_MID_Y - 12);
 
 ctx.fillStyle = 'rgba(59,130,246,0.2)';
 roundRect(nameX, ROW_MID_Y - 8, 55, 22, 8);
 ctx.fill();
 ctx.fillStyle = '#60a5fa';
 ctx.font = '11px Arial';
 ctx.fillText(`Level ${user.level}`, nameX + 5, ROW_MID_Y + 5);
 
 ctx.fillStyle = 'rgba(16,185,129,0.2)';
 roundRect(nameX + 65, ROW_MID_Y - 8, 70, 22, 8);
 ctx.fill();
 ctx.fillStyle = '#34d399';
 ctx.fillText(`${user.messages.toLocaleString()} pesan`, nameX + 70, ROW_MID_Y + 5);
 
 const barX = nameX;
 const barY = ROW_MID_Y + 18;
 const barW = 360;
 const barH = 8;
 
 ctx.fillStyle = 'rgba(255,255,255,0.06)';
 roundRect(barX, barY, barW, barH, 4);
 ctx.fill();
 
 const fillW = Math.max((progress / 100) * barW, 0);
 if (fillW > 0) {
 const barGrad = ctx.createLinearGradient(barX, barY, barX + fillW, barY);
 barGrad.addColorStop(0, '#3b82f6');
 barGrad.addColorStop(1, '#10b981');
 ctx.fillStyle = barGrad;
 ctx.shadowColor = '#10b981';
 ctx.shadowBlur = 4;
 roundRect(barX, barY, fillW, barH, 4);
 ctx.fill();
 ctx.shadowBlur = 0;
 }
 
 ctx.fillStyle = 'rgba(180,200,255,0.6)';
 ctx.font = '11px Arial';
 ctx.fillText(`${progress}%`, barX + barW + 12, barY + 8);
 
 const badgeW = 90;
 const badgeH = 40;
 const badgeX = W - 85;
 
 ctx.shadowColor = rankGlow;
 ctx.shadowBlur = isTop3 ? 12 : 6;
 ctx.fillStyle = rankColor + '1a';
 roundRect(badgeX - badgeW, ROW_MID_Y - badgeH / 2, badgeW, badgeH, 10);
 ctx.fill();
 ctx.strokeStyle = rankColor + '66';
 ctx.lineWidth = 1.5;
 roundRect(badgeX - badgeW, ROW_MID_Y - badgeH / 2, badgeW, badgeH, 10);
 ctx.stroke();
 ctx.shadowBlur = 0;
 
 ctx.fillStyle = rankColor;
 ctx.beginPath();
 ctx.moveTo(badgeX - badgeW + 15, ROW_MID_Y - 8);
 ctx.lineTo(badgeX - badgeW + 25, ROW_MID_Y - 8);
 ctx.lineTo(badgeX - badgeW + 25, ROW_MID_Y + 2);
 ctx.lineTo(badgeX - badgeW + 15, ROW_MID_Y + 2);
 ctx.fill();
 ctx.beginPath();
 ctx.moveTo(badgeX - badgeW + 19, ROW_MID_Y + 2);
 ctx.lineTo(badgeX - badgeW + 22, ROW_MID_Y + 8);
 ctx.lineTo(badgeX - badgeW + 25, ROW_MID_Y + 2);
 ctx.fill();
 
 ctx.fillStyle = rankColor;
 ctx.font = `bold ${isTop3 ? 18 : 16}px Arial`;
 ctx.textAlign = 'center';
 ctx.fillText(user.messages.toLocaleString(), badgeX - badgeW / 2, ROW_MID_Y + 6);
 
 mentions.push(user.jid);
 const medalIcon = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
 caption += `${medalIcon} @${user.jid.split('@')[0]} • ${user.messages.toLocaleString()} pesan • Lv.${user.level}\n`;
 }
 
 const footerY = H - FOOTER_H;
 
 const sepGrad = ctx.createLinearGradient(35, footerY, W - 35, footerY);
 sepGrad.addColorStop(0, 'rgba(59,130,246,0)');
 sepGrad.addColorStop(0.3, 'rgba(59,130,246,0.4)');
 sepGrad.addColorStop(0.7, 'rgba(16,185,129,0.4)');
 sepGrad.addColorStop(1, 'rgba(16,185,129,0)');
 ctx.strokeStyle = sepGrad;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(35, footerY + 10);
 ctx.lineTo(W - 35, footerY + 10);
 ctx.stroke();
 
 ctx.fillStyle = 'rgba(180,200,255,0.35)';
 ctx.font = '12px Arial';
 ctx.textAlign = 'center';
 ctx.fillText(`✦ ${global.botname || 'Bot'} • Aktif chat untuk masuk leaderboard! ✦`, W / 2, footerY + 30);
 
 caption += `\n✨ *Aktif chat untuk naik peringkat!*`;
 
 const buffer = canvas.toBuffer('image/png');
 
 await raiden.sendMessage(m.chat, {
 image: buffer,
 caption: caption,
 mentions: mentions
 }, { quoted: m });
 
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error('[TOPAKTIF ERROR]', error);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${safeErr(error) || 'Coba lagi nanti'}`);
 }
};

export default handler;
