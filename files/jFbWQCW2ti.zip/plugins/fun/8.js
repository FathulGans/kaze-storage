const pluginConfig = {
  name: '8',
  category: 'fun',
  command: ['8'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden, troli } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 try {
 var _audioUrl = 'https://raw.githubusercontent.com/Archiokeceabiez/shadow-tourl-storage/main/uploads/kelvin-evernight-1780831738597.mp3';

 await m.react('💐');

 await Reply("Whops💐");

 await raiden.sendMessage(m.chat, {
 audio: { url: _audioUrl },
 mimetype: 'audio/mp4',
 ptt: true,
 waveform: [0, 20, 50, 80, 100, 80, 50, 20, 0]
 }, { quoted: troli });

 await m.react('🌹');

 } catch (e) {
 console.error('Error Fitur 5149:', e.message);
 await m.react('❌');
 Reply("⚠️ Gagal memutar suara, link bermasalah atau server sibuk.");
 }
};

export default handler;
