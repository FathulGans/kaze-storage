const pluginConfig = {
  name: 'notifgempa',
  category: 'fun',
  command: ['notifgempa'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip, prefix } = ctx;
    if (!m.isGroup) return
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
        global.db.groups[m.chat].notifgempa = true;
        Reply(`✅ *Notif Gempa diaktifkan*\n\nGrup ini akan menerima notifikasi otomatis setiap ada info gempa terbaru dari BMKG.`);
    } else if (action === 'off') {
        global.db.groups[m.chat].notifgempa = false;
        Reply(`❌ *Notif Gempa dimatikan*\n\nGrup ini tidak akan menerima notifikasi gempa lagi.`);
    } else {
        const status = global.db.groups[m.chat].notifgempa ? 'Aktif' : 'Mati';
        Reply(`🔧 *SETTING NOTIF GEMPA*\n\nStatus: ${status}\n\nGunakan:\n• ${prefix}notifgempa on - untuk mengaktifkan\n• ${prefix}notifgempa off - untuk mematikan`);
    }
    return;
};

export default handler;
