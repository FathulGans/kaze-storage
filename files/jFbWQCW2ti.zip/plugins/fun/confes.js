import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'confes',
  category: 'fun',
  command: ['confes'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, text } = ctx;
    if (!global.confessCooldown) global.confessCooldown = {}

if (!tierAkses.isPrem(m.sender) && !isVip) 
        return Reply(mess.prem);
    const cdTime = 10 * 60 * 1000; 
    if (global.confessCooldown[m.sender] && (Date.now() - global.confessCooldown[m.sender]) < cdTime) {
        let sisa = ((cdTime - (Date.now() - global.confessCooldown[m.sender])) / 1000 / 60).toFixed(1);
        return Reply(`⏳ Tunggu *${sisa} menit* dulu sebelum pake .confes lagi!`);
    }
    global.confessCooldown[m.sender] = Date.now();
    if (!text) 
        return raiden.sendMessage(m.chat, { 
            text: `🚨 *Contoh:* .confes 628123456789 Hai, aku suka banget sama kamu\n\n📝 Tulis pesanmu dengan jelas ya!` 
        }, { quoted: m });

    const parts = text.trim().split(' ');
    const targetNumber = parts.shift().replace(/\D/g, '');
    const pesan = parts.join(' ');

    if (!pesan) return Reply(`❌ Isi pesan kosong!`);

    const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const captionConfes = `╭─💌 *PESAN RAHASIA* 💌
│🕒 *Waktu:* ${waktu}
│🧩 *Isi Pesan:*
${pesan.split('\n').map(line => '│ ' + line).join('\n')}
╰──────────────❏
🎯 *Pengirim anonim*`;

    const targetJid = targetNumber + '@s.whatsapp.net';
    const fotoUrl = 'https://img1.pixhost.to/images/8139/633650484_media.jpg';

    try {
        await raiden.sendMessage(targetJid, { 
            image: { url: fotoUrl }, 
            caption: captionConfes 
        });

        await raiden.sendMessage(m.chat, { 
            text: `✅ Pesan rahasia berhasil dikirim ke *${targetNumber}*!` 
        }, { quoted: m });
    } catch (e) {
        console.log(`❌ Gagal kirim pesan ke ${targetNumber}:`, e);
        await raiden.sendMessage(m.chat, { 
            text: `❌ Gagal mengirim pesan. Pastikan nomor benar dan bot bisa mengirim ke nomor tersebut.` 
        }, { quoted: m });
    }
};

export default handler;
