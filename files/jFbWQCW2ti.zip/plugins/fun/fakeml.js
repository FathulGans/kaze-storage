import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'fakeml',
  category: 'fun',
  command: ['fakeml'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, text, uploadCatbox, uploadKappaFile, uploadQu, uploadUguu } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi)
    if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit)

    const validRanks = ['warrior', 'elite', 'master', 'grandmaster', 'epic', 'legend', 'mythic', 'glory']
    const minBorder = 1
    const maxBorder = 20

    const qmsg = m.quoted ? m.quoted : m
    const qmime = (qmsg.msg || qmsg).mimetype || ''

    if (!/image/.test(qmime)) {
        return Reply(`🎮 *FAKE ML CARD*\n\n(wajib reply/kirim foto buat avatar)\n\nFormat: .fakeml username|rank|border\n\n📌 *Rank tersedia:*\n${validRanks.join(', ')}\n📌 *Border:* angka ${minBorder}-${maxBorder}\n📌 Bisa pakai kata *random* buat rank/border/keduanya\n\n*Contoh:*\n.fakeml ArcxHz|glory|11\n.fakeml ArcxHz|mythic|random\n.fakeml ArcxHz|random|random\n.fakeml ArcxHz *(rank & border otomatis random)*`)
    }
    if (!text) return Reply('❌ Username wajib diisi!\n\nContoh: .fakeml ArcxHz|glory|11')

    let [username, rankInput, borderInput] = text.split('|').map(v => v && v.trim())
    if (!username) return Reply('❌ Username wajib diisi!\n\nContoh: .fakeml ArcxHz|glory|11')

    let rank
    if (!rankInput || rankInput.toLowerCase() === 'random') {
        rank = validRanks[Math.floor(Math.random() * validRanks.length)]
    } else {
        rank = rankInput.toLowerCase()
        if (!validRanks.includes(rank)) {
            return Reply(`❌ Rank *${rankInput}* tidak valid!\n\nPilih salah satu: ${validRanks.join(', ')}\natau ketik *random*`)
        }
    }

    let border
    if (!borderInput || borderInput.toLowerCase() === 'random') {
        border = Math.floor(Math.random() * (maxBorder - minBorder + 1)) + minBorder
    } else {
        border = parseInt(borderInput)
        if (isNaN(border) || border < minBorder || border > maxBorder) {
            return Reply(`❌ Border harus angka ${minBorder}-${maxBorder}, atau ketik *random*`)
        }
    }

    addLimit(m.sender, tierAkses.isPrem(m.sender), isVip)
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    try {
        const avatarBuffer = await qmsg.download()
        const generateFilename = (mimeType) => {
            const extMap = { 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }
            return 'avatar-' + Date.now() + '-' + Math.floor(Math.random() * 9999) + '.' + (extMap[mimeType] || 'jpg')
        }
        const isValidUrl = (u) => typeof u === 'string' && /^https?:\/\//.test(u.trim())
        const apikey = global.apikeyKyzzCanvas || global.apikeyKyzz

        const uploaders = [
            { name: 'Kappa', fn: () => uploadKappaFile(avatarBuffer, qmime, generateFilename) },
            { name: 'Catbox', fn: () => uploadCatbox(avatarBuffer, qmime, generateFilename) },
            { name: 'Qu.ax', fn: () => uploadQu(avatarBuffer, qmime, generateFilename) },
            { name: 'Uguu', fn: () => uploadUguu(avatarBuffer, qmime, generateFilename) },
        ]

        let buffer = null
        let lastError = null

        for (const uploader of uploaders) {
            let avatarUrl = null
            try {
                const r = await uploader.fn()
                if (isValidUrl(r)) avatarUrl = r.trim()
            } catch (e) {
                console.error(`[fakeml] Upload ${uploader.name} gagal:`, e?.message || e)
                continue
            }
            if (!avatarUrl) continue

            try {
                const apiUrl = `https://api.kyzzz.xyz/api/canvas/fake-ml?avatar=${encodeURIComponent(avatarUrl)}&username=${encodeURIComponent(username)}&rank=${encodeURIComponent(rank)}&border=${border}&apikey=${apikey}`
                const res = await axios.get(apiUrl, { timeout: 20000, responseType: 'arraybuffer', validateStatus: () => true })
                const contentType = res.headers['content-type'] || ''

                let resultBuffer
                if (contentType.includes('application/json')) {
                    const json = JSON.parse(Buffer.from(res.data).toString('utf-8'))
                    const resultUrl = json?.result?.url || json?.result || json?.url || null
                    if (!resultUrl || typeof resultUrl !== 'string') {
                        throw new Error(json?.message || json?.error || `API menolak (host: ${uploader.name}): ${JSON.stringify(json).substring(0, 150)}`)
                    }
                    const imgRes = await axios.get(resultUrl, { responseType: 'arraybuffer', timeout: 15000 })
                    resultBuffer = Buffer.from(imgRes.data)
                } else {
                    resultBuffer = Buffer.from(res.data)
                }

                if (!resultBuffer || resultBuffer.length < 500) {
                    const asText = resultBuffer ? resultBuffer.toString('utf-8').substring(0, 150) : ''
                    throw new Error(`Response tidak valid (host: ${uploader.name}): ${asText || 'buffer kosong'}`)
                }

                buffer = resultBuffer
                break

            } catch (e) {
                lastError = e
                console.error(`[fakeml] API gagal pakai avatar dari ${uploader.name}:`, e?.message || e)
                continue
            }
        }

        if (!buffer) {
            throw new Error(lastError?.message || 'Semua percobaan gagal (hosting avatar & API tidak merespons dengan benar)')
        }

        await raiden.sendMessage(m.chat, {
            image: buffer,
            caption: `${mess.done}\n\n👤 Username: *${username}*\n🏆 Rank: *${rank.toUpperCase()}*\n🖼️ Border: *${border}*`
        }, { quoted: m })
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } })

    } catch (e) {
        console.error('[fakeml] error:', e?.message || e)
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        Reply(`❌ Gagal membuat fake ML card!\n\n${e.message || e}`)
    }
};

export default handler;
