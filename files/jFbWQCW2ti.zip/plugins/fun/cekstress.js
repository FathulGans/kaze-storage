import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'cekstress',
  category: 'fun',
  command: ['cekstress'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isVip } = ctx;
  if (!isRegistered(m.sender) && !isVip) return Reply(`❌ *KAMU BELUM TERDAFTAR*`);
  if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);

  
  let users = []
  if (m.isGroup) {
    if (m.mentionedJid.length) {
      users = m.mentionedJid.map(id => {
        if (id.endsWith('@lid')) {
          let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
          return p ? p.jid : null
        } else {
          return id
        }
      }).filter(Boolean)
    } else {
      users = args[0] ? [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'] : []
    }
  } else {
    users = args[0] ? [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'] : []
  }
  
  const user = users[0] || m.sender;
  const persen = Math.floor(Math.random() * 101);
  
  const barLength = 20;
  const filled = Math.round((persen / 100) * barLength);
  const empty = barLength - filled;
  const progressBar = '█'.repeat(filled) + '░'.repeat(empty);
  
  let title, emoji, desc, advice;
  
  if (persen >= 90) {
    title = "💀 MENTAL COLLAPSE";
    emoji = "💀";
    desc = "Sistem darurat! Segera cari pertolongan profesional.";
    advice = "🚨 Rekomendasi: Konsultasi psikolog, cuti panjang, digital detox";
  } else if (persen >= 75) {
    title = "🔥 BURN OUT EXTREME";
    emoji = "🔥";
    desc = "Overthinking level dewa. Setiap notifikasi = jantung copot.";
    advice = "💡 Rekomendasi: Istirahat total, meditasi, hobby baru";
  } else if (persen >= 60) {
    title = "⚡ HIGH STRESS";
    emoji = "⚡";
    desc = "50 tab pikiran terbuka, RAM otak overload.";
    advice = "🌿 Rekomendasi: Istirahat sejenak, olahraga ringan";
  } else if (persen >= 40) {
    title = "⚠️ MODERATE";
    emoji = "⚠️";
    desc = "Masih stabil tapi perlu waspada.";
    advice = "☕ Rekomendasi: Ngopi santai, dengarkan musik";
  } else if (persen >= 20) {
    title = "😐 LOW STRESS";
    emoji = "😐";
    desc = "Santai tapi tetap aware.";
    advice = "✨ Rekomendasi: Jaga pola hidup sehat";
  } else {
    title = "😎 SUPER CHILL";
    emoji = "😎";
    desc = "Zen master level. Dunia hancur tetap tenang.";
    advice = "🌟 Rekomendasi: Ajarkan rahasia ketenanganmu";
  }
  
  Reply(`
🌡️ *STRESS METER CHECK*

👤 User: @${user.split('@')[0]}

${progressBar} ${persen}%

${emoji} *LEVEL:* ${title}

📊 *STATISTICS:*
• Score: ${persen}/100
• Status: ${desc}

💬 *DESCRIPTION:*
${desc}

${advice}
  `.trim());
};

export default handler;
