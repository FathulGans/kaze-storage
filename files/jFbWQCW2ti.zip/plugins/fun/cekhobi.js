const pluginConfig = {
  name: 'cekhobi',
  category: 'fun',
  command: ['cekhobi', 'hobi'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, text, troli } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!m.isGroup) return Reply(global.mess.group);
    if (!m.quoted && m.mentionedJid.length === 0 && !text) return Reply(`Silakan tag user, reply pesan, atau ketik nama user yang ingin dicek hobinya!\nContoh: ${prefix + command} @user`);
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : null;
    let user = target ? `@${target.split('@')[0]}` : text;
    let mentions = target ? [target] : [];    
    const listHobi = [
        "Mancing Keributan", "Turu (Tidur)", "Ngoding JavaScript", "Maling Spek Bot", "Ghosting Orang", 
        "Dengerin Lagu Galau", "Main Game Sampai Pagi", "Nonton Anime/Wibu", "Ghibah (Rumpi)", 
        "Scroll TikTok Gak Jelas", "Bucin Gak Ada Hasil", "Olahraga (Lari dari Kenyataan)", 
        "Baca Wattpad", "Ngopi Sambil Melamun", "Makan Terus Tapi Gak Gendut", "Koleksi Stiker Lucu",
        "Jadi Beban Keluarga", "Cari Masalah Sama Admin", "Nge-spam Chat", "Deep Talk Sama Bot"
    ];
    let hobi = listHobi[Math.floor(Math.random() * listHobi.length)];
    let caption = `*── 「 CEK HOBI 」 ──*\n\n`;
    caption += `User: ${user}\n`;
    caption += `Hobi: *${hobi}*\n\n`;
    caption += `_Tingkatkan bakatmu, jangan kasih kendor!_`;
    raiden.sendMessage(m.chat, { 
        text: caption, 
        mentions: mentions 
    }, { quoted: troli });
};

export default handler;
