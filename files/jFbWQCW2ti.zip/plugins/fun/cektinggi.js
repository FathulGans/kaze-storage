const pluginConfig = {
  name: 'cektinggi',
  category: 'fun',
  command: ['cektinggi', 'cekberatbadan', 'cekhargadiri', 'cekkehebatan', 'cekskill', 'cekkekuattan'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, raiden, troli } = ctx;
 
 if (!isRegistered(m.sender) && !isVip) {
 return daftar(global.mess.verifikasi);
 }
 
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) {
 return Reply(global.mess.limit);
 }
 
 
 var _target = m.sender;
 
 if (m.mentionedJid && m.mentionedJid.length > 0) {
 _target = m.mentionedJid[0];
 } else if (m.quoted && m.quoted.sender) {
 _target = m.quoted.sender;
 }
 
 if (_target.endsWith('@lid') && m.metadata?.participants) {
 var _findTarget = m.metadata.participants.find(x => x.lid === _target || x.id === _target);
 if (_findTarget && _findTarget.jid) {
 _target = _findTarget.jid;
 } else {
 _target = globalThis.lidKeNomor(_target);
 }
 }
 
 var _numUser = _target.split('@')[0];
 
 var _pct = Math.floor(Math.random() * 100) + 1;
 var _val = _pct;
 var _suffix = "%"; 
 var _msg = "";
 var _lvl = "";
 var _emj = "";
 var _title = "";
 
 if (command === 'cektinggi') {
 _title = "TINGGI BADAN";
 _val = Math.floor(Math.random() * (220 - 120 + 1)) + 120; 
 _suffix = " cm";
 _pct = Math.max(0, Math.min(100, Math.floor(((_val - 120) / 100) * 100)));
 
 if (_val <= 130) {
 _lvl = "TUYUL KESASAR"; 
 _emj = "👶"; 
 _msg = "Sumpah @tag, lo ini manusia apa tuyul magang? Tinggi lo sebatas lutut orang dewasa. Kalau jalan di rumput awas ilang ketutupan. Mending lo daftar jadi kurcaci taman aja deh! 😭";
 }
 else if (_val <= 140) {
 _lvl = "MINION LEPAS"; 
 _emj = "🍄"; 
 _msg = "Ya elah @tag, cebol banget najis! Lo kalau ngambil barang di atas kulkas pasti harus pake kursi plastik kan? Makanya waktu kecil minum susu yang bener, bukan minum air kobokan! 🍼";
 }
 else if (_val <= 150) {
 _lvl = "BOCAH SD KECETIT"; 
 _emj = "🐥"; 
 _msg = "Tinggi lo nanggung amat @tag. Pendek banget iya, dibilang kurcaci juga kegedean. Kalau foto bareng temen lo pasti selalu ditaruh di depan kan biar gak ketutupan? Nasib jadi manusia bonsai! 📉";
 }
 else if (_val <= 158) {
 _lvl = "PENDEK BANTET"; 
 _emj = "🚶‍♂️"; 
 _msg = "Pendek bantet lo @tag. Lo kalau naik motor matic pasti harus jinjit balet kan di lampu merah? Gak usah sok-sokan modif motor deh, kaki lu aja kaga nyampe napak ke aspal! 🛵";
 }
 else if (_val <= 165) {
 _lvl = "NPC PAS-PASAN"; 
 _emj = "🗿"; 
 _msg = "Tinggi lo bener-bener pas-pasan @tag. Gak tinggi, gak pendek, cuma NPC figuran di dunia nyata. Lo kalau di keramaian otomatis tenggelam gak ada yang notice. Benar-benar madesu! 😑";
 }
 else if (_val <= 172) {
 _lvl = "NORMAL STANDAR"; 
 _emj = "👌"; 
 _msg = "Lumayan lah @tag, tinggi lo normal standar SNI. Udah pantes disebut manusia. Tapi tetep aja muka lo yang bikin minus. Tinggi doang tapi dompet kosong ya percuma bos, tetep kaga laku! 💸";
 }
 else if (_val <= 178) {
 _lvl = "IDEAL IDAMAN"; 
 _emj = "✨"; 
 _msg = "Wih @tag, tinggi lo ideal banget nih! Pantes pake baju apa aja. Tapi sayang, kepribadian lo toxic abis. Fisik bintang lima, kelakuan minus lima. Tuhan emang adil ngasih cobaan ke sekeliling lo. 💅";
 }
 else if (_val <= 186) {
 _lvl = "TIANG LISTRIK"; 
 _emj = "🗼"; 
 _msg = "Busyet @tag, lo makan bambu apa gimana? Ketinggian bos! Pasti lo sering jedot pintu kan? Kalo jalan bareng temen lo kayak lagi bawa anak TK jalan-jalan. Awas kesamber petir lu tiang listrik! ⚡";
 }
 else if (_val <= 195) {
 _lvl = "RAKSASA GABAN"; 
 _emj = "🦖"; 
 _msg = "FIX LO BUKAN MANUSIA @tag! Lo titan yang kabur dari tembok Wall Maria ya? Nunduk woy kalau lewat! Bikin repot orang sekitar aja badan segede gaban, naik angkot aja kepala lu nyangkut! 🚑";
 }
 else {
 _lvl = "ALIEN / JERAPAH"; 
 _emj = "🦒"; 
 _msg = "GILA @tag!!! Lo setinggi ini buat apaan anjir?! Mau benerin genteng tanpa tangga? Lo itu anomali genetik! Mending lo ikut main NBA sana daripada menuh-menuhin trotoar pejalan kaki! 🪐";
 }
 }
 
 else if (command === 'cekberatbadan') {
 _title = "BERAT BADAN";
 _val = Math.floor(Math.random() * (180 - 30 + 1)) + 30;
 _suffix = " kg";
 _pct = Math.max(0, Math.min(100, Math.floor(((_val - 30) / 150) * 100)));
 
 if (_val <= 40) {
 _lvl = "TENGKORAK HIDUP"; 
 _emj = "💀"; 
 _msg = "@tag lo hidup apa nunggu mati? Kurus kering kerontang kayak triplek! Ketiup angin kipas angin juga lo terbang beda dimensi. Jangan pelit amat ngasih makan badan sendiri, gizi buruk lo! 🥀";
 }
 else if (_val <= 50) {
 _lvl = "LIDI BERJALAN"; 
 _emj = "🥢"; 
 _msg = "Berat lo enteng banget @tag, persis kayak harga diri lo. Daging kaga ada, cuma kulit balut tulang. Kalo digigit nyamuk, nyamuknya yang nangis karena keras mentok tulang dada lu! 🦟";
 }
 else if (_val <= 60) {
 _lvl = "KREMPENG NANGGUNG"; 
 _emj = "🦴"; 
 _msg = "Krempeng amat lo @tag. Kalau pake baju kaos kegedean dikit udah kayak orang-orangan sawah. Mending lo rajin nge-gym deh atau makan nasi padang lauk ganda tiap hari biar berisi dikit! 👕";
 }
 else if (_val <= 70) {
 _lvl = "STANDAR PASARAN"; 
 _emj = "⚖️"; 
 _msg = "Berat lo pas-pasan @tag. Gak kurus, gak gendut. Ya aman lah buat standar manusia. Tapi awas ntar kalau putus cinta, biasanya langsung nyusut balik jadi tengkorak lagi. 💔";
 }
 else if (_val <= 80) {
 _lvl = "IDEAL / BERISI"; 
 _emj = "👌"; 
 _msg = "Mantap @tag, berat lo ideal dan berisi. Enak dipeluk katanya. Tapi jangan seneng dulu, buncit-buncit dikit di perut mulai keliatan tuh kalau lu lagi duduk. Olahraga woy! 🏃‍♂️";
 }
 else if (_val <= 90) {
 _lvl = "BAPAK-BAPAK BUNCIT"; 
 _emj = "🤰"; 
 _msg = "Wah @tag, perut lo udah maju duluan ngeduluin masa depan lo. Kebanyakan ngemil martabak jam 2 pagi ya? Baju lo mulai sesak tuh, siap-siap aja nyari ukuran XXL. Lemak berjalan! 🐖";
 }
 else if (_val <= 105) {
 _lvl = "OVERWEIGHT PARAH"; 
 _emj = "🐷"; 
 _msg = "GILA @tag! Timbangan aja teriak ampun pas lo naik! Lo napas aja udah ngos-ngosan kan abis naik tangga? Diet woy diet! Lo tuh beban bumi, kasian gravitasi harus nahan berat lo! 📉";
 }
 else if (_val <= 125) {
 _lvl = "KULKAS 2 PINTU"; 
 _emj = "🧊"; 
 _msg = "Busyet @tag, badan lo udah segede kulkas 2 pintu! Kalau lo masuk ke dalem lift, otomatis langsung alarm *overload* bunyi. Kurang-kurangin rakus, atau umur lu yang dikurangin sama Tuhan! ☠️";
 }
 else if (_val <= 150) {
 _lvl = "TRUK TRONTON"; 
 _emj = "🚛"; 
 _msg = "AMPUUUN @tag! Lo jalan di gang aja bikin macet, kaga ada space sisa! Kolesterol, asam urat, diabetes udah nungguin lo di depan pintu bawa karangan bunga. Udah gak ketolong lagi lu! 🏥";
 }
 else {
 _lvl = "BLACK HOLE / PLANET"; 
 _emj = "🌍"; 
 _msg = "100% BEBAN TATA SURYA @tag!!! Lo kalau loncat bikin gempa tektonik skala 8 richter! Lo punya medan gravitasi sendiri saking gedenya badan lo. Udah woy, setop makan sebelum bumi ini amblas! ☄️";
 }
 }
 
 else if (command === 'cekhargadiri') {
 _title = "HARGA DIRI";
 if (_pct <= 10) {
 _lvl = "KESET WELCOME"; 
 _emj = "🗑️"; 
 _msg = "Harga diri lo 0% @tag! Lo rela diinjek-injek, dimanfaatin, dipake doang trus dibuang. Lo itu lebih rendah dari keset 'Welcome' di depan Alfamart! Gak ada valuenya sama sekali jadi manusia. Jijik! 🤮";
 }
 else if (_pct <= 20) {
 _lvl = "BADUT KELAS KAKAP"; 
 _emj = "🤡"; 
 _msg = "Udah diselingkuhin berkali-kali tapi tetep ngemis balikan? BADUT ANCOL LO @tag! Lo cuma dijadiin pelarian kalau dia lagi bosen. Muka lo udah tebel banget kaga ada rasa malunya! 🎪";
 }
 else if (_pct <= 30) {
 _lvl = "GAMPANGAN"; 
 _emj = "💔"; 
 _msg = "Harga diri lo receh banget @tag. Gampang banget disetir sama orang lain. Lo gak punya pendirian, cuma bisa ngekor. Dikasih perhatian dikit langsung baper dan rela ngasih semuanya. Murahan! 💸";
 }
 else if (_pct <= 40) {
 _lvl = "SIMP AKUT"; 
 _emj = "🐶"; 
 _msg = "Lo itu definisi 'Anjing Peliharaan' @tag. Rela ngeluarin duit, tenaga, waktu buat orang yang bahkan nge-read chat lo aja butuh 3 hari. Hentikan kebucinan tolol ini sebelum lo gila! 📉";
 }
 else if (_pct <= 50) {
 _lvl = "PLIN-PLAN"; 
 _emj = "⚖️"; 
 _msg = "Harga diri lo 50-50 @tag. Kadang lo sok jaim, tapi kalau lagi butuh lo jilat ludah sendiri. Ego lo nanggung, harga diri lo juga goyah kena angin dikit. Bener-bener manusia standar! 🗿";
 }
 else if (_pct <= 60) {
 _lvl = "BANYAK GAYA DOANG"; 
 _emj = "🎭"; 
 _msg = "Sok-sokan punya harga diri tinggi, aslinya mental kerupuk lu @tag. Bacot doang di sosmed berkelas, di real life kalau dibentak dikit langsung kicep minta maaf. Cupu! 🦐";
 }
 else if (_pct <= 70) {
 _lvl = "PUNYA PRINSIP"; 
 _emj = "🛡️"; 
 _msg = "Bagus @tag, lo mulai punya prinsip. Gak gampang dimanfaatin orang. Kalau ada yang toxic, lo berani nge-cut mereka dari idup lo. Pertahankan bos, biarin circle lo kecil asal sehat! 🌿";
 }
 else if (_pct <= 80) {
 _lvl = "MAHAL & ELEGAN"; 
 _emj = "👑"; 
 _msg = "Lumayan @tag, lo tau cara ngehargain diri sendiri. Lo gak mau nongkrong sama orang benalu, dan lo tau kapan harus bilang 'TIDAK'. Terusin gaya elegan lo ini, biarin yang miskin mental pada kepanasan! 🥂";
 }
 else if (_pct <= 90) {
 _lvl = "SIGMA UNTOUCHABLE"; 
 _emj = "🗿"; 
 _msg = "Harga diri lo luar biasa tinggi @tag. Gak ada yang berani ngerendahin lo. Orang buang muka, lo buang mereka dari hidup lo tanpa basa-basi. Keren sih, tapi awas mati kesepian karena terlalu batu! 🐺";
 }
 else {
 _lvl = "GOD TIER GENGSI"; 
 _emj = "🌌"; 
 _msg = "LEVEL DEWA @tag! Saking tingginya harga diri lo, lo mending nahan lapar mati kelaparan daripada minta traktiran orang. Kesombongan lo udah nyentuh langit lapis ketujuh. Arogansi murni! 🔥";
 }
 }
 
 else if (command === 'cekkehebatan') {
 _title = "KEHEBATAN";
 if (_pct <= 10) {
 _lvl = "BEBAN BUMI"; 
 _emj = "💩"; 
 _msg = "Kehebatan lo cuma satu @tag: JADI BEBAN KELUARGA YANG PALING KONSISTEN! Gak ada hal positif dari idup lo, semuanya nyusahin. Oksigen yang lo hirup itu pemborosan sumber daya alam tau gak! 🚮";
 }
 else if (_pct <= 20) {
 _lvl = "KROCO PASARAN"; 
 _emj = "🐜"; 
 _msg = "Kroco banget lo @tag. Cuma berani bacot di grup WhatsApp, di real life lo kicep nunduk-nunduk pura-pura main HP. Gak punya prestasi, cuma ampas masyarakat yang buang-buang kuota internet! 😮‍💨";
 }
 else if (_pct <= 30) {
 _lvl = "MANUSIA GAGAL"; 
 _emj = "📉"; 
 _msg = "Lo hebat sih @tag, hebat dalam hal merusak segalanya! Apapun yang lo pegang pasti hancur. Kerjaan berantakan, hubungan asmara apalagi. Lo adalah definisi nyata dari produk gagal pabrik! 🚫";
 }
 else if (_pct <= 40) {
 _lvl = "FIGURAN GAK GUNA"; 
 _emj = "👻"; 
 _msg = "Di film kehidupan, lo cuma jadi figuran yang lewat sedetik terus mati ketabrak lari @tag. Kehebatan lo bener-bener gak ada gunanya. Lo mati besok juga dunia bakal baik-baik aja jalan terus! ⚰️";
 }
 else if (_pct <= 50) {
 _lvl = "RATA-RATA / NPC"; 
 _emj = "☕"; 
 _msg = "Kehebatan lo rata-rata. Ya lumayan lah bisa diajak ngerjain tugas walau lemot dikit. Cuma gitu-gitu aja, idup lo flat gak ada gebrakan. 10 tahun lagi juga nasib lo tetep jadi bawahan orang @tag. 🥱";
 }
 else if (_pct <= 60) {
 _lvl = "LUMAYAN DIANDALIN"; 
 _emj = "🛠️"; 
 _msg = "Lo lumayan hebat @tag. Di tongkrongan, lo sering jadi problem solver walau kadang solusi lo ngawur. Seenggaknya otak lo masih jalan buat hal-hal dasar kehidupan. Pertahankan! 🧩";
 }
 else if (_pct <= 70) {
 _lvl = "PRO PLAYER"; 
 _emj = "🔥"; 
 _msg = "Hebat juga lo @tag. Di circle lo, lo salah satu yang paling menonjol. Tapi inget, sepintar-pintarnya lo, masih ada langit di atas langit. Jangan sok jago dulu mentang-mentang baru dapet pujian receh! 🦅";
 }
 else if (_pct <= 80) {
 _lvl = "JAGOAN NEO"; 
 _emj = "⚡"; 
 _msg = "Wow, kehebatan lo di atas rata-rata @tag! Orang-orang pada segan sama kemampuan lo. Lo bisa nyelesain masalah yang bikin orang lain nyerah. Jangan lupa sedekah ilmu, jangan pelit-pelit jadi orang! 💡";
 }
 else if (_pct <= 95) {
 _lvl = "MAIN CHARACTER (MC)"; 
 _emj = "🛐"; 
 _msg = "AMPUUN SUHU @tag! Kehebatan lo udah kayak Main Character anime! Apapun yang lo lakuin selalu *plot armor*-nya tebel. Tapi awas, orang sehebat lo biasanya dikhianatin temen sendiri di season 2. Hati-hati bos! 👑";
 }
 else {
 _lvl = "CHEAT HIDUP / DEWA"; 
 _emj = "🌌"; 
 _msg = "100% DEWA @tag!!! Lo ini pasti pake *cheat engine* kan di dunia nyata?! Kehebatan lo udah gak bisa dilogika pake akal sehat. Apa aja yang lo sentuh jadi emas. Lo beneran mutlak penguasa realita! 🤯☄️";
 }
 }
 
 else if (command === 'cekskill') {
 _title = "SKILL";
 if (_pct <= 10) {
 _lvl = "SKILL ISSUE AKUT"; 
 _emj = "🤡"; 
 _msg = "SKILL ISSUE! @tag lo napas aja kayaknya manual apalagi disuruh mikir. Buka bungkus indomie aja lo pake gunting rumput. Lo itu definisi nyata dari 'makhluk gak berguna'. Parah abis! 🤦";
 }
 else if (_pct <= 20) {
 _lvl = "PENGANGGURAN ABADI"; 
 _emj = "🛌"; 
 _msg = "Skill lo cuma rebahan, scroll TikTok, tidur, bangun, berak, tidur lagi. Selain siklus itu, lo buta arah @tag. Gak ada keahlian khusus. Madesu banget idup lu, perusahaan juga jijik nerima CV lo! 💸";
 }
 else if (_pct <= 30) {
 _lvl = "AMATIRAN CUPU"; 
 _emj = "🐢"; 
 _msg = "Lo kalau disuruh nyelesein masalah bukannya kelar malah nambah masalah baru @tag. Tangan lo itu tangan penghancur. Gak punya skill, cuma modal modal bacot doang nyuruh-nyuruh orang lain. 🗑️";
 }
 else if (_pct <= 40) {
 _lvl = "BISA DIKIT DOANG"; 
 _emj = "🤏"; 
 _msg = "Skill lo cuma sebatas tutorial YouTube part 1 doang @tag. Pas error dikit langsung panik gak tau cara benerinnya. Pengetahuan lo cetek banget, awas gampang ditipu orang pinter! 📉";
 }
 else if (_pct <= 50) {
 _lvl = "PALUGADA NANGGUNG"; 
 _emj = "🛠️"; 
 _msg = "Lo bisa ngerjain banyak hal @tag, tapi sayang GAK ADA SATU PUN YANG JAGO. Semuanya setengah-setengah. Istilahnya 'Jack of all trades, master of none'. Lo gak bakal punya *value* mahal di pasar kerja! 🧩";
 }
 else if (_pct <= 60) {
 _lvl = "LUMAYAN PINTAR"; 
 _emj = "💡"; 
 _msg = "Skill lo udah lumayan kepake buat nyari duit @tag. Cuma lo malesnya itu yang bikin lo gak maju-maju. Kalau aja kemalasan lo bisa diubah jadi duit, lo pasti udah jadi triliuner sekarang! ⏳";
 }
 else if (_pct <= 70) {
 _lvl = "BERBAKAT"; 
 _emj = "🎯"; 
 _msg = "Bakat lo boleh juga @tag. Kalau ditekuni lu bisa jadi orang sukses yang dihargai mahal. Sayangnya lingkungan lo kurang ngedukung. Jangan gampang nyerah, buktikan kalau lo bisa ngelewatin batas! 📈";
 }
 else if (_pct <= 80) {
 _lvl = "EXPERT / SUHU"; 
 _emj = "🦅"; 
 _msg = "Suhu turun gunung nih @tag. Skill lo di bidang lo udah gak diraguin lagi. Orang banyak berguru sama lo. Tapi tetep *stay humble*, karena di luar sana banyak yang diem-diem lebih jago dan siap nikung lo! ⚔️";
 }
 else if (_pct <= 95) {
 _lvl = "MAESTRO / LEGENDA"; 
 _emj = "👑"; 
 _msg = "Skill tingkat Dewa @tag! Lo ngerjain sesuatu pake merem aja hasilnya lebih bagus daripada orang yang ngerjain seminggu gak tidur. Karya lo *masterpiece*. Tinggal nunggu lo kaya raya aja ini mah! 💰";
 }
 else {
 _lvl = "HACKER DUNIA NYATA"; 
 _emj = "💻"; 
 _msg = "100% ANOMALI @tag! Lo itu pinter kebangetan sampe orang mikir lo nge-cheat hidup. Tapi orang-orang super pinter kayak lo biasanya stress sendiri mikirin betapa bodohnya orang di sekitar lo. Semangat ya nahan sabar! 🧠⚡";
 }
 }
 
 else if (command === 'cekkekuattan') {
 _title = "KEKUATAN FISIK/MENTAL";
 if (_pct <= 10) {
 _lvl = "LEMAH SYAHWAT"; 
 _emj = "🥀"; 
 _msg = "Lemah banget lo @tag! Buka tutup botol air mineral aja mesti minta tolong pake handuk. Disenggol dikit jatuh koma, dikritik dikit nangis kejer. Fisik lemah, mental tempe. Jijik banget sumpah! 😭🍵";
 }
 else if (_pct <= 20) {
 _lvl = "KERUPUK MELEMPEM"; 
 _emj = "🍤"; 
 _msg = "Lo lebih rapuh dari biskuit roma yang dicelupin ke teh panas @tag! Disuruh lari 10 meter napas lo udah bunyi peluit kereta. Jangan sok-sokan ikut tawuran deh, kena angin aja lo udah geger otak! 🌬️";
 }
 else if (_pct <= 30) {
 _lvl = "TULANG LUNAK"; 
 _emj = "🧽"; 
 _msg = "Kekuatan lo setara sama anak TK @tag. Suruh angkat galon aja pinggang lo encok seminggu, harus dipijet pake minyak urut. Kalo ada copet mending lo kasih aja dompet lu daripada mati konyol! 🛌";
 }
 else if (_pct <= 40) {
 _lvl = "FISIK REMAJA JOMPO"; 
 _emj = "🦯"; 
 _msg = "Baru umur segini badan lo udah bunyi 'krek krek' tiap kali jongkok @tag. Fix lo ini remaja jompo. Kekuatan lo udah abis kesedot buat begadang main HP tiap malem. Tolong sadar diri lu tuh ringkih! 🤕";
 }
 else if (_pct <= 50) {
 _lvl = "KULI LIGHT EDITION"; 
 _emj = "🧱"; 
 _msg = "Lumayan kuat @tag. Kalo diajak gotong royong mindahin lemari kelas masih kuat lah. Tapi awas jangan keseringan, tulang lo ntar geser. Kuat aslinya, tapi malesnya itu lho yang nutupin potensi lu. 😪";
 }
 else if (_pct <= 60) {
 _lvl = "KULI STANDAR"; 
 _emj = "👷‍♂️"; 
 _msg = "Kekuatan lo normal standar buruh pabrik @tag. Bisa nahan capek walau sambil ngomel-ngomel dalam hati. Punya mental baja buat nahan omelan bos. Salut sih, semangat terus pejuang rupiah! ☕";
 }
 else if (_pct <= 70) {
 _lvl = "PREMAN PASAR"; 
 _emj = "🦍"; 
 _msg = "Badan sama mental lo kuat banget @tag! Kalo ada yang macem-macem langsung lo sikat habis. Cuma ya gitu, lo kadang over-power nyari masalah yang gak penting. Otot kawat tapi otak kosong! 👊";
 }
 else if (_pct <= 80) {
 _lvl = "ATLET / MONSTER GYM"; 
 _emj = "🏋️‍♂️"; 
 _msg = "Gila @tag, fisik lo prima banget! Pukulan lo udah bisa bikin orang geger otak ringan. Lo pasti rajin *workout* kan? Awas jangan asal mukul orang sembarangan, tangan lu itu senjata tajam bos! 🔥";
 }
 else if (_pct <= 95) {
 _lvl = "HERCULES / TITAN"; 
 _emj = "🌋"; 
 _msg = "AMPUUN BANG @tag! Lu mukul tembok, temboknya yang nangis minta maaf. Kekuatan fisik dan mental lo udah gak bisa dipatahkan sama masalah hidup. Lo *unstoppable force* yang siap nabrak apapun! 🚜";
 }
 else {
 _lvl = "SAITAMA / KULI JAWA VIP"; 
 _emj = "☄️"; 
 _msg = "100% KEKUATAN MONSTER @tag! Lu angkat bumi pake satu jari kelingking juga sanggup kayaknya. Kalo lu nabok orang, orang itu beda dimensi langsung pindah alam. Tolong tahan kekuatan lu demi kedamaian semesta! 💥💀";
 }
 }
 
 
 var _barLength = 10;
 var _fillCount = Math.max(0, Math.min(10, Math.round(_pct / 10)));
 if (_fillCount === 0 && _pct > 0) _fillCount = 1; 
 var _barUI = '█'.repeat(_fillCount) + '▒'.repeat(_barLength - _fillCount);
 
 var _finalMsg = _msg.replace(/@tag/g, '@' + _numUser);
 
 var _finalText = `📊 *CEK ${_title}* 🔞\n\n`;
 _finalText += `╭─❏「 🔍 *SCAN PROFIL* 」\n`;
 _finalText += `│◆ 👤 *Target* : @${_numUser}\n`;
 _finalText += `│◆ 📊 *Level* : ${_barUI} ${_pct}%\n`;
 _finalText += `│◆ 📈 *Skor* : ${_val}${_suffix}\n`;
 _finalText += `│◆ 🏷️ *Status* : ${_lvl} ${_emj}\n`;
 _finalText += `╰──────────❏\n\n`;
 _finalText += `💀 *HASIL ANALISIS:* 💀\n`;
 _finalText += `${_finalMsg}\n\n`;
 _finalText += `╭─❏ ⚠️ *DISCLAIMER*\n`;
 _finalText += `│▣ Hasil ini di-generate secara acak oleh AI\n`;
 _finalText += `│▣ Kalau lo kena mental, segera periksa ke psikolog 🏥\n`;
 _finalText += `│▣ Jangan baper woy, lo semua cuma NPC di bumi!\n`;
 _finalText += `╰──────────❏\n\n`;
 _finalText += `_🔥 Powered by ${global.botname || '𝑹𝒂𝒊𝒅𝒆𝒏 𝑴𝑫'} 🔥_`;
 
 await raiden.sendMessage(m.chat, { 
 text: _finalText, 
 mentions: [_target] 
 }, { quoted: troli });
 
 await m.react('😹');
};

export default handler;
