import __moment_timezone from 'moment-timezone';

const pluginConfig = {
  name: 'calendar',
  category: 'fun',
  command: ['calendar', 'cekkalender'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPrem, isVip, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, isPrem(m.sender), isVip)) return Reply(global.mess.limit);

    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        const moment = __moment_timezone;
        const tgl = moment.tz('Asia/Jakarta').format('DD');
        const bln = moment.tz('Asia/Jakarta').format('MM');
        const thn = moment.tz('Asia/Jakarta').format('YYYY');

        const api_url = `${global.fgsi}/api/maker/calendar?apikey=${global.fgsiApikey}&date=${tgl}&month=${bln}&year=${thn}`;

        await raiden.sendMessage(m.chat, { 
            image: { url: api_url }, 
            caption: mess.done
        }, { quoted: m });

        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error(e);
        Reply("❌ Terjadi kesalahan pada server API Kalender.");
    }
};

export default handler;
