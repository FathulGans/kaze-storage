const pluginConfig = {
  name: 'prem',
  category: 'fun',
  command: ['prem', 'premium'],
};

const handler = async (m, ctx) => {
    let { daftar, generateWAMessageFromContent, isVip, prepareWAMessageMedia, proto, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);

    const time = new Date().toLocaleTimeString('id-ID', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    });

    const date = new Date().toLocaleDateString('id-ID', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });

    const msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessageV2Extension: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `╭─❏ *Premium Member*
│✧ ${date}
│✧ Price : ${global.harga.prem}
│✧ Duration : 30 Days
│✧ No Limit
│✧ Priority
│✧ All Features
│✧ All Games
│✧ Download Hq
│✧ Ai Tools
│✧ Vip Badge
│✧ Vip Support
╰──────────❏`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({
                        text: ``
                    }),
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia(
                            { image: { url: global.image.menu } },
                            { upload: raiden.waUploadToServer }
                        ))
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: `{\"display_text\":\"Beli Sekarang\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"${global.linkOwner}\"}`
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: `{\"display_text\":\"Menu\",\"id\":\".menu\"}`
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: `{\"display_text\":\"Coba Trial\",\"id\":\".trialprem\"}`
                            }
                        ]
                    })
                })
            }
        }
    }, { userJid: m.sender, quoted: m });

    await raiden.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

export default handler;
