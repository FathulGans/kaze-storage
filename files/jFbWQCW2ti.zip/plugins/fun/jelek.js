const pluginConfig = {
  name: 'jelek',
  category: 'fun',
  command: ['jelek'],
};

const handler = async (m, ctx) => {
    let { Reply, botNumber, daftar, isPremium, isVip, raiden, troli } = ctx;
 if (!m.isGroup) return Reply('❌ Fitur ini cuma bisa di grup!');
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 const participants = m.metadata?.participants || [];
 const eligible = participants.filter(p => {
 const jid = p.id || p.jid;
 return jid && jid !== botNumber && jid !== m.sender;
 });

 if (eligible.length === 0) return Reply('Gak ada orang di sini buat dihina.');

 const randomTarget = eligible[Math.floor(Math.random() * eligible.length)];
 let targetJid = randomTarget.id || randomTarget.jid;
 
 if (targetJid.endsWith('@lid')) {
 let real = participants.find(p => p.id === targetJid);
 if (real && real.jid) targetJid = real.jid;
 else targetJid = globalThis.lidKeNomor(targetJid);
 }

 const jelekRoast = [
 "Muka lo itu kayak resolusi video 144p pas sinyal lemot: buram, acak-acakan, dan bikin sakit mata.",
 "Fix, lu adalah alasan kenapa pabrik skincare gak pernah bangkrut. Kasus visual lu berat bener.",
 "Tuhan emang adil, ngasih lu idup tapi lupa ngasih lu tekstur muka yang layak dipandang manusia normal.",
 "Muka lo itu kayak error 404 Not Found. Berantakan, gak jelas, dan bikin orang pengen nge-refresh tapi tetep zonk.",
 "Lu itu kayak sampah organik. Kalo didiemin lama-lama busuk, dipandang bikin mata perih.",
 "Gak usah sok cakep. Lu kalo ngaca, bayangan lu aja males muncul karena capek nahan beban visual lu.",
 "Muka lu itu kayak sinyal 2G di basement. Udah lambat, susah dapet, sekalinya dapet malah bikin emosi.",
 "Evolusi manusia kayaknya berhenti pas nyampe di lu deh. Visual lu kayak versi beta yang penuh bug.",
 "Kalo ada kontes kemiripan sama aspal baru disiram air, lu pasti juara satu tanpa perlu dandan.",
 "Coba deh lu kalo keluar rumah pake kantong kresek. Bukan apa-apa, kasihan pejalan kaki lain trauma liat penampakan lu."
 ];

 const roast = jelekRoast[Math.floor(Math.random() * jelekRoast.length)];
 const finalMsg = `𝗢𝗿𝗮𝗻𝗴 𝗷𝗲𝗹𝗲𝗸 𝗱𝗶𝘀𝗶𝗻𝗶 𝗮𝗱𝗮𝗹𝗮𝗵😹\n\n@${targetJid.split('@')[0]} ${roast}`;

 await raiden.sendMessage(m.chat, {
 text: finalMsg,
 mentions: [targetJid]
 }, { quoted: troli });
 
 await m.react('🤣');
};

export default handler;
