const pluginConfig = {
  name: 'cekgoblok',
  category: 'fun',
  command: ['cekgoblok'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden, troli } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
 var _tGb = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : m.sender);
 if (_tGb.endsWith('@lid') && m.metadata?.participants) {
 var _pGb = m.metadata.participants.find(x => x.lid === _tGb || x.id === _tGb);
 if (_pGb) _tGb = _pGb.jid;
 }
 var _psnGb = Math.floor(Math.random() * 100) + 1;
 var _kmGb = "";
 if (_psnGb <= 25) {
 _kmGb = [
 "Lo pinter banget, otaknya encer. Jarang-jarang ada orang pinter nyasar di grup dongo ini.",
 "IQ lo pasti tinggi, logika lo tajam banget. Salut gue sama cara berpikir lo.",
 "Ternyata lo bukan bagian dari kawanan dongo grup ini. Otak lo masih berfungsi normal."
 ][Math.floor(Math.random() * 3)];
 } else if (_psnGb <= 75) {
 _kmGb = [
 "Otak lo sering delay ya? Kadang nyambung tapi seringan 'hah hoh' doang. Banyakin makan ikan.",
 "Goblok standar lah, gak parah-parah amat cuma ya emang agak lemot kalo disuruh mikir.",
 "Pola pikir lo tuh kayak loading bar stuck di 99%. Sedikit lagi dongo, sabar ya."
 ][Math.floor(Math.random() * 3)];
 } else {
 _kmGb = [
 "Gobloknya udah permanen dan mendarah daging. Otak lo cuma pajangan doang biar kepala gak kosong.",
 "Definisi tolol sejati. Kalo ketololan itu bisa dijual, lo udah jadi orang terkaya di dunia.",
 "Kasian ya orang tua lo, besarin anak berharap jadi kebanggaan, eh taunya malah jadi beban oksigen doang."
 ][Math.floor(Math.random() * 3)];
 }
 await raiden.sendMessage(m.chat, { text: `📊 *CEK STATUS GOBLOK*\n\nTarget: @${_tGb.split('@')[0]}\nHasil: *${_psnGb}%*\n\n📝 *Analisis:* ${_kmGb}`, mentions: [_tGb] }, { quoted: troli });
 await m.react('🤡');
};

export default handler;
