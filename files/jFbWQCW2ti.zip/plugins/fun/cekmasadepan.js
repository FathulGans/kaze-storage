import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'cekmasadepan',
  category: 'fun',
  command: ['cekmasadepan'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden, text } = ctx;
  if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);

  if (!text) return Reply(example("nama"));

  let who = m.mentionedJid?.[0] ?? m.quoted?.sender ?? m.sender;
  let name = await raiden.getName(who);

  let reportList = [
    `
👤 Nama: ${name}
📅 Year 2026

📝 Lo makin glowing sih… tapi mentally? still struggling. People bilang lo 'strong', padahal tiap malem lo breakdown sambil scroll IG mantan. Career path lo? ngambang. Relationship? pending sejak 2022.

📎 Saran: find peace, bukan validasi. Stop acting okay if lo emang dying inside.`,

    `
👤 Nama: ${name}
📅 Year 2027

📝 Lo akhirnya jadi famous… tapi karena di-TikTokin pas jatoh dari motor waktu ngejar gebetan. Lo bukan trauma survivor, lo public cringe now. Tapi at least lo viral, right?

📎 Saran: next time jatoh, jangan lupa senyum biar jadi meme aesthetic.`,

    `
👤 Nama: ${name}
📅 Year 2028

📝 Lo makin dewasa. Tapi hidup lo makin chaos. Healing lo gagal, self-love lo cuman excuse buat belanja impulsif. Lo udah gak broken home, lo broken soul now.

📎 Saran: jangan cari cinta, cari akal sehat lo yang ilang dulu.`,

    `
👤 Nama: ${name}
📅 Year 2025

📝 Lo dapet pasangan, tapi dia kayak soft toxic. Manis di awal, mental abuse di akhir. Tapi lo stay, karena lo takut sepi. Classic. Ujung-ujungnya lo sayang yang gak sayang balik.

📎 Saran: block dia, block ego lo, terus block semua self-pity story.`,

    `
👤 Nama: ${name}
📅 Year 2030

📝 Surprisingly lo sukses. Lo glow-up secara karir, mental stable, relationship sehat. Tapi... lo jadi stranger buat diri lo sendiri. Kayak lo menang, tapi kosong.

📎 Saran: be proud, but jangan lost in achievement. Be human, not resume.`,

    `
👤 Nama: ${name}
📅 Year 2029

📝 Lo nemu someone yang klik. Dia ngerti lo, dia dengerin, dia gak maksa. Tapi lo? Masih sibuk overthinking dan sabotage semua. Karena lo takut disayang beneran.

📎 Saran: stop blaming love for the damage you do to yourself.`,

    `
👤 Nama: ${name}
📅 Year 2026

📝 Masa depan lo chill. Career steady, inner circle kecil tapi safe. Tapi lo tetep overthinking hal-hal random jam 2 pagi. Lo stabil, tapi restless. Lo tenang, tapi kosong.

📎 Saran: bukan waktunya cari pelarian. It's time to sit with yourself, finally.`,

    `
👤 Nama: ${name}
📅 Year 2027

📝 Lo hidup, tapi kayak NPC. Bangun kerja tidur, ngeluh di Twitter, repeat. Lo bukan stuck di life, lo stuck di pattern lo sendiri. Dan lo capek, tapi gak move.

📎 Saran: break the cycle, or lo bakal jadi urban legend manusia lelah.`
  ];

  let pick = reportList[Math.floor(Math.random() * reportList.length)];
  Reply(pick, [who]);
};

export default handler;
