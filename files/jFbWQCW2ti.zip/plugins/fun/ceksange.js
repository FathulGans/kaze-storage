const pluginConfig = {
  name: 'ceksange',
  category: 'fun',
  command: ['ceksange'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, text } = ctx;
  if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
    if (!text) return Reply(`Contoh: ${prefix + command} ${global.botname}`)
    const level = Math.floor(Math.random() * 101)
    let komentar = ""

    if (level <= 20) {
        komentar = "Alhamdulillah, hatinya masih suci bersih kyk bayi. 👼"
    } else if (level <= 40) {
        komentar = "Masih normal lah, dikit-dikit khilaf doang. 😶"
    } else if (level <= 60) {
        komentar = "Mulai meresahkan ya, kyknya kurang asupan air putih. 🥤"
    } else if (level <= 80) {
        komentar = "Bahaya! Otaknya isinya video biru semua kyknya. 💀"
    } else {
        komentar = "TOLONG! Ini mah udah stadium akhir, mending buru-buru nikah atau tobat! 🚩🚩"
    }

    let teks = `*── 「 CEK SANGE 」 ──*\n\n`
    teks += `*Nama:* ${text}\n`
    teks += `*Level Sange:* ${level}%\n`
    teks += `*Analisa:* ${komentar}\n\n`
    teks += `_Jangan serius, cuma buat seru-seruan di grup!_`
    await raiden.sendMessage(m.chat, { 
        text: teks 
    }, { 
        quoted: {
            key: { fromMe: false, participant: m.sender, remoteJid: m.chat },
            message: { extendedTextMessage: { text: `Bentar, lagi cek suhu otaknya si ${text}... 🌡️` } }
        }
    });
};

export default handler;
