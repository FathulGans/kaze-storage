import __baileys from '../../src/lib/baileys-compat.js';
import fs from 'fs';

const pluginConfig = {
  name: 'tqto',
  category: 'fun',
  command: ['tqto'],
};

const handler = async (m, ctx) => {
    let { isVip, makeQuotedContact, raiden } = ctx;
    if (!isVip) return m.reply(mess.vip);
    
    await raiden.sendMessage(m.chat, { react: { text: '🍀', key: m.key } });
    
    const tqtoPath = './library/database/tqto.json';
    if (!fs.existsSync(tqtoPath)) {
        fs.writeFileSync(tqtoPath, JSON.stringify([]));
    }
    let tqtoData = JSON.parse(fs.readFileSync(tqtoPath));
    
    const developerData = {
        name: "Archio official",
        role: "Owner Script",
        number: "62881022288695"
    };
    
    const allData = [developerData, ...tqtoData.filter(v => v.number !== "62881022288695")];
    
    const cards = [];
    for (const x of allData) {
        let profileUrl = global.image.menu;
        try {
            const pp = await raiden.profilePictureUrl(x.number + '@s.whatsapp.net', 'image').catch(() => null);
            if (pp) profileUrl = pp;
        } catch(e) {}
        
        let titleText = `╭╼─┈───┈──⏣╼╯
├ ◦  *Name:* ${x.name}
├ ◦  *Role:* ${x.role}
╰─╼𔕬─┈───┈───┈`;
        const { prepareWAMessageMedia } = __baileys;
        
        cards.push({
            header: await prepareWAMessageMedia({ image: { url: profileUrl } }, { upload: raiden.waUploadToServer }),
            title: titleText,
            number: x.number
        });
    }
   
    const { proto, generateWAMessageFromContent } = __baileys;
    
    const thanksToBody = cards.map(card => card.title).join('\n');
    const quotedContact = makeQuotedContact(m);
    
    const msgii = await generateWAMessageFromContent(m.chat, {
        viewOnceMessageV2Extension: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `🙏 *Thanks To*\n\nDaftar pihak yang berjasa dalam pengembangan ${global.botname || 'bot ini'}:\n\n${thanksToBody}`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({
                        text: `${global.botname || 'RaidenAI'} • Apresiasi & Kontributor`
                    }),
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                        hasMediaAttachment: true,
                        ...cards[0].header
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: cards.map(card => ({
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"💬 Sapa ${card.name || card.number}\",\"url\":\"https://wa.me/${card.number}\",\"merchant_url\":\"https://wa.me/${card.number}\"}`
                        }))
                    })
                })
            }
        }
    }, { userJid: m.sender, quoted: quotedContact });
    
    await raiden.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id });
    const MB = (await import('baileys-mbuilder')).default;
    await new MB.AIRich(raiden)
        .addTip(`Proyek ini tidak akan berjalan tanpa dukungan dari banyak pihak.`)
        .addTable([
            ["Nama", "Kontribusi"],
            ["Owner, partner & reseller", "Dukungan dan kerja sama"],
            ["Member RAIDEN AI", "Testing dan masukan"],
            ["Penyedia API", "Layanan dan integrasi"],
            ["Allah SWT", "Segala kemudahan dan rezeki"]
        ])
        .addTip("Terima kasih atas semua dukungan yang telah diberikan.")
        .send(m.chat, {
            forwarded: true
        });
    return m.reply(`✅ Daftar *Thanks To* berhasil dikirim.`);
};

export default handler;
