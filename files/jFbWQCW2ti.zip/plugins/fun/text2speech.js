import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'text2speech',
  category: 'fun',
  command: ['text2speech'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    if (!text) {
        return Reply(example("Hi kenalin ya, nama aku raiden ai"));
    }
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    try {
        const encodedText = encodeURIComponent(text);
        const apiUrl = `https://api.nexray.eu.cc/ai/dracin-tts?text=${encodedText}&speed=1.0&volume=0.3&music=true`;
        
        const response = await axios.get(apiUrl, { timeout: 30000 });
        
        if (!response.data.status || !response.data.result) {
            throw new Error('Gagal membuat audio');
        }
        
        const audioUrl = response.data.result;
        
        await raiden.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            ptt: false,
            caption: mess.done
        }, { quoted: m });
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[TTS ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;
