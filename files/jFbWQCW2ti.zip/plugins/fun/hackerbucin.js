const pluginConfig = {
  name: 'hackerbucin',
  category: 'fun',
  command: ['hackerbucin', 'hekerbucin', 'bucinhacker', 'bucinheker'],
};

const handler = async (m, ctx) => {
    let { daftar, isVip, raiden, troli } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    const quotes = [
        "Cintaku ke kamu itu kayak root access, punya kendali penuh atas hatiku.",
        "Hati aku nggak butuh firewall, soalnya aku udah nge-allow IP address kamu buat masuk kapan aja.",
        "Kamu itu kayak malware, sekali masuk ke pikiranku langsung susah buat di-cleanup.",
        "Aku nggak butuh password buat buka hati kamu, cukup pake brute force rindu yang nggak ada abisnya.",
        "Cinta kita itu kyk blockchain, nggak bisa diubah-ubah dan bakal kekal selamanya.",
        "Kalau aku jadi hacker, hal pertama yang aku deface adalah tampilan masa depanmu, biar isinya cuma ada fotoku.",
        "Jangan pernah logout dari hatiku, karena aku udah delete tombol sign-in buat orang lain.",
        "Kamu itu kyk SQL Injection, masuk lewat celah kecil tapi langsung menguasai seluruh database perasaanku.",
        "Rinduku ke kamu itu kyk DDoS attack, datang bertubi-tubi sampe logikaku down.",
        "Aku rela jadi VPN buat kamu, biar aku bisa jagain kamu dari bahaya dunia luar.",
        "Hubungan kita kyk HTTPS, aman, terenkripsi, dan nggak ada orang ketiga yang bisa sniffing.",
        "Cintaku padamu itu kyk open source, bebas kamu kembangin sesuka hati tanpa perlu lisensi.",
        "Kamu itu bug terindah yang pernah aku temuin, nggak mau aku fix karena aku suka efeknya.",
        "Tiap liat senyum kamu, hatiku langsung kena 'Critical Error' karena terlalu kencang berdetak.",
        "Aku nggak butuh backdoor buat masuk ke hidupmu, aku pengen masuk lewat pintu depan sebagai admin hatimu.",
        "Data perasaanku ke kamu udah aku backup di cloud surga, biar nggak ilang kalau dunia ini crash.",
        "Mencintaimu itu kyk coding Python, simpel tapi hasilnya luar biasa powerful.",
        "Kamu itu kyk kernel di OS-ku, tanpa kamu hidupku nggak bakal bisa running.",
        "Kalau rindu ini adalah script, kyknya bakal infinite loop karena nggak pernah nemu titik henti.",
        "Hati aku udah ter-encrypt pake kunci SHA-256, dan cuma kamu satu-satunya private key yang bisa buka.",
        "Jangan coba-coba scan hatiku pake Nmap, isinya cuma ada satu port terbuka: Port Cinta buat kamu.",
        "Kamu itu kyk 0day exploit, bikin aku nggak berdaya dalam sekejap.",
        "Cinta aku ke kamu itu 'Uncaught Exception', nggak terduga tapi bikin sistem hidupku berubah total.",
        "Aku mau kita kyk git commit, setiap perubahan dalam hidupku selalu ada kamu di dalamnya.",
        "Status cintaku ke kamu itu 200 OK, nggak ada error, nggak ada bad request, pokoknya lancar jaya."
    ];
    const hasil = quotes[Math.floor(Math.random() * quotes.length)];
    raiden.sendMessage(m.chat, {
        text: `*── 「 HACKER BUCIN 」 ──*\n\n"${hasil}"\n\n_~ ${global.botname} DarkNet_`
    }, { quoted: troli });
};

export default handler;
