const pluginConfig = {
  name: 'galau',
  category: 'fun',
  command: ['galau', 'quotesgalau', 'katakata'],
};

const handler = async (m, ctx) => {
    let { daftar, isVip, raiden } = ctx;
if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
    const quotes = [
        "Sakit itu bukan pas putus, tapi pas tau dia udah bahagia sama orang lain sedangkan kita masih stuck di tempat.",
        "Aku bukan berhenti mencintaimu, aku cuma berhenti menunjukkannya karena kamu nggak pernah menghargainya.",
        "Kadang kita harus melepaskan seseorang, bukan karena berhenti sayang, tapi karena sadar kalau kita bukan alasannya bahagia.",
        "Sehebat apapun aku bertahan, kalau kamu cuma niat singgah ya bakal tetap pergi juga.",
        "Hujan itu jatuh, tapi tetap kembali ke langit. Tapi kenapa rindu ini jatuh dan nggak pernah sampai ke kamu?",
        "Ternyata benar, yang paling menyakitkan adalah dicintai oleh seseorang yang belum selesai dengan masa lalunya.",
        "Aku pernah jadi alasanmu tersenyum, sebelum akhirnya aku jadi alasanmu untuk pergi.",
        "Menunggu itu membosankan, tapi kehilanganmu jauh lebih menyakitkan.",
        "Kita itu seperti dua garis yang sempat bersimpangan, namun akhirnya menjauh selamanya.",
        "Ada rindu yang nggak pernah tersampaikan, dan ada doa yang diam-diam selalu menyebut namamu.",
        "Lucu ya, dulu kita sedekat nadi, sekarang sejauh matahari.",
        "Lelahnya pura-pura bahagia itu jauh lebih berat daripada mengakui kalau hati ini hancur.",
        "Aku cuma butuh waktu untuk sembuh, bukan butuh orang baru untuk melupakanmu.",
        "Kamu adalah luka paling indah yang pernah aku perjuangkan.",
        "Jangan datang lagi kalau cuma mau ngetes aku udah move on atau belum. Capek tau!",
        "Ternyata, nggak semua yang diperjuangkan bakal berakhir dengan kepemilikan.",
        "Hati ini bukan halte yang bisa kamu singgahi pas lagi butuh, terus kamu tinggal pas lagi bosan.",
        "Terima kasih sudah pernah singgah, meski akhirnya kamu cuma ninggalin luka yang susah sembuh.",
        "Mencintai orang yang nggak bisa dimiliki itu kyk meluk duri, makin erat dipeluk makin sakit.",
        "Satu-satunya hal yang paling aku benci adalah kenyataan bahwa aku masih peduli sama kamu.",
        "Kita hanya dua orang yang saling mengenal, lalu saling melupakan karena ego masing-masing.",
        "Masa lalu itu kyk kaca yang pecah, jangan dipaksain buat disatuin lagi kalau nggak mau tanganmu makin berdarah.",
        "Rindu ini kyk ombak, datangnya tiba-tiba dan bikin sesak napas.",
        "Kamu tau yang lebih sakit dari ditinggal? Yaitu dianggap nggak ada padahal masih ada di sampingmu.",
        "Aku titipkan bahagiamu pada dia, karena kelihatannya bahagiaku sudah tidak lagi kamu butuhkan.",
        "Cinta itu butuh waktu, tapi melupakanmu butuh selamanya.",
        "Terjebak di antara ingin bertahan tapi sakit, atau ingin pergi tapi masih sayang.",
        "Kenangan itu indah, tapi menyakitkan saat kita sadar kalau itu nggak akan terulang lagi.",
        "Pernah sedekat doa, sebelum akhirnya sejauh asing.",
        "Aku hanya ingin kamu tau, aku tetap di sini, meski kamu sudah lari sejauh mungkin."
    ];
    const hasilQuote = quotes[Math.floor(Math.random() * quotes.length)];

    let teks = `*── 「 QUOTES GALAU 」 ──*\n\n`
    teks += `"${hasilQuote}"\n\n`
    teks += `~ _${global.botname}_`

    await raiden.sendMessage(m.chat, { 
        text: teks 
    }, { 
        quoted: {
            key: { fromMe: false, participant: m.sender, remoteJid: m.chat },
            message: { extendedTextMessage: { text: "Menyeka air mata... 💧" } }
        }
    });
};

export default handler;
