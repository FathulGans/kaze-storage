import __fs from 'fs';

const pluginConfig = {
  name: 'jumlahuser',
  category: 'fun',
  command: ['jumlahuser', 'totaluser'],
};

const handler = async (m, ctx) => {
    let { Reply } = ctx;
  const fs = __fs;
  const path = './library/database/user.json';

  if (!fs.existsSync(path)) fs.writeFileSync(path, '[]');

  let users = [];
  try {
    users = JSON.parse(fs.readFileSync(path));
    if (!Array.isArray(users)) users = [];
  } catch (e) {
    users = [];
  }

  const total = users.length;
  const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

  const teks = `📊 *TOTAL PENGGUNA TERDAFTAR*

👥 *Total:* ${total} user
🕒 *Waktu:* ${waktu}`;

  Reply(teks);
};

export default handler;
