const pluginConfig = {
  name: 'pintar',
  category: 'fun',
  command: ['pintar'],
};

const handler = async (m, ctx) => {
    let { Reply, botNumber, daftar, isPremium, isVip, raiden, troli } = ctx;
 if (!m.isGroup) return Reply('❌ Fitur ini khusus di dalam grup!');
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 if (!global.pintarCooldown) global.pintarCooldown = {};
 const now = Date.now();
 const cd = isPremium ? 30000 : 180000; 
 if (!isVip && global.pintarCooldown[m.sender] && (now - global.pintarCooldown[m.sender] < cd)) {
 const sisa = Math.ceil((cd - (now - global.pintarCooldown[m.sender])) / 1000);
 return Reply(`Waduh, otak lo lagi panas nyari orang pinter. Tunggu ${sisa} detik lagi.`);
 }
 global.pintarCooldown[m.sender] = now;

 const participants = m.metadata?.participants || [];
 const eligible = participants.filter(p => {
 const jid = p.id || p.jid;
 return jid && jid !== botNumber && jid !== m.sender;
 });

 if (eligible.length === 0) return Reply('Gak ada orang di sini yang kelihatan pinter.');

 const picked = eligible[Math.floor(Math.random() * eligible.length)];
 let targetJid = picked.id || picked.jid;
 
 if (targetJid.endsWith('@lid')) {
 let real = participants.find(p => p.id === targetJid);
 if (real && real.jid) targetJid = real.jid;
 else targetJid = globalThis.lidKeNomor(targetJid);
 }

 const savagePintar = [
 "IQ lo pasti di atas rata-rata manusia normal, cara lo mikir tuh futuristik banget. Gila, pinter banget!",
 "Lo tuh tipe orang yang kalau diajak debat, lawan langsung kena mental duluan gara-gara argumen lo yang terlalu jenius.",
 "Otak lo kayak supercomputer, semua masalah beres dalam hitungan detik. Definisi pinter sesungguhnya.",
 "Sepertinya Google harus belajar banyak dari isi kepala lo. Pengetahuan lo luas banget kayak samudera.",
 "Gak heran lo jadi andalan, logika lo tuh tajam banget kayak silet. Salut buat kecerdasan lo!",
 "Pantesan aura lo beda, ternyata ada otak tingkat tinggi di balik muka kalem lo itu. Jenius murni.",
 "Lo tuh walking encyclopedia ya? Apa aja ditanya pasti tau jawabannya. Grup ini butuh orang kayak lo.",
 "Cara lo nyelesaiin masalah itu seni banget. Simple tapi cerdas, gak semua orang bisa kayak gitu.",
 "Otak lo tuh aset berharga grup ini. Jangan ampe ilang ya, pinter lo tuh langka banget soalnya.",
 "Setiap kata yang keluar dari ketikan lo tuh berbobot semua, kelihatan kalau yang ngetik orang berpendidikan tinggi.",
 "Kalo kecerdasan itu investasi, lo pasti udah jadi orang terkaya di dunia. Otak lo mahal harganya!"
 ];

 const compliment = savagePintar[Math.floor(Math.random() * savagePintar.length)];
 
 const finalMsg = `𝗢𝗿𝗮𝗻𝗴 𝗽𝗶𝗻𝘁𝗮𝗿 𝗱𝗶𝘀𝗶𝗻𝗶 𝗮𝗱𝗮𝗹𝗮𝗵🧠\n\n@${targetJid.split('@')[0]} ${compliment}`;

 await raiden.sendMessage(m.chat, {
 text: finalMsg,
 mentions: [targetJid]
 }, { quoted: troli });
 
 await m.react('🧠');
};

export default handler;
