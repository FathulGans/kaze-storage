import __path from 'path';

const pluginConfig = {
  name: 'suratsakit',
  category: 'fun',
  command: ['suratsakit', 'suratizin', 'sakit', 'skd', 'dokter'],
};

const handler = async (m, konteksInti) => {
    let { Reply, daftar, isPremium, isVip, prefix, raiden, safeErr, text } = konteksInti;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, isPremium, isVip))
 return Reply(global.mess.limit);
 
 if (!text) {
 return Reply(
 `*Surat Keterangan Sakit*
 Parameter wajib diisi!

*Format* : ${prefix}suratsakit nama|umur|pekerjaan|alamat|penyakit|hari
*Contoh* : ${prefix}suratsakit dinz|19|Mahasiswa|Jl. Melati No 12|Demam berdarah|3

*Keterangan:*
• nama : Nama pasien
• umur : Usia pasien
• pekerjaan : Pekerjaan pasien (opsional)
• alamat : Alamat pasien
• penyakit : Jenis penyakit
• hari : Jumlah hari istirahat (1-7)
`
 )
 }
 
 addLimit(m.sender, isPremium, isVip);
 await raiden.sendMessage(m.chat, { react: { text: "🩺", key: m.key } });
 
 try {
 const parts = text.split('|');
 if (parts.length < 5) {
 return Reply('❌ Format salah! Gunakan: nama|umur|pekerjaan|alamat|penyakit|hari');
 }
 
 let [nama, umur, pekerjaan, alamat, penyakit, hari] = parts;
 nama = nama.trim();
 umur = umur.trim();
 pekerjaan = pekerjaan.trim() || '-';
 alamat = alamat.trim();
 penyakit = penyakit.trim();
 let jumlahHari = parseInt(hari);
 if (isNaN(jumlahHari) || jumlahHari < 1) jumlahHari = 3;
 if (jumlahHari > 14) jumlahHari = 14;
 
 const today = new Date();
 const startDate = today.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
 const endDate = new Date(today);
 endDate.setDate(today.getDate() + jumlahHari - 1);
 const endDateStr = endDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
 
 const { createCanvas, registerFont } = (await import('canvas')).default;
 const path = __path;
 
 try {
 registerFont('./src/font/times.ttf', { family: 'Times New Roman' });
 registerFont('./src/font/arial.ttf', { family: 'Arial' });
 } catch (e) { console.error(e); }
 
 const width = 800;
 const height = 1100;
 const canvas = createCanvas(width, height);
 const ctx = canvas.getContext('2d');
 
 ctx.fillStyle = '#ffffff';
 ctx.fillRect(0, 0, width, height);
 
 ctx.strokeStyle = '#333333';
 ctx.lineWidth = 2;
 ctx.strokeRect(10, 10, width - 20, height - 20);
 
 ctx.strokeStyle = '#666666';
 ctx.lineWidth = 1;
 ctx.strokeRect(15, 15, width - 30, height - 30);
 
 ctx.font = 'bold 24px "Times New Roman", Times, serif';
 ctx.fillStyle = '#1a1a1a';
 ctx.textAlign = 'center';
 ctx.fillText('SURAT KETERANGAN SAKIT', width / 2, 70);
 
 ctx.font = 'italic 16px "Times New Roman", Times, serif';
 ctx.fillStyle = '#444444';
 ctx.fillText('CERTIFICATE OF SICKNESS', width / 2, 100);
 
 ctx.beginPath();
 ctx.moveTo(50, 120);
 ctx.lineTo(width - 50, 120);
 ctx.strokeStyle = '#999999';
 ctx.lineWidth = 1;
 ctx.stroke();
 
 const nomorSurat = `003/SKS/${Math.floor(Math.random() * 999) + 1}/PKD/${new Date().getFullYear()}`;
 ctx.font = '12px "Times New Roman", Times, serif';
 ctx.fillStyle = '#666666';
 ctx.textAlign = 'right';
 ctx.fillText(`No. ${nomorSurat}`, width - 50, 145);
 
 ctx.font = '14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#000000';
 ctx.textAlign = 'left';
 ctx.fillText('Yang bertanda tangan dibawah ini :', 50, 185);
 
 ctx.font = 'bold 14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#000000';
 ctx.fillText('dr. Wahyu Setiawan', 50, 215);
 
 ctx.font = '14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#000000';
 ctx.fillText('Menerangkan bahwa :', 50, 250);
 
 let yPos = 290;
 const lineHeight = 28;
 
 ctx.font = '14px "Times New Roman", Times, serif';
 
 ctx.fillStyle = '#000000';
 ctx.fillText('Nama', 50, yPos);
 ctx.fillText(':', 180, yPos);
 ctx.font = 'bold 14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#1a1a1a';
 ctx.fillText(nama, 210, yPos);
 
 yPos += lineHeight;
 ctx.font = '14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#000000';
 ctx.fillText('Umur', 50, yPos);
 ctx.fillText(':', 180, yPos);
 ctx.font = 'bold 14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#1a1a1a';
 ctx.fillText(`${umur} Tahun`, 210, yPos);
 
 yPos += lineHeight;
 ctx.font = '14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#000000';
 ctx.fillText('Pekerjaan', 50, yPos);
 ctx.fillText(':', 180, yPos);
 ctx.font = 'bold 14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#1a1a1a';
 ctx.fillText(pekerjaan, 210, yPos);
 
 yPos += lineHeight;
 ctx.font = '14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#000000';
 ctx.fillText('Alamat', 50, yPos);
 ctx.fillText(':', 180, yPos);
 ctx.font = 'bold 14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#1a1a1a';
 ctx.fillText(alamat, 210, yPos);
 
 yPos += lineHeight + 15;
 
 ctx.font = '14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#000000';
 ctx.fillText(`Perlu beristirahat selama ${jumlahHari} hari`, 50, yPos);
 
 yPos += lineHeight;
 ctx.fillText(`Dari tanggal ${startDate} s/d ${endDateStr}`, 50, yPos);
 
 yPos += lineHeight;
 ctx.fillText(`Karena ${penyakit}`, 50, yPos);
 
 yPos += lineHeight + 10;
 ctx.fillText('Demikian Surat Keterangan ini dibuat untuk diketahui dan', 50, yPos);
 yPos += lineHeight;
 ctx.fillText('dipergunakan sebagaimana mestinya.', 50, yPos);
 
 yPos += lineHeight + 15;
 const formattedDate = today.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
 ctx.fillText(`${formattedDate}`, width - 200, yPos);
 
 yPos += 60;
 ctx.font = '14px "Times New Roman", Times, serif';
 ctx.textAlign = 'center';
 ctx.fillText('(dr. Wahyu Setiawan)', width / 2, yPos);
 
 yPos += 25;
 ctx.font = 'bold 12px "Times New Roman", Times, serif';
 ctx.fillStyle = '#444444';
 ctx.fillText('PRAKTEK DOKTER UMUM', width / 2, yPos);
 
 yPos += 20;
 ctx.font = 'bold 14px "Times New Roman", Times, serif';
 ctx.fillStyle = '#1a1a1a';
 ctx.fillText('DR. WAHYU SETIAWAN', width / 2, yPos);
 
 yPos += 25;
 ctx.font = '10px "Times New Roman", Times, serif';
 ctx.fillStyle = '#666666';
 ctx.fillText('SIP: 33/B.15A/31.75.07.1007.01.003.K.2/3/-1.779.3/e/2022', width / 2, yPos);
 
 yPos = height - 50;
 ctx.font = '10px "Times New Roman", Times, serif';
 ctx.fillStyle = '#888888';
 ctx.textAlign = 'center';
 ctx.fillText('Jl. Rama Ratu Jaya No. 279, Cakung, Jakarta Timur, DKI Jakarta', width / 2, yPos);
 
 ctx.save();
 ctx.translate(width - 120, height - 180);
 ctx.rotate(-0.15);
 ctx.font = 'bold 20px "Times New Roman", Times, serif';
 ctx.fillStyle = 'rgba(100, 100, 100, 0.25)';
 ctx.textAlign = 'center';
 ctx.fillText('RUMAH SAKIT', 0, 0);
 ctx.font = 'bold 14px "Times New Roman", Times, serif';
 ctx.fillText('UMUM', 0, 25);
 ctx.beginPath();
 ctx.arc(0, -10, 45, 0, Math.PI * 2);
 ctx.strokeStyle = 'rgba(100, 100, 100, 0.25)';
 ctx.lineWidth = 2;
 ctx.stroke();
 ctx.restore();
 
 const buffer = canvas.toBuffer('image/png');
 
 await raiden.sendMessage(m.chat, {
 image: buffer,
 caption: `🏥 *SURAT KETERANGAN SAKIT*\n\n👤 Pasien: ${nama}\n🩺 Diagnosis: ${penyakit}\n📅 Istirahat: ${jumlahHari} hari (${startDate} - ${endDateStr})\n\n_Surat ini telah ditandatangani secara digital oleh dr. Wahyu Setiawan_`
 }, { quoted: m });
 
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error('[SURATSAKIT ERROR]', error);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Gagal membuat surat: ${safeErr(error)}`);
 }
};

export default handler;
