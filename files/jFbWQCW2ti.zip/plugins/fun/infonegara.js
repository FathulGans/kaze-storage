import fetch from 'node-fetch';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'infonegara',
  category: 'fun',
  command: ['infonegara', 'country'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, prefix, q, raiden } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


    if (!q) return Reply("Masukkan nama negara! Contoh: .infonegara Vietnam");
    let url = `https://api.siputzx.my.id/api/tools/countryInfo?name=${encodeURIComponent(q)}`;
    try {
        let res = await fetch(url);
        let json = await res.json();
        if (!json.status) return Reply("Negara tidak ditemukan!");
        let data = json.data;
        let neighbors = data.neighbors.map(n => `- ${n.name} (${n.flag})`).join("\n");
        let replyText = `🌍 *Informasi Negara: ${data.name}*\n\n` +
            `🏛 *Ibukota:* ${data.capital}\n` +
            `📍 *Koordinat:* ${data.coordinates.latitude}, ${data.coordinates.longitude}\n` +
            `🏴 *Bendera:* ${data.flag}\n` +
            `📞 *Kode Telepon:* ${data.phoneCode}\n` +
            `🗺 *Peta:* ${data.googleMapsLink}\n` +
            `🌏 *Benua:* ${data.continent.name} ${data.continent.emoji}\n` +
            `🗣 *Bahasa:* ${data.languages.native.join(", ")}\n` +
            `💰 *Mata Uang:* ${data.currency}\n` +
            `🚗 *Lajur Kendaraan:* ${data.drivingSide}\n` +
            `🌟 *Terkenal Sebagai:* ${data.famousFor}\n` +
            `🏛 *Bentuk Pemerintahan:* ${data.constitutionalForm}\n` +
            `🌐 *Domain Internet:* ${data.internetTLD}\n` +
            `🌍 *Negara Tetangga:*\n${neighbors || "Tidak ada"}\n`;
        let buttons = [
            { buttonId: `${prefix}infonegara ${data.name}`, buttonText: { displayText: "🔄 Cek Lagi" }, type: 1 },
            { buttonId: `.menu`, buttonText: { displayText: "📜 Menu" }, type: 1 }
        ];
        let message = {
            text: replyText,
            footer: "Country Info Bot",
            buttons: buttons,
            headerType: 1,
            image: { url: data.flag }
        };
        raiden.sendMessage(m.chat, message, { quoted: m });
    } catch (err) {
        console.error(err);
        Reply("Terjadi kesalahan saat mengambil data.");
    }
};

export default handler;
