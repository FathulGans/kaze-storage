const pluginConfig = {
  name: 'cekdongo',
  category: 'fun',
  command: ['cekdongo', 'cektolol', 'cekkekontolan', 'cekmiskin'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, raiden, troli } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 var _target = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : m.sender);
 if (_target.endsWith('@lid') && m.metadata?.participants) {
 var _findTarget = m.metadata.participants.find(x => x.lid === _target || x.id === _target);
 if (_findTarget) _target = _findTarget.jid;
 }
 var _numUser = _target.split('@')[0];
 var _pct = Math.floor(Math.random() * 100) + 1;
 var _msg = "";
 var _lvl = "";
 var _emj = "";

 if (command === 'cekdongo') {
 if (_pct <= 10) { _lvl = "GENIUS"; _emj = "🧠"; _msg = "Otak @tag masih encer, jarang-jarang ada orang waras kayak lu di grup ini."; }
 else if (_pct <= 20) { _lvl = "NORMAL"; _emj = "✅"; _msg = "@tag masih bisa diajak ngomong nyambung, walaupun kadang rada lemot dikit."; }
 else if (_pct <= 30) { _lvl = "SLOW RESPON"; _emj = "⏳"; _msg = "Otak @tag kayak pake provider kuning di basement, sinyalnya suka ilang-ilangan."; }
 else if (_pct <= 40) { _lvl = "TELMI"; _emj = "🐌"; _msg = "@tag telat mikir. Orang udah bahas masa depan, lu baru sadar masa lalu."; }
 else if (_pct <= 50) { _lvl = "AGAK GESREK"; _emj = "🔧"; _msg = "Ada satu baut di kepala @tag yang lepas, coba cari dulu sebelum makin parah."; }
 else if (_pct <= 60) { _lvl = "DONGO RINGAN"; _emj = "🥴"; _msg = "Lu kalo dikasih tau 'A', jawabnya 'Z'. Bener-bener gak sinkron otak lu @tag."; }
 else if (_pct <= 70) { _lvl = "DONGO MENENGAH"; _emj = "🚧"; _msg = "Otak @tag cuma dipake buat napas doang ya? Gak ada fungsi logikanya sama sekali."; }
 else if (_pct <= 80) { _lvl = "DONGO KRONIS"; _emj = "🚑"; _msg = "IQ @tag setara suhu ruangan ber-AC, rendah dan bikin menggigil saking dongo-nya."; }
 else if (_pct <= 90) { _lvl = "STADIUM AKHIR"; _emj = "🏥"; _msg = "Gak ada harapan buat @tag. Sel-sel otak lu udah pada resign karena gak kuat nampung kedongoan lu."; }
 else { _lvl = "DONGO MUTLAK"; _emj = "🤡"; _msg = "Manusia paling dongo di galaksi. Kalo @tag mati, otaknya bisa dijual mahal karena kondisinya masih baru (gak pernah dipake)."; }
 }
 else if (command === 'cektolol') {
 if (_pct <= 10) { _lvl = "BIJAKSANA"; _emj = "🧘"; _msg = "@tag masih punya martabat. Ketololan lu masih di bawah batas wajar manusia."; }
 else if (_pct <= 20) { _lvl = "USAHA PINTER"; _emj = "🎓"; _msg = "@tag lagi pura-pura pinter ya? Lumayan lah, ketutup dikit ketololannya."; }
 else if (_pct <= 30) { _lvl = "TOLOL TIPIS"; _emj = "🤏"; _msg = "Ada bakat tolol di diri @tag, tapi masih bisa disembunyikan kalo lu diem aja."; }
 else if (_pct <= 40) { _lvl = "LUCU DOANG"; _emj = "🐣"; _msg = "Ketololan @tag masih di tahap menghibur, kayak badut ancol lagi atraksi."; }
 else if (_pct <= 50) { _lvl = "TOLOL STANDAR"; _emj = "😐"; _msg = "Lu adalah warga average yang tololnya pas-pasan. Gak lebih, gak kurang @tag."; }
 else if (_pct <= 60) { _lvl = "KELEWATAN"; _emj = "🚫"; _msg = "Sadar gak sih @tag? Kelakuan lu itu bikin orang pengen nabok pake kamus KBBI."; }
 else if (_pct <= 70) { _lvl = "TOLOL AKUT"; _emj = "💊"; _msg = "Mending @tag minum obat penurun ketololan deh, soalnya lu udah mulai bahaya buat lingkungan."; }
 else if (_pct <= 80) { _lvl = "DI LUAR NALAR"; _emj = "🛸"; _msg = "Ketololan @tag tembus ke dimensi lain. Alien aja minder liat tingkah laku lu."; }
 else if (_pct <= 90) { _lvl = "TOLOL MAKSIMAL"; _emj = "💣"; _msg = "@tag adalah bukti nyata kegagalan sistem pendidikan. Bener-bener tolol mendarah daging."; }
 else { _lvl = "RAJA TOLOL"; _emj = "👑"; _msg = "Sembah sujud buat @tag, sang penguasa ketololan. Kebodohan lu adalah sebuah mahakarya yang tragis."; }
 }
 else if (command === 'cekkontol') {
 if (_pct <= 10) { _lvl = "MALAIKAT"; _emj = "😇"; _msg = "@tag baik banget, suci tanpa noda. Gak ada sifat rese sama sekali di diri lu."; }
 else if (_pct <= 20) { _lvl = "HUMBLE"; _emj = "🤝"; _msg = "Sifat @tag masih sangat terjaga. Masih punya rasa kemanusiaan yang tinggi."; }
 else if (_pct <= 30) { _lvl = "BIASA AJA"; _emj = "😶"; _msg = "Gak jahat tapi gak baik juga. Standar manusia yang nyari aman doang @tag."; }
 else if (_pct <= 40) { _lvl = "MULAI RESE"; _emj = "😒"; _msg = "Vibes @tag mulai bikin gerah. Udah mulai berani nyari masalah kecil-kecilan."; }
 else if (_pct <= 50) { _lvl = "PENJILAT"; _emj = "👅"; _msg = "Setengah sifat @tag itu bermuka dua. Hati-hati kalo deket orang modelan begini."; }
 else if (_pct <= 60) { _lvl = "SOK KERAS"; _emj = "🥊"; _msg = "Kelakuan @tag udah kayak preman pasar, padahal mental lu lembek kayak tahu bulat."; }
 else if (_pct <= 70) { _lvl = "TOXIC"; _emj = "☢️"; _msg = "Sifat @tag bener-bener beracun. Setiap lu nongol, suasana grup langsung jadi suram."; }
 else if (_pct <= 80) { _lvl = "BRENGSEK"; _emj = "👺"; _msg = "Lu bener-bener gak punya perasaan @tag. Kebrengsekan lu udah diakui warga sekitar."; }
 else if (_pct <= 90) { _lvl = "PARAH BANGET"; _emj = "🔥"; _msg = "Hampir full sifat buruk. @tag kalo ngomong gak pernah difilter, hatinya busuk bener."; }
 else { _lvl = "FULL KONTOL"; _emj = "💩"; _msg = "Gak ada kata lain. @tag adalah personifikasi dari kata kontol. Idup cuma buat nyampah dan nyusahin orang."; }
 }
 else if (command === 'cekmiskin') {
 if (_pct <= 10) { _lvl = "OLD MONEY"; _emj = "🏯"; _msg = "Keluarga @tag udah kaya dari tujuh turunan. Duit lu gak bakal abis dipake mandi emas tiap hari."; }
 else if (_pct <= 20) { _lvl = "SULTAN ELITE"; _emj = "💎"; _msg = "Dompet @tag tebelnya ngalahin kamus bahasa Inggris. Lu bersin aja keluar recehan dollar."; }
 else if (_pct <= 30) { _lvl = "KAYA RAYA"; _emj = "🏎️"; _msg = "@tag bisa beli apapun tanpa liat harga. Hidup lu terlalu mewah buat kaum mendang-mending."; }
 else if (_pct <= 40) { _lvl = "KELAS ATAS"; _emj = "👔"; _msg = "Gaji @tag perbulan cukup buat beli motor cash tiap minggu. Hidup lu udah sangat stabil."; }
 else if (_pct <= 50) { _lvl = "MENENGAH"; _emj = "🏢"; _msg = "Bisa gaya dikit tapi tetep nunggu promo. @tag amanlah buat makan enak 3 kali sehari."; }
 else if (_pct <= 60) { _lvl = "PAS-PASAN"; _emj = "📉"; _msg = "Ekonomi @tag goyah kalo dapet undangan nikahan temen. Uang makan cuma cukup ampe tanggal 20."; }
 else if (_pct <= 70) { _lvl = "SOBAT MISQUEEN"; _emj = "💸"; _msg = "@tag hobi banget scroll keranjang Shopee tapi gak pernah di-checkout karena saldo nol."; }
 else if (_pct <= 80) { _lvl = "TOKEN HABIS"; _emj = "🔦"; _msg = "Kasian @tag, mandi pake air hujan karena pompa dimatiin PLN. Makan indomie dibagi dua buat lusa."; }
 else if (_pct <= 90) { _lvl = "GEMBEL TOTAL"; _emj = "🏚️"; _msg = "Dompet @tag cuma isi debu sama struk alfamart tahun lalu. Tidur pake kardus, mandi di sungai."; }
 else { _lvl = "MISKIN ABADI"; _emj = "🕳️"; _msg = "Bahkan gembel pun kasihan liat @tag. Lu gak miskin lagi, lu adalah personifikasi dari kemiskinan itu sendiri."; }
 }

 var _barLength = 10;
 var _fillCount = Math.round(_pct / 10);
 if (_fillCount === 0 && _pct > 0) _fillCount = 1;
 var _barUI = '█'.repeat(_fillCount) + '▒'.repeat(_barLength - _fillCount);
 
 var _finalMsg = _msg.replace(/@tag/g, '@' + _numUser);
 var _titleCaps = command.replace('cek', '').toUpperCase();

 var _finalText = `📊 *${_titleCaps} METER* 📊

╭─❏「 🔍 Scanning Profile 」
│◆ 👤 Target : @${_numUser}
│◆ 📊 Meter : ${_barUI}
│◆ 📈 Score : ${_pct}%
│◆ 🎖️ Status : ${_lvl} ${_emj}
╰──────────❏

📝 *Analisis AI:*
${_finalMsg}`;
 
 await raiden.sendMessage(m.chat, { text: _finalText, mentions: [_target] }, { quoted: troli });
 await m.react('🔥');
};

export default handler;
