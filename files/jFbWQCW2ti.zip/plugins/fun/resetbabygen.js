const pluginConfig = {
  name: 'resetbabygen',
  category: 'fun',
  command: ['resetbabygen', 'resetbaby', 'batalbabygen', 'batalbaby'],
};

const handler = async (m, ctx) => {
    let { Reply, prefix } = ctx;
    if (!global.babygenSessions) global.babygenSessions = {};
    const sessionKey = `${m.chat}:${m.sender}`;
    const session = global.babygenSessions[sessionKey];
    
    if (!session) {
        return Reply(`❌ *Tidak ada sesi baby generator aktif!*

Mulai sesi baru dengan:
${prefix}babygen`);
    }
    
    delete global.babygenSessions[sessionKey];
    
    let statusMsg = '';
    if (session.step === 'waiting_second') {
        statusMsg = 'Foto 1';
    } else if (session.step === 'waiting_gender') {
        statusMsg = 'Foto 1 & Foto 2';
    } else {
        statusMsg = 'Semua data';
    }
    
    return Reply(`✅ *Sesi baby generator direset!*

📸 *Data yang dihapus:* ${statusMsg}

Silakan mulai dari awal dengan:
${prefix}babygen`);
};

export default handler;
