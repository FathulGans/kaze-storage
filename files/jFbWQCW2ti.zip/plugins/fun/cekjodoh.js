import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'cekjodoh',
  category: 'fun',
  command: ['cekjodoh'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden, text } = ctx;
  if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);

  if (!text) return Reply(example("nama"));

  let who = m.mentionedJid?.[0] ?? m.quoted?.sender ?? m.sender;
  let name = await raiden.getName(who);

  let reportList = [
    `
👤 Nama: ${name}
📍 Status: Jodoh ga jadi lahir

📝 "Jodoh lo tuh sebenernya udah dikirim. Tapi pas denger lo ngorok sambil kentut jam 2 pagi, dia mutusin reinkarnasi jadi batu nisan. Visual lo kayak bekas hubungan toxic: gak enak diliat, penuh trauma."

📎 Saran: jangan cari jodoh, cari jawaban kenapa lo kayak gini.`,

    `
👤 Nama: ${name}
📍 Status: Kontol/memek lo ngalah

📝 "Alat vital lo udah lelah. Coli terus, overused, underloved. Cewek ilfeel, cowok mundur. Lo kayak walking cringe. Semua hormon cinta ogah kerja pas denger suara lo aja udah kayak efek PUBG kepleset."

📎 Saran: detox syahwat, cut sinetron dalam kepala lo, dan belajar diem.`,

    `
👤 Nama: ${name}
📍 Status: Rejected by both genders

📝 "Lo bukan gak laku. Lo ditolak dua kubu: cowok takut lo ngelunjak, cewek takut lo nempel. Muka lo vibes-nya kayak file ZIP: berat, ngebug, dan isinya cuma kenangan pahit."

📎 Saran: uninstall fantasi, install filter sosial, dan mandi sore.`,

    `
👤 Nama: ${name}
📍 Status: Bau luka lama

📝 "Lo bawa luka batin kayak tas jinjing, pamer ke semua orang tapi gak ada yang peduli. Jodoh lo udah niat... tapi kabur setelah baca caption lo: 'aku cuma pengen dimengerti'. Cringe level: 404."

📎 Saran: stop jadi korban pasif, hidup lo bukan sinetron SCTV.`,

    `
👤 Nama: ${name}
📍 Status: Aura mantan toxic

📝 "Semua orang yang deketin lo merasa kayak masuk flashback hubungan sebelumnya. Mulut lo lembut, tapi otak lo isinya micin dan emosi gak jelas. Lo bukan gak disayang, lo terlalu mirip trauma."

📎 Saran: stop ngaku 'trauma', padahal lo cuma nyebelin.`,

    `
👤 Nama: ${name}
📍 Status: Pacaran sama harapan sendiri

📝 "Lo udah sayang duluan, bayangin skenario duluan, tapi lupa nanya: 'emang dia mau juga?'. Lo bukan jomblo, lo main one-sided drama tiap hari. Cinta lo sepihak, alat kelamin lo sepihak, otak lo ngalor ngidul."

📎 Saran: belajar consent, bukan cuma ngarep.`,

    `
👤 Nama: ${name}
📍 Status: Terlalu sering sayang yang salah

📝 "Jodoh lo sebenernya udah muncul... tapi lo sibuk ngemis chat dari orang yang reply cuma 'hmm'. Lo bukan gak pantes disayang. Lo cuma goblok soal milih siapa yang harus lo kasih waktu."

📎 Saran: downgrade nafsu, upgrade harga diri.`,

    `
👤 Nama: ${name}
📍 Status: Jodoh tabrakan sama karma

📝 "Dulu lo sering PHP-in orang. Sekarang jodoh lo stuck di jalur karma. Bahkan malaikat ngetik: 'kita tunda dulu, dia belum nyesel cukup'. Dosa lo bikin sinyal cinta lo ke-blok."

📎 Saran: minta maaf ke semua yang pernah lo bikin nangis. Termasuk diri sendiri.`
  ];

  let pick = reportList[Math.floor(Math.random() * reportList.length)];
  Reply(pick, [who]);
};

export default handler;
