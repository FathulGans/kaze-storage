const pluginConfig = {
  name: 'readmore',
  category: 'fun',
  command: ['readmore', 'selengkapnya'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!text.includes('|')) return Reply(`Masukkan teks dengan format:\n${prefix + command} teks depan|teks belakang`);
    const more = String.fromCharCode(8203).repeat(4001);
    let [l, r] = text.split('|');
    l = l.trim();
    r = r.trim();
    Reply(l + '\n' + more + r);
};

export default handler;
