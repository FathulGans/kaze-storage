const pluginConfig = {
  name: 'bucin',
  category: 'fun',
  command: ['bucin', 'quotesbucin'],
};

const handler = async (m, ctx) => {
    let { daftar, isVip, raiden } = ctx;
if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
    const quotes = [
        "Mencintaimu itu kayak napas, kalo berhenti ya mati.",
        "Aku nggak butuh yang sempurna, aku cuma butuh orang yang nggak bakal nyerah sama keadaan kita.",
        "Kopi ini pahit, tapi kalau minumnya sambil lihat senyum kamu, manisnya jadi pas.",
        "Kalau aku jadi wakil rakyat, aku pasti gagal. Gimana mau mikirin rakyat, kalau di pikiranku cuma ada kamu?",
        "Cukup antartika aja yang jauh, antarkita jangan.",
        "Aku nggak pernah menyesal mengenalmu, yang aku sesali adalah kenapa nggak dari dulu aku sayang kamu.",
        "Mencintaimu itu indah, seperti pelangi setelah hujan, meski kadang hujannya adalah air mataku sendiri.",
        "Cinta itu bukan tentang seberapa lama kita kenal, tapi seberapa tulus kita bertahan.",
        "Aku tanpamu bagaikan butiran debu yang terbang nggak tentu arah.",
        "Kamu itu kayak wifi, kalau udah deket otomatis nyambung ke hati.",
        "Dulu cita-citaku jadi dokter, tapi sekarang berubah ingin jadi masa depanmu.",
        "Rindu itu berat, biar aku aja yang nanggung, kamu cukup jangan ilang-ilangan aja.",
        "Kalau kamu itu tugas sekolah, aku bakal ngerjain kamu setiap hari tanpa ngeluh.",
        "Obat pusing paling ampuh itu cuma satu: denger suara kamu.",
        "Tahu nggak kenapa aku suka matematika? Karena aku ingin menghitung hari-hari bahagia bersamamu.",
        "Jangan tanya kenapa aku sayang kamu, tanya aja kenapa kamu bisa seindah itu di mataku.",
        "Kamu itu oksigen ya? Soalnya kalau nggak ada kamu, aku sesak napas.",
        "Dunia ini luas, tapi kenapa hatiku cuma mau mampir di kamu?",
        "Jarak itu bukan masalah, yang masalah itu kalau hati kita yang menjauh.",
        "Senyum kamu itu kyk charger, kalau liat kamu semangatku langsung full lagi.",
        "Aku nggak minta bintang atau bulan, aku cuma minta kamu jangan pernah pergi.",
        "Tuhan itu baik ya, udah nyiptain orang sekeren kamu buat aku sayang.",
        "Setiap malam aku selalu titip rindu sama bintang, semoga sampai ke jendela kamarmu.",
        "Kalau mencintaimu adalah sebuah kesalahan, maka aku nggak mau jadi orang benar selamanya.",
        "Kamu adalah jawaban dari doa-doa yang selalu aku panjatkan di sepertiga malam."
    ];
    const hasilQuote = quotes[Math.floor(Math.random() * quotes.length)];

    let teks = `*── 「 QUOTES BUCIN 」 ──*\n\n`
    teks += `"${hasilQuote}"\n\n`
    teks += `~ _${global.botname}_`

    await raiden.sendMessage(m.chat, { 
        text: teks 
    }, { 
        quoted: {
            key: { fromMe: false, participant: m.sender, remoteJid: m.chat },
            message: { extendedTextMessage: { text: "bentar wok, lagi nyari kata-kata buat kamu❤️" } }
        }
    });
};

export default handler;
