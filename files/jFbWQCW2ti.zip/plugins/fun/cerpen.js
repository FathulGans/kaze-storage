const pluginConfig = {
  name: 'cerpen',
  category: 'fun',
  command: ['cerpen'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 let cerpen = [
 {
 title: "🌟 Impian Seorang Penulis",
 story: "Di sebuah desa kecil bernama Sukawening, hiduplah seorang anak laki-laki bernama Kiko. Ia menghabiskan hari-harinya menulis cerita di bawah pohon rindang. Suatu hari, tulisannya ditemukan oleh seorang penerbit dari kota besar. Dari sanalah mimpi Kiko perlahan menjadi kenyataan, satu kata demi satu kata."
 },
 {
 title: "🎨 Warna di Taman Kota",
 story: "Lila adalah gadis kecil yang selalu membawa kotak cat ke mana pun ia pergi. Di taman kota, ia melukis langit, pohon, dan wajah orang-orang yang lewat. Suatu sore, seorang nenek tua berhenti dan menatap lukisannya lama sekali, lalu berkata, 'Kamu melukis perasaan, bukan sekadar gambar.' Sejak itu, Lila tahu bahwa seni bukan soal teknik, tapi soal hati."
 },
 {
 title: "🌲 Bahasa Hutan",
 story: "Kakek Tono hidup di pinggir hutan sejak muda. Ia percaya setiap pohon punya cerita. Setiap pagi ia berjalan, mendengarkan gemerisik daun dan kicauan burung. Cucunya, Reno, tertawa mendengar cerita itu — sampai suatu malam seekor rusa datang ke halaman rumah mereka, tepat seperti yang Kakek Tono ramalkan. Malam itu Reno mulai belajar mendengarkan."
 },
 {
 title: "🌊 Surat dari Tepi Pantai",
 story: "Setiap tahun, Nadia menulis surat dan menghanyutkannya ke laut. Ia tidak tahu siapa yang akan menemukannya. Suatu hari, sebuah surat balasan tiba — dari seorang anak di pulau seberang bernama Faiz. Persahabatan mereka tumbuh lewat surat-surat yang ditiup angin laut, tanpa pernah bertemu, namun terasa lebih dekat dari siapapun."
 },
 {
 title: "🌙 Bintang untuk Ibu",
 story: "Dito kecil selalu bertanya, 'Bu, bintang itu milik siapa?' Ibunya selalu menjawab, 'Milik orang yang berani bermimpi.' Bertahun kemudian, saat Dito menerima penghargaan sebagai ilmuwan muda terbaik, ia mendongak ke langit malam. Di sana, satu bintang terasa lebih terang — persis seperti yang selalu ditunjuk ibunya dulu."
 },
 {
 title: "🍃 Pohon Tua di Lapangan",
 story: "Pohon beringin itu sudah berdiri ratusan tahun di tengah lapangan desa. Anak-anak bermain di bawahnya, orang tua bercengkrama di sisinya. Suatu hari datang kabar bahwa pohon itu akan ditebang untuk pembangunan. Seluruh desa berkumpul, dan untuk pertama kalinya dalam puluhan tahun, mereka bersatu — melindungi sesuatu yang selama ini menyatukan mereka."
 },
 {
 title: "🎵 Melodi Hujan",
 story: "Setiap kali hujan turun, Nina duduk di jendela dan memainkan piano. Tetangganya sempat mengeluh — tapi lama-lama mereka diam dan mendengarkan. Suatu hari, seorang anak kecil dari ujung gang mengetuk pintunya. 'Kak, ajari aku main piano?' Dari sanalah Nina belajar bahwa musik bukan hanya untuk didengar, tapi untuk dibagikan."
 },
 {
 title: "🌺 Kebun Terakhir",
 story: "Nenek Sari menanam bunga seumur hidupnya. Ketika ia sakit dan tidak bisa ke kebun, bunga-bunga itu layu satu per satu. Tapi setiap pagi, cucunya Sinta diam-diam menyiram dan merawat kebun itu. Saat Nenek Sari sembuh dan melihat kebunnya masih mekar indah, air matanya jatuh tanpa kata-kata. Ada cinta yang tidak perlu diucapkan."
 },
 {
 title: "🦋 Kepompong",
 story: "Raka selalu merasa dirinya lambat. Di sekolah ia tertinggal, di rumah ia pendiam. Gurunya memberinya sebuah kotak berisi kepompong. 'Tunggu,' kata sang guru. Seminggu kemudian, seekor kupu-kupu indah keluar dari kotak itu. 'Kamu seperti ini,' bisik gurunya. 'Sedang berproses.' Raka tersenyum — untuk pertama kalinya dalam waktu yang lama."
 },
 {
 title: "🔦 Senter Ayah",
 story: "Ayah selalu membawa senter tua ke mana-mana. 'Buat apa, Yah?' tanya Dani. 'Untuk menerangi jalan orang lain,' jawabnya. Dani tidak mengerti saat itu. Tapi bertahun kemudian, saat ia menjadi dokter di daerah terpencil tanpa listrik, ia mengeluarkan senter tua peninggalan ayahnya dan mulai memahami segalanya."
 },
 {
 title: "🏠 Rumah di Ujung Gang",
 story: "Rumah itu selalu ramai meski sempit. Ibu memasak untuk semua tetangga yang lapar, ayah meminjamkan uang tanpa bertanya kapan dikembalikan. Anak-anak mereka sering malu karena keluarga mereka tak punya banyak harta. Sampai suatu hari mereka sadar — seluruh kampung hadir di pemakaman ayah mereka. Kekayaan yang sesungguhnya bukan di rekening bank."
 },
 {
 title: "📚 Perpustakaan Rahasia",
 story: "Di balik lemari tua di gudang sekolah, Wulan menemukan pintu kecil. Di baliknya ada ratusan buku tua berdebu. Setiap sore ia membaca diam-diam di sana, menjelajahi dunia tanpa pernah ke mana-mana. Ketika ia dewasa dan menjadi penjelajah sejati, ia selalu berkata bahwa petualangan pertamanya dimulai dari balik lemari tua itu."
 },
 {
 title: "🌅 Fajar di Puncak",
 story: "Mereka mendaki tiga hari tiga malam. Saat puncak akhirnya tercapai, tidak ada kata yang keluar — hanya tangis haru dan senyum lelah. Langit pagi menyambut mereka dengan warna yang tidak bisa dilukis. Arman menatap cakrawala dan berkata pelan, 'Semua yang berat di bawah sana, terlihat begitu kecil dari sini.'"
 },
 {
 title: "🐟 Ikan dan Nelayan Tua",
 story: "Pak Hamid sudah menangkap ikan selama lima puluh tahun. Suatu pagi jaring nya penuh — lebih dari biasanya. Tapi di tengah ikan-ikan itu ia menemukan seekor ikan kecil yang menatapnya. Ia melepaskannya kembali. Muridnya yang muda protes, 'Kenapa dilepas?' Pak Hamid menjawab, 'Karena laut bukan milik kita. Kita hanya tamunya.'"
 },
 {
 title: "✈️ Tiket Pulang",
 story: "Rini sudah sepuluh tahun di luar negeri. Ia sukses, punya apartemen bagus, karier cemerlang. Tapi setiap malam ia bermimpi tentang aroma masakan ibunya. Ketika akhirnya ia membeli tiket pulang, bukan karena kalah — tapi karena ia akhirnya mengerti bahwa rumah bukan tempat yang kamu tinggalkan, tapi tempat yang selalu kamu rindukan."
 }
 ];

 let random = Math.floor(Math.random() * cerpen.length);
 let selectedCerpen = cerpen[random];

 try {
 Reply(`╭─❏ ${selectedCerpen.title}\n│\n│ ${selectedCerpen.story}\n│\n╰──────────❏`);
 } catch (e) {
 Reply(mess.error);
 }
};

export default handler;
