import __baileys from '../../src/lib/baileys-compat.js';

const pluginConfig = {
  name: 'kudeta',
  category: 'fun',
  command: ['kudeta'],
};

const handler = async (m, ctx) => {
    let { Reply, command, isVip, prefix, raiden, text } = ctx;
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isBotAdmin) return Reply(mess.botAdmin);
    if (!isVip) return Reply('❌ Perintah ini sangat berbahaya dan hanya bisa digunakan oleh Owner bot!');
    
    if (text.toLowerCase() !== 'yes') {
        return Reply(`⚠️ *PERINGATAN KUDETA!* ⚠️\n\nPerintah ini akan:\n1. Mencabut jabatan SEMUA ADMIN\n2. Menge-kick para mantan admin tersebut\n3. Memastikan semua nomor Owner menjadi Admin\n4. Menutup grup secara otomatis\n\nJika kamu benar-benar yakin, ketik:\n*${prefix + command} yes*`);
    }

    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    const { areJidsSameUser } = __baileys;

    const groupMetadata = m.metadata || await raiden.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    
    const ownerJids = Array.isArray(global.creator) 
        ? global.creator.map(v => String(v).replace(/[^0-9]/g, '') + '@s.whatsapp.net') 
        : [String(global.creator).replace(/[^0-9]/g, '') + '@s.whatsapp.net'];

    const admins = participants.filter(v => v.admin !== null).map(v => v.jid || v.id);
    
    const targetAdmins = admins.filter(id => 
        !areJidsSameUser(id, raiden.user.id) &&
        !areJidsSameUser(id, m.sender) && 
        !ownerJids.some(ownerId => areJidsSameUser(id, ownerId))
    );

    if (targetAdmins.length === 0) return Reply('❌ Tidak ada admin yang bisa dikudeta. Kamu dan bot sudah berkuasa penuh!');

    await Reply('🚨 *PROTOKOL KUDETA DIMULAI!* 🚨\nMenyingkirkan admin lama & mengamankan posisi Owner...');

    for (let admin of targetAdmins) {
        try {
            await raiden.groupParticipantsUpdate(m.chat, [admin], 'demote');
            await sleep(800);
            await raiden.groupParticipantsUpdate(m.chat, [admin], 'remove');
            await sleep(800);
        } catch (e) {
            console.log(`Gagal mengkudeta ${admin}:`, e);
        }
    }

    const groupMembers = participants.map(v => v.jid || v.id);
    const ownersInGroup = groupMembers.filter(id => ownerJids.some(ownerId => areJidsSameUser(id, ownerId)));
    
    for (let ownerJid of ownersInGroup) {
        const isAlreadyAdmin = participants.find(v => areJidsSameUser(v.jid || v.id, ownerJid) && v.admin !== null);
        if (!isAlreadyAdmin) {
            try {
                await raiden.groupParticipantsUpdate(m.chat, [ownerJid], 'promote');
                await sleep(800);
            } catch (e) {
                console.log(`Gagal promote owner ${ownerJid}:`, e);
            }
        }
    }

    try {
        await raiden.groupSettingUpdate(m.chat, 'announcement');
        await Reply('🔒 *KUDETA BERHASIL!* 🏴‍☠️\n\nSemua admin lama telah disingkirkan, hak akses Owner telah dipulihkan/diamankan, dan grup telah ditutup. Kekuasaan penuh di tangan kita!');
    } catch (e) {
        await Reply('⚠️ Kudeta selesai, admin telah disingkirkan, tapi gagal menutup grup secara otomatis.');
    }
};

export default handler;
