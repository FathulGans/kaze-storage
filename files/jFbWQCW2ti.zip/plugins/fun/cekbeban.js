import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'cekbeban',
  category: 'fun',
  command: ['cekbeban'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, text } = ctx;
  if (!isRegistered(m.sender) && !isVip) return Reply(`❌ *KAMU BELUM TERDAFTAR*`);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


  if (!text) return Reply(example("nama"));

  const persen = Math.floor(Math.random() * 101);
  let katakata;
  if (persen > 90) {
    katakata = `Level Beban: *BEBAN INTERNASIONAL* 🌍\n\nKeberadaan ${text} adalah alasan kenapa orang tuanya sering ikut seminar "sabar itu indah". Kontribusi lo di rumah cuma nambah tagihan listrik sama cucian kotor.`;
  } else if (persen > 70) {
    katakata = `Level Beban: *PENGGANGGURAN ESTETIK* 🚬\n\n${text} kerjaannya rebahan, ngeluh, terus minta duit. Lo bukan pengangguran, lo adalah "seniman gaya hidup pasif". Circle lo udah capek dengerin keluhan lo.`;
  } else if (persen > 40) {
    katakata = `Level Beban: *ANGGOTA PASIF* 😴\n\nDi grup, ${text} cuma jadi 'sider'. Diajak nongkrong banyak alasan. Dimintain tolong, read doang. Kontribusi lo setara dengan 'R' di chat grup.`;
  } else {
    katakata = `Level Beban: *ASET BERHARGA* 💪\n\nLuar biasa! ${text} adalah orang yang diandalkan. Lo mandiri, rajin, dan sering jadi tempat curhat. Teruslah menjadi inspirasi!`;
  }
  
  Reply(`
 BEBAN METER
 █▒▒▒▒▒▒▒▒▒  ${persen}%
 
 ${katakata}
  `.trim());
};

export default handler;
