const pluginConfig = {
  name: 'cekjahat',
  category: 'fun',
  command: ['cekjahat'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden, troli } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
const _tJ = m.mentionedJid[0]||(m.quoted?m.quoted.sender:m.sender);
const _pJ = Math.floor(Math.random()*101);
const _kJ = _pJ>=80?'Villain kelas atas! Niat jahatnya terencana rapi 😈':_pJ>=50?'Jahat moderat, suka ngerjain orang tapi masih ada batas 🙃':_pJ>=20?'Jahilnya wajar, masih manusia normal 😅':'Terlalu baik! Ntar malah dimanfaatin orang 🥺';
await raiden.sendMessage(m.chat,{text:`😈 *CEK TINGKAT KEJAHATAN*\n\nTarget: @${_tJ.split('@')[0]}\nTingkat Kejahatan: *${_pJ}%*\n\n📝 ${_kJ}`,mentions:[_tJ]},{ quoted: troli });
};

export default handler;
