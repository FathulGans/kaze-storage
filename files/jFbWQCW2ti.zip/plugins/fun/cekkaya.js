import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'cekkaya',
  category: 'fun',
  command: ['cekkaya'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, raiden, text } = ctx;
  if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);

  if (!text) return Reply(example("nama"))

  let who = m.mentionedJid?.[0] ?? m.quoted?.sender ?? m.sender;
  let name = await raiden.getName(who);

  let reportList = [
    `
👤 Nama: ${name}
📍 Status: Miskin spiritual & finansial

📝 Isi rekening 0, isi hati kosong. Nafas lo bau utang. Hidup lo kayak Indomie 3 hari berturut-turut: kenyang tapi bikin nelangsa.

📎 Saran: kerja bukan buat flex, tapi biar titit gak sedih.`,

    `
👤 Nama: ${name}
📍 Status: Flexer buta realita

📝 Outfit lo 3 juta, utang lo 9 juta. Beli boba tiap sore, padahal tagihan Shopee belum dibayar. Gaya sultan, dompet rakyat.

📎 Saran: downgrade gaya, upgrade otak dan dompet.`,

    `
👤 Nama: ${name}
📍 Status: Warisan cancel

📝 Jodoh lo kabur, kerjaan gak ada, warisan ditolak karena kelakuan lo kayak maling pulsa. Lo hidup dari sisa-sisa keyakinan palsu.

📎 Saran: jangan nunggu dapet, mulai usaha dari nol, bukan dari ngemis.`,

    `
👤 Nama: ${name}
📍 Status: Dompet krisis, attitude minus

📝 Lo pengangguran tapi picky. Kerjaan males, jajan jalan terus. Uang habis, harga diri ikutan.

📎 Saran: stop mikir jadi sultan, lo masih jadi beban grup.`,

    `
👤 Nama: ${name}
📍 Status: Dompet low, mimpi high

📝 Lo pengen liburan ke Jepang, tapi buat beli Aqua aja ngutang ke temen. Kepala di awan, saldo di neraka.

📎 Saran: tarik mimpi ke realita, terus tarik kabel charger, kerja!`,

    `
👤 Nama: ${name}
📍 Status: Kaya niat doang

📝 Lo selalu bilang "lagi nabung", padahal saldo Dana lo Rp3.272. Muka pede, dompet nyesek.

📎 Saran: jangan toxic positivity ke keuangan sendiri.`,

    `
👤 Nama: ${name}
📍 Status: Sekaya piring kosong

📝 Rumah ngontrak, sepatu sobek, tapi nyimpen wishlist iPhone tiap malam. Lo tuh bukan ngirit, lo tuh emang ga punya apa-apa.

📎 Saran: stop denial, mulai dagang apa aja kecuali harapan palsu.`,

    `
👤 Nama: ${name}
📍 Status: Sisa uangnya dari refund

📝 Sumber kekayaan: cashback, refund, dan sisa kembalian ojol. Lo tuh walking diskon hunter, bukan entrepreneur.

📎 Saran: lo butuh kerjaan, bukan kode promo.`,

    `
👤 Nama: ${name}
📍 Status: Pemuda PayLater

📝 Gaya hidup lo dibiayai utang jangka panjang. Lo cicil martabak, lo nyicil dosa. Mental kaya, tapi nyolong waktu buat bayar tagihan.

📎 Saran: puasa Shopee, puasa flexing, fokus napas aja dulu.`,

    `
👤 Nama: ${name}
📍 Status: Gaji numpang lewat

📝 Gaji masuk langsung keluar. Lo cuma halte bagi duit, bukan terminal kekayaan. Uang nempel 2 jam udah ilang.

📎 Saran: simpen dikit buat hidup, jangan semua buat healing palsu.`,

    `
👤 Nama: ${name}
📍 Status: Mental UMR, gaya CEO

📝 Nongkrong tiap hari, tapi bensin patungan. Baju branded, tapi sabun muka abis 2 minggu ga beli. Lo hidup pake impresi, bukan realita.

📎 Saran: kerja keras dulu, baru minum kopi 45 ribu.`,

    `
👤 Nama: ${name}
📍 Status: Pura-pura humble padahal beneran kere

📝 Lo bilang "gue anaknya simple aja", padahal gak punya apa-apa buat ditunjukin. Lo bukan lowkey, lo emang low budget.

📎 Saran: gak usah malu miskin, yang penting gak bego.`,

    `
👤 Nama: ${name}
📍 Status: Kaya dari giveaway

📝 Duit lo ada karena hoki, bukan kerja. Lo bukan sultan, lo hoki account. Besok kalah kuis, balik kismin.

📎 Saran: jangan andelin rezeki dari spin, kerja bang.`,

    `
👤 Nama: ${name}
📍 Status: Anak sultan, otak receh

📝 Ortu tajir, tapi lo otaknya pengangguran. Uang ada, skill gaada. Duit keturunan, tapi kelakuan downgrade.

📎 Saran: jangan cuma lahir kaya, coba mikir juga.`,

    `
👤 Nama: ${name}
📍 Status: Cuan tapi toxic

📝 Duit lo ada, tapi lo nyebelin. Ngetreat orang kayak staff, padahal cuma laku di circle lo sendiri. Tajir, tapi sepi.

📎 Saran: perbaiki attitude sebelum Tuhan tarik semua yang lo pamerin.`,

    `
👤 Nama: ${name}
📍 Status: Kosong tapi optimis

📝 Lo miskin tapi pede. Gak punya duit tapi selalu bilang "aku yakin aku bisa sukses". Lo sih semangat, tapi dompet lo nangis.

📎 Saran: gapapa optimis, asal sambil kerja, bukan rebahan sambil afirmasi kosong.`,

    `
👤 Nama: ${name}
📍 Status: Cashflow mental illness

📝 Lo bukan boros. Lo pake duit buat nutupin luka batin. Tiap sedih, lo checkout. Tiap gagal, lo jajan. Uang lo jadi korban mood swing.

📎 Saran: cari bahagia yang gak ngurangin saldo.`,

    `
👤 Nama: ${name}
📍 Status: Tabungan isinya screenshot

📝 Lo bilang "duitku aman kok", padahal itu capture rekening dari 2019. Real life lo tinggal debu digital. Uang tinggal konsep.

📎 Saran: stop acting rich online, lo tuh buffer.`,

    `
👤 Nama: ${name}
📍 Status: Gajian = pesta, besok = puasa

📝 Tiap tanggal 25 lo jadi raja, tanggal 28 lo cari receh di saku jaket. Lo bukan sultan, lo roleplayer kemewahan musiman.

📎 Saran: stabilin otak dulu baru penghasilan.`,

    `
👤 Nama: ${name}
📍 Status: Nyimpen receh dalam mimpi

📝 Lo jago ngatur uang... kalo lagi tidur. Di realita? Setiap nemu duit malah beli skin. Dompet lo kayak sahabat: gak pernah penuh.

📎 Saran: budgeting itu nyata, bukan cuma quotes IG.`
  ];

  let pick = reportList[Math.floor(Math.random() * reportList.length)];
  Reply(pick, [who]);
};

export default handler;
