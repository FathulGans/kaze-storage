import fetch from 'node-fetch';

const pluginConfig = {
  name: 'sertifika-tolol',
  category: 'ephoto',
  command: ["sertifikat-tolol","sertifikattolol","sertifikat"],
};

let handler = async (m, { raiden, command, isVip, Reply, text }) => {
  if (!isRegistered(m.sender) && !isVip)
    return Reply(global.mess.verifikasi);
if (checkLimit(m.sender, (await import('../../src/lib/tiers.js')).default.isPrem(m.sender), isVip))
return Reply(global.mess.limit);
addLimit(m.sender, (await import('../../src/lib/tiers.js')).default.isPrem(m.sender), isVip);

    if (!text) return Reply(`❌ Contoh penggunaan:\n\n*.${command} jokowi*`)

    try {
        let api = `https://api.siputzx.my.id/api/m/sertifikat-tolol?text=${encodeURIComponent(text)}`
        await raiden.sendMessage(m.chat, {
            image: { url: api },
            caption: `🖼️ *SERTIFIKAT*\n\n${text}`
        }, { quoted: m })
    } catch (e) {
        console.error(e)
        Reply("❌ Terjadi error saat membuat sertifikat.")
    }
}

export default handler