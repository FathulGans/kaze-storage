import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'kompres',
  category: 'ephoto',
  command: ['kompres', 'compress', 'pres'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, safeErr, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit)     
    const type = m.quoted ? (m.quoted.mtype || Object.keys(m.quoted.message || {})[0] || '') : ''
    if (!m.quoted || !/image/i.test(type)) return Reply(`📌 reply gambar yang mau dikompres terus tentukan target ukuran (100-800 kb)\ncontoh: *${prefix + command} 200*`)        
    let targetSize = parseInt(text)
    if (!targetSize || targetSize > 800 || targetSize < 100) return Reply(`⚠️ masukkan target ukuran antara 100 sampe 800 kb`)    
    try {
        await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })        
        const sharp = (await import('sharp')).default
        const media = await m.quoted.download()        
        let quality = 100
        let buffer = await sharp(media).jpeg({ quality, progressive: true }).toBuffer()        
        while (buffer.length / 1024 > targetSize && quality > 5) {
            quality -= 5
            buffer = await sharp(media).jpeg({ quality, progressive: true }).toBuffer()
        }            
        await raiden.sendMessage(m.chat, { 
            image: buffer, 
            caption: `✅ *Sukses Kompres*\n\n📊 *Target:* ${targetSize} kb\n📉 *Hasil:* ${(buffer.length / 1024).toFixed(2)} kb\n🚀 *Status:* Berhasil diperkecil` 
        }, { quoted: m })                
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
        addLimit(m.sender, tierAkses.isPrem(m.sender), isVip)
    } catch (err) {
        console.error(err)
        Reply(`❌ gagal kompres: ${safeErr(err)}`)
    }
};

export default handler;
