import axios from 'axios';
import fs from 'fs';
import tierAkses from '../../src/lib/tiers.js';
import { ytdl2 } from '../../src/scraper/ytdl2.js';
import __baileys from '../../src/lib/baileys-compat.js';
const { generateWAMessageFromContent } = __baileys;

const pluginConfig = {
  name: 'ytmp3',
  category: 'download',
  command: ['ytmp3'],
};

const MAX_SIZE = 50 * 1024 * 1024;

async function getAudio(url) {
    try {
        const r = await ytdl2(url, { format: 'mp3' });
        const res = await axios.get(r.download, {
            responseType: 'arraybuffer',
            timeout: 120000,
            maxContentLength: MAX_SIZE * 2,
            maxBodyLength: MAX_SIZE * 2,
            headers: r.headers || {}
        });
        const type = String(res.headers['content-type'] || '');
        if (/text\/html|application\/json/i.test(type)) throw new Error('Respons bukan file audio');
        return {
            buffer: Buffer.from(res.data),
            title: r.title,
            duration: r.duration,
            thumbnail: r.thumbnail,
            filePath: null
        };
    } catch (e) {
        console.error('[YTMP3] ytdl2 gagal, pakai yt-dlp:', e.message);
    }

    const { default: ytdlp } = await import('../../src/scraper/ytdlp.js');
    const result = await ytdlp.download(url, { mode: 'audio' });
    return {
        buffer: fs.readFileSync(result.filePath),
        title: result.info?.title,
        duration: result.info?.duration_string,
        thumbnail: result.info?.thumbnail,
        filePath: result.filePath
    };
}

const handler = async (m, ctx) => {
    let { Reply, command, isVip, prefix, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return
    if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return
    if (!text) return Reply(`❌ Masukkan link YouTube-nya.\nContoh: ${prefix}${command} https://youtu.be/xxxxx`)
    if (!text.includes('youtube.com') && !text.includes('youtu.be')) return Reply('Link YouTube tidak valid')

    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    addLimit(m.sender, tierAkses.isPrem(m.sender), isVip)

    const url = (text.match(/(https?:\/\/[^\s]+)/i) || [text.trim()])[0]
    let filePath = null

    try {
        const audio = await getAudio(url)
        filePath = audio.filePath

        if (audio.buffer.length > MAX_SIZE) {
            return Reply('File terlalu besar (di atas 50MB)')
        }

        const judul = audio.title || 'YouTube Audio'
        let thumb = null
        if (audio.thumbnail) {
            try {
                const t = await axios.get(audio.thumbnail, { responseType: 'arraybuffer', timeout: 15000 })
                thumb = Buffer.from(t.data)
            } catch {}
        }

        const desc = `Durasi: ${audio.duration || '-'}`
        const card = generateWAMessageFromContent(m.chat, {
            extendedTextMessage: {
                text: `🎵 *${judul}*\n${desc}\n${url}`,
                matchedText: url,
                canonicalUrl: url,
                title: judul,
                description: desc,
                previewType: 0,
                ...(thumb ? { jpegThumbnail: thumb } : {})
            }
        }, { quoted: m })
        await raiden.relayMessage(m.chat, card.message, { messageId: card.key.id })

        await raiden.sendMessage(
            m.chat,
            {
                audio: audio.buffer,
                mimetype: 'audio/mpeg',
                ptt: false
            },
            { quoted: m }
        )

        await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (e) {
        console.error('[YTMP3 ERROR]', e)
        await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } })

        const msg = String(e?.message || '')
        if (e.code === 'ECONNABORTED' || /timeout/i.test(msg)) {
            Reply('Timeout: Proses terlalu lama')
        } else if (e.response && e.response.status === 404) {
            Reply('Audio tidak ditemukan')
        } else if (e.response && e.response.status === 403) {
            Reply('Akses ditolak oleh server')
        } else {
            Reply('Error saat memproses audio')
        }
    } finally {
        if (filePath) fs.unlink(filePath, () => {})
    }
};

export default handler;