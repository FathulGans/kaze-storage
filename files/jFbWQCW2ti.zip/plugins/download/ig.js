import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'ig',
  category: 'download',
  command: ['ig', 'igdl', 'instagram'],
};

const API = 'https://api-cloud.my.id/downloader/instagram';
const MAKS_CAPTION = 700;

async function keBuffer(item) {
    const isi = item.base64 || item.data || item.url || '';
    if (typeof isi !== 'string' || !isi) return null;
    if (/^https?:\/\//.test(isi)) {
        const res = await axios.get(isi, { responseType: 'arraybuffer', timeout: 120000 });
        return Buffer.from(res.data);
    }
    const buf = Buffer.from(isi.replace(/^data:[^;,]+;base64,/, ''), 'base64');
    return buf.length ? buf : null;
}

function jenisMedia(item, buf) {
    const t = String(item.type || item.mimeType || '').toLowerCase();
    if (t.includes('video')) return 'video';
    if (t.includes('image') || t.includes('photo')) return 'image';
    return buf && buf.length > 12 && buf.toString('ascii', 4, 8) === 'ftyp' ? 'video' : 'image';
}

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, safeErr, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    const link = String(text || '').trim().split(/\s+/)[0] || '';
    if (!link) return Reply(`📌 *Masukkan link Instagram!*\n\nContoh: ${prefix + command} https://www.instagram.com/reel/xxxxx`);
    if (!/instagram\.com|instagr\.am/i.test(link)) return Reply('❌ Link Instagram tidak valid!');
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    try {
        const { data, status } = await axios.get(`${API}?url=${encodeURIComponent(link)}`, {
            timeout: 180000,
            maxContentLength: 200 * 1024 * 1024,
            validateStatus: () => true,
        });
        if (data?.status !== true || !data.result) throw new Error(data?.message || data?.error || `API Instagram gagal (HTTP ${status})`);
        const { username, caption } = data.result;
        const daftarMedia = Array.isArray(data.result.media) ? data.result.media : [];
        if (!daftarMedia.length) throw new Error('Postingan tidak berisi media (akun privat / link salah?)');

        const media = [];
        for (const item of daftarMedia) {
            const buf = await keBuffer(item).catch(() => null);
            if (buf) media.push({ jenis: jenisMedia(item, buf), buf });
        }
        if (!media.length) throw new Error('Media gagal dibaca dari API');

        const capPost = String(caption || '').trim();
        const teks = `${global.mess.done}\n` +
            (username && username !== '-' ? `\n👤 @${username}` : '') +
            `\n🖼️ ${media.length} media` +
            (capPost ? `\n\n${capPost.length > MAKS_CAPTION ? capPost.slice(0, MAKS_CAPTION) + '…' : capPost}` : '');
        const isiPesan = (x, cap) => x.jenis === 'video'
            ? { video: x.buf, mimetype: 'video/mp4', ...(cap ? { caption: cap } : {}) }
            : { image: x.buf, ...(cap ? { caption: cap } : {}) };

        if (media.length === 1) {
            await raiden.sendMessage(m.chat, isiPesan(media[0], teks), { quoted: m });
        } else {
            let albumTerkirim = false;
            try {
                await raiden.sendMessage(m.chat, {
                    album: media.map(x => x.jenis === 'video' ? { video: x.buf } : { image: x.buf }),
                    caption: teks,
                }, { quoted: m });
                albumTerkirim = true;
            } catch (e) {
                console.error('[IG] album gagal, kirim satu per satu:', e?.message || e);
            }
            if (!albumTerkirim) {
                for (let i = 0; i < media.length; i++) {
                    await raiden.sendMessage(m.chat, isiPesan(media[i], i === 0 ? teks : ''), { quoted: m });
                    await new Promise(r => setTimeout(r, 1000));
                }
            }
        }
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (error) {
        console.error('Instagram Download Error:', error?.message || error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        m.reply("❌ Terjadi kesalahan: " + String(safeErr(error) || error));
    }
};

export default handler;
