import __axios from 'axios';
import __form_data from 'form-data';

const pluginConfig = {
  name: 'tdl',
  category: 'download',
  command: ['tdl', 'twitterdl'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, q, raiden, troli } = ctx;
if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, isPremium, isVip))
return Reply(global.mess.limit);


;
 if (!q) {
 return raiden.sendMessage(m.chat, { text: 'Link Twitter-nya mana?' }, { quoted: troli });
 }
 if (!q.includes('x.com')) {
 return raiden.sendMessage(m.chat, { text: 'Link tidak valid!' }, { quoted: troli });
 }

 try {
 const axios = __axios;
 const FormData = __form_data;
 const cheerio = (await import('cheerio'));

 let form = new FormData();
 form.append("q", q);
 form.append("lang", "en");
 form.append("cftoken", "");

 let { data } = await axios.post(
 "https://savetwitter.net/api/ajaxSearch",
 form,
 { headers: form.getHeaders() }
 );

 if (!data.data) {
 return raiden.sendMessage(m.chat, { text: "Data kosong / tidak ditemukan" }, { quoted: troli });
 }

 const $ = cheerio.load(data.data);
 const thumbnail = $(".image-tw img").attr("src");
 let result = [];

 $(".dl-action a").each((_, el) => {
 const link = $(el).attr("href");
 const label = $(el).text().trim();
 if (link && label.includes("Download MP4")) {
 result.push({
 quality: label.replace("Download MP4", "").replace(/[()]/g, "").trim(),
 url: link
 });
 }
 });

 if (result.length === 0) {
 return raiden.sendMessage(m.chat, { text: "Video tidak ditemukan." }, { quoted: troli });
 }

 let caption = `*Semua Kualitas Tersedia:*\n\n`;
 result.forEach((v, i) => {
 caption += `${i+1}. *${v.quality}*\n${v.url}\n\n`;
 });
 await raiden.sendMessage(m.chat, { text: caption }, { quoted: troli });

 let high = result.find(v => v.quality.includes("1280"));
 if (high) {
 await raiden.sendMessage(m.chat, {
 video: { url: high.url },
 caption: `Berikut video kualitas *${high.quality}*`
 }, { quoted: troli });
 } else {
 await raiden.sendMessage(m.chat, { text: "Video kualitas 1280 tidak ditemukan." }, { quoted: troli });
 }

 } catch (e) {
 console.error(e);
 await raiden.sendMessage(m.chat, { text: "Terjadi kesalahan saat memproses permintaan." }, { quoted: troli });
 }
};

export default handler;
