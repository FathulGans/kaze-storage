import fetch from 'node-fetch';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'playv2',
  category: 'download',
  command: ['playv2'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);

 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);

 if (!text) return Reply('Masukkan judul lagu!\nContoh: *play Jakarta Hari Ini*');

 try {
 const res = await fetch(`https://api-cloud.my.id/downloader/play?query=${encodeURIComponent(text)}`);
 if (!res.ok) throw new Error('Gagal menghubungi server');

 const json = await res.json();
 if (!json.status || !json.result) return Reply('Lagu tidak ditemukan!');

 const { title, channel, duration, url, download } = json.result;

 await raiden.sendMessage(m.chat, {
 text: `🎵 *${title}*\n👤 ${channel}\n⏱️ ${duration}\n🔗 ${url}\n\n_Audio sedang dikirim..._`
 }, { quoted: m });

 await raiden.sendMessage(m.chat, {
 audio: { url: download },
 mimetype: 'audio/mpeg',
 fileName: `${title}.mp3`,
 ptt: false
 }, { quoted: m });

 } catch (e) {
 console.error(e);
 Reply('Terjadi kesalahan saat memproses permintaanmu.');
 }
};

export default handler;
