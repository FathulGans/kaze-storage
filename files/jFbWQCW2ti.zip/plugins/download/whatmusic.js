import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'whatmusic',
  category: 'download',
  command: ['whatmusic', 'whatmusik'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi)

    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit)

    const q = m.quoted ? m.quoted : m
    let mime = q?.msg?.mimetype || q?.mimetype || ""

    if (!/audio|video/.test(mime)) {
        return Reply(
            `╭─❏ *What Music* - Gagal
│✧ Alasan : Kirim atau reply audio/video
│✧ Format : .whatmusic
╰──────────❏`
        )
    }


    try {
        await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

        const buffer = await q.download()
        if (!buffer) {
            return Reply(
                `╭─❏ *What Music* - Gagal
│✧ Alasan : Gagal mengambil file
╰──────────❏`
            )
        }

        const apiUrl = `${global.termai}/api/audioProcessing/whatmusic?key=${global.apitermai}`

        const { data } = await axios.post(
            apiUrl,
            buffer,
            {
                headers: {
                    "Content-Type": "application/octet-stream"
                }
            }
        )

        if (!data || data.status !== true) {
            return Reply(
                `╭─❏ *What Music* - Gagal
│✧ Alasan : Musik tidak ditemukan
╰──────────❏`
            )
        }

        const result = data.data

        const teks = `╭─❏ *What Music* - Berhasil
│✧ Judul : ${result.title || '-'}
│✧ Artis : ${result.artists || '-'}
│✧ Acrid : ${result.acrid || '-'}
╰──────────❏`

        await raiden.sendMessage(m.chat, {
            text: teks,
            buttons: [
                {
                    buttonId: `.play ${result.title}`,
                    buttonText: { displayText: "🎧 Cari Musik" },
                    type: 1
                }
            ],
            headerType: 1
        }, { quoted: m })

        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } })

    } catch (e) {
        console.log(e)
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        
        Reply(
            `╭─❏ *What Music* - Gagal
│✧ Error : Gagal mengidentifikasi musik
╰──────────❏`
        )
    }
};

export default handler;
