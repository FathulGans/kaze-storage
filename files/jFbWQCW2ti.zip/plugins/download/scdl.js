import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'scdl',
  category: 'download',
  command: ['scdl', 'soundclouddl'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    if (!text) return Reply(example("https://soundcloud.com/artist/track"));
    
    const decodedUrl = decodeURIComponent(text);
    if (!decodedUrl.includes('soundcloud.com/')) return Reply("❌ Link SoundCloud tidak valid");

    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        const apiUrl = `https://api.siputzx.my.id/api/d/soundcloud?url=${encodeURIComponent(decodedUrl)}`;
        
        const { data } = await axios.get(apiUrl, { timeout: 30000 });

        if (!data.status || !data.data) throw new Error('Gagal mengambil data lagu');

        const { title, url, thumbnail, duration, user } = data.data;
        
        const audioResponse = await axios.get(url, { 
            responseType: 'arraybuffer',
            timeout: 60000 
        });
        const buffer = Buffer.from(audioResponse.data);

        if (buffer.length > 50 * 1024 * 1024) return Reply("❌ File terlalu besar (di atas 50MB)");

        const durationSec = Math.floor(duration / 1000);
        const minutes = Math.floor(durationSec / 60);
        const seconds = durationSec % 60;
        const durationStr = `${minutes}:${seconds.toString().padStart(2, '0')}`;

        await raiden.sendMessage(m.chat, {
    audio: buffer,
    mimetype: 'audio/mpeg',
    ptt: false
}, { quoted: m });

await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (error) {
        console.error('[SCDL ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;
