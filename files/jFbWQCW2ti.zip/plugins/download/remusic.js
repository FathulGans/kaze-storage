import axios from 'axios';
import crypto from 'crypto';
import fetch from 'node-fetch';

const pluginConfig = {
  name: 'remusic',
  category: 'download',
  command: ['remusic'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!isPremium && !isVip) return Reply(mess.prem);
 if (!text) return Reply(`Contoh: ${prefix + command} quiet at night, Reggae, Chill, Calm, Jazz`);

 addLimit(m.sender, isPremium, isVip);
 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 const API = "https://remusic.ai/api/v1/ai-music/music";
 const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0";

 const sleep = ms => new Promise(r => setTimeout(r, ms));
 const freshGa = () => `GA1.1.${Math.floor(Math.random() * 9e9 + 1e9)}.${Math.floor(Date.now() / 1000)}`;
 const randIP = () => Array.from({ length: 4 }, () => 1 + Math.floor(Math.random() * 254)).join(".");

 function headers() {
 return {
 "accept": "application/json, text/plain, */*",
 "content-type": "application/json",
 "origin": "https://remusic.ai",
 "referer": "https://remusic.ai/ai-music-generator",
 "user-agent": UA,
 "cookie": `_ga=${freshGa()}; anonymous_user_id=${crypto.randomUUID()}`,
 "x-forwarded-for": randIP()
 };
 }

 function pick(row) {
 return {
 id: row.song_id,
 title: row.title || null,
 status: row.status,
 audio: row.audio_url || null,
 image: row.image_url || row.cover_url || null,
 duration: row.duration || null,
 tags: row.tags || null,
 lyrics: row.lyrics || null,
 description: row.description || null
 };
 }

 async function createJob(body, maxRetries) {
 let last = "create failed";
 for (let i = 0; i < maxRetries; i++) {
 const res = await fetch(API, { method: "POST", headers: headers(), body: JSON.stringify(body) });
 const json = await res.json().catch(() => null);
 if (json && json.code === 100000 && Array.isArray(json.data) && json.data.length) return json.data;
 last = json ? `${json.code}: ${json.message}` : `http ${res.status}`;
 await sleep(600);
 }
 throw new Error(last);
 }

 async function pollJob(id) {
 for (let i = 0; i < 70; i++) {
 await sleep(5000);
 const res = await fetch(`${API}/${id}`, { headers: headers() });
 const json = await res.json().catch(() => null);
 const row = Array.isArray(json?.data) ? json.data[0] : json?.data;
 if (!row) continue;
 if (row.status === "success" && row.audio_url) return row;
 if (["failed", "error", "fail"].includes(row.status)) throw new Error("generation failed");
 }
 throw new Error("generation timeout");
 }

 async function generateMusic(prompt, options = {}) {
 const {
 styles = [],
 title = null,
 lyrics = null,
 mv = "v4",
 supplier = 10,
 maxRetries = 6
 } = options;

 const tags = (Array.isArray(styles) ? styles : [styles]).filter(Boolean).join(", ");
 const custom = !!(title || lyrics);

 const body = custom
 ? { mode: 2, supplier, mv, is_instrumental: false, is_public: true, prompt: String(prompt || tags || title), title: title || "", tags, lyrics: lyrics || "" }
 : { mode: 1, supplier, mv, is_instrumental: false, is_public: true, prompt: tags ? `${prompt}, ${tags}` : String(prompt) };

 const jobs = await createJob(body, maxRetries);
 const songs = await Promise.all(jobs.map(j => pollJob(j.song_id).then(pick).catch(() => ({ id: j.song_id, status: "failed", audio: null }))));

 return {
 ok: songs.some(s => s.audio),
 prompt: String(prompt || ""),
 styles: tags || null,
 mode: custom ? "custom" : "simple",
 count: songs.length,
 songs
 };
 }

 try {
 const args = text.split(",").map(s => s.trim());
 const prompt = args[0];
 const styles = args.slice(1);
 const result = await generateMusic(prompt, { styles });

 if (result.ok) {
 await raiden.sendMessage(m.chat, { text: "🎵 *Generating music...*" }, { quoted: m });

 for (let i = 0; i < result.songs.length; i++) {
 const song = result.songs[i];
 if (song.audio) {
 try {
 const audioBuffer = await axios.get(song.audio, {
 responseType: 'arraybuffer',
 timeout: 60000,
 headers: {
 'User-Agent': UA
 }
 });

 if (audioBuffer.data && audioBuffer.data.length > 1000) {
 await raiden.sendMessage(m.chat, {
 audio: Buffer.from(audioBuffer.data),
 mimetype: 'audio/mpeg',
 ptt: false
 }, { quoted: m });

 await raiden.sendMessage(m.chat, {
 text: `🎵 *${song.title || 'Music ' + (i + 1)}*\n` +
 `⏱️ ${song.duration || 'Unknown'}\n` +
 `🏷️ ${song.tags || result.styles || 'AI Generated'}\n` +
 `🤖 *${global.botname || 'Raiden Asisten'}*`
 }, { quoted: m });

 await new Promise(r => setTimeout(r, 1000));
 }
 } catch (e) {
 console.log(`[REMUSIC] Gagal download lagu ${i + 1}:`, e.message);
 await raiden.sendMessage(m.chat, {
 text: `❌ Gagal mengunduh lagu *${song.title || i + 1}*`
 }, { quoted: m });
 }
 }
 }

 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } else {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Gagal generate musik.\n\nCoba lagi dengan prompt yang berbeda.`);
 }
 } catch (e) {
 console.error('[REMUSIC ERROR]', e);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Error: ${e.message}`);
 }
};

export default handler;
