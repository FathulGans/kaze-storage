import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'capcut',
  category: 'download',
  command: ['capcut', 'capcutdl', 'capcutdownload'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
 
 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);
 
 if (!text) {
 return Reply(
 `╭─❏ *CapCut Downloader*
│✧ Format : .capcut [link]
╰──────────❏`
 )
 }
 
 if (!text.includes('capcut.com') && !text.includes('capcut.net')) {
 return Reply(
 `╭─❏ *CapCut Downloader* - Gagal
│✧ Alasan : Link CapCut tidak valid
╰──────────❏`
 )
 }
 
 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 
 try {
 const encodedUrl = encodeURIComponent(text);
 const apiUrl = `https://api-cloud.my.id/downloader/capcut?url=${encodedUrl}`;
 
 const response = await axios.get(apiUrl, { timeout: 30000 });
 const data = response.data;
 
 if (!data.status || !data.result) {
 throw new Error('Gagal mengambil data video dari server');
 }
 
 const result = data.result;
 const videoUrl = result.video;
 const title = result.title || 'CapCut Video';
 
 const videoResponse = await axios.get(videoUrl, {
 responseType: 'arraybuffer',
 timeout: 60000
 });
 
 const videoBuffer = Buffer.from(videoResponse.data);
 const fileSizeMB = (videoBuffer.length / 1024 / 1024).toFixed(1);
 
 const caption = `╭─❏ *CapCut Downloader*
│✧ Judul : ${title}
│✧ Ukuran : ${fileSizeMB} MB
╰──────────❏`;
 
 await raiden.sendMessage(m.chat, {
 video: videoBuffer,
 mimetype: 'video/mp4',
 caption: caption
 }, { quoted: m });
 
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error('[CAPCUT ERROR]', error);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 
 let errorMsg = error.message || 'Gagal mendownload video';
 if (error.code === 'ECONNABORTED') {
 errorMsg = 'Timeout, coba lagi nanti';
 } else if (error.response?.status === 404) {
 errorMsg = 'Video tidak ditemukan atau link sudah expired';
 } else if (error.response?.status === 403) {
 errorMsg = 'Akses ditolak oleh server';
 }
 
 Reply(
 `╭─❏ *CapCut Downloader* - Gagal
│✧ Error : ${errorMsg}
╰──────────❏`
 )
 }
};

export default handler;
