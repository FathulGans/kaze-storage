import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'toptv',
  category: 'download',
  command: ['toptv'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    if (!/video/.test(mime)) return Reply("❌ reply atau kirim video yang ingin dijadikan video ptv");
    try {
        await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        let media = await q.download();        
        await raiden.sendMessage(m.chat, { 
            video: media, 
            ptv: true 
        }, { quoted: m });
        await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
        console.error(e);
        Reply("❌ gagal mengonversi video ke ptv");
    }
};

export default handler;
