import axios from 'axios';

const pluginConfig = {
  name: 'videy',
  category: 'download',
  command: ['videy', 'vd'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) 
        return daftar(global.mess.verifikasi);

    if (!checkAndConsumeLimit(m.sender, isPremium, isVip))
        return Reply(global.mess.limit);

    if (!text || !text.startsWith('http')) return Reply(`Contoh: ${prefix + command} https://videy.co/`);


    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    const statusMsg = await m.reply('🔄 *Sedang memproses video Videy...*\n> Mohon tunggu, proses ini bisa memakan waktu hingga 1-2 menit tergantung koneksi.');

    try {
        const apiUrl = `https://api.nexray.web.id/downloader/videy?url=${encodeURIComponent(text)}`;
        
        const { data } = await axios.get(apiUrl, { timeout: 0 });

        if (data && data.status === true && data.result) {
            const videoUrl = data.result;
            const captionText = `📥 *VIDEY DOWNLOADER*\n\n *Status:* Berhasil\n *Sumber:* Videy\n`;
            
            await raiden.sendMessage(m.chat, { delete: statusMsg.key });
            
            await raiden.sendMessage(m.chat, { 
                video: { url: videoUrl }, 
                mimetype: 'video/mp4',
                caption: captionText 
            }, { quoted: m });
            
            await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

        } else {
            throw new Error(data?.message || 'Gagal mengunduh video');
        }

    } catch (error) {
        console.error('Videy Error:', error);
        
        await raiden.sendMessage(m.chat, { delete: statusMsg.key });
        
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        
        let errorMsg = '❌ *Gagal memproses video Videy*\n\n';
        if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
            errorMsg += '⏰ *Timeout:* Server terlalu lama merespon.\n';
            errorMsg += '💡 *Saran:* Coba lagi nanti atau gunakan link Videy lain.';
        } else if (error.response?.status === 404) {
            errorMsg += '🔍 *Link tidak valid:* Video tidak ditemukan.\n';
            errorMsg += '💡 *Saran:* Pastikan URL Videy benar dan video masih ada.';
        } else if (error.response?.status === 500) {
            errorMsg += '⚠️ *Server error:* Lanan downloader sedang sibuk.\n';
            errorMsg += '💡 *Saran:* Tunggu beberapa menit, lalu coba lagi.';
        } else {
            errorMsg += '🌐 *Koneksi error:* ' + (error.message || 'Tidak diketahui') + '\n';
            errorMsg += '💡 *Saran:* Coba lagi nanti.';
        }
        
        await m.reply(errorMsg);
    }
    return;
};

export default handler;
