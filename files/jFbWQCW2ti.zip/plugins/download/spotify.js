import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'spotify',
  category: 'download',
  command: ['spotify', 'ssp', 'spsearch'],
};

const handler = async (m, konteksInti) => {
    let { Reply, example, isVip, prefix, raiden, text } = konteksInti;
    if (!isRegistered(m.sender) && !isVip) return Reply(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    if (!text) return Reply(example("Justin Bieber"));

    await raiden.sendMessage(m.chat, { react: { text: "🔍", key: m.key } });

    try {
        const query = encodeURIComponent(text.trim());
        const apiUrl = `https://api-cloud.my.id/downloader/spotify2?query=${query}`;

        const response = await axios.get(apiUrl, { timeout: 60000 });
        const data = response.data;

        if (!data.status || !data.result || !data.result.download_url) {
            await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
            return Reply(`❌ Lagu "${text}" tidak ditemukan`);
        }

        const track = data.result;

        global.spotifyCache = global.spotifyCache || {};
        global.spotifyCache[m.sender] = { track, time: Date.now() };

        const { createCanvas, loadImage } = (await import('canvas')).default;
        const width = 1200;
        const height = 630;
        const canvas = createCanvas(width, height);
        const ctx = canvas.getContext('2d');

        const bgGrad = ctx.createLinearGradient(0, 0, width, height);
        bgGrad.addColorStop(0, '#0a0a0f');
        bgGrad.addColorStop(0.5, '#0f0f14');
        bgGrad.addColorStop(1, '#08080c');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);

        const glow = ctx.createRadialGradient(200, 315, 0, 200, 315, 500);
        glow.addColorStop(0, 'rgba(29,185,84,0.10)');
        glow.addColorStop(0.5, 'rgba(29,185,84,0.04)');
        glow.addColorStop(1, 'rgba(29,185,84,0)');
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, width, height);

        const glow2 = ctx.createRadialGradient(width, 0, 0, width, 0, 600);
        glow2.addColorStop(0, 'rgba(30,215,96,0.06)');
        glow2.addColorStop(1, 'rgba(30,215,96,0)');
        ctx.fillStyle = glow2;
        ctx.fillRect(0, 0, width, height);

        ctx.fillStyle = 'rgba(18, 18, 24, 0.90)';
        ctx.beginPath();
        ctx.roundRect(60, 60, width - 120, height - 120, 32);
        ctx.fill();

        ctx.strokeStyle = 'rgba(255,255,255,0.06)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(60, 60, width - 120, height - 120, 32);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(255,255,255,0.02)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(61, 61, width - 122, height - 122, 31);
        ctx.stroke();

        const thumbSize = 360;
        const thumbX = 100;
        const thumbY = (height - thumbSize) / 2;

        try {
            const thumb = await loadImage(track.thumbnail);

            ctx.save();
            ctx.beginPath();
            ctx.roundRect(thumbX, thumbY, thumbSize, thumbSize, 24);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(thumb, thumbX, thumbY, thumbSize, thumbSize);
            ctx.restore();

            ctx.shadowColor = 'rgba(0,0,0,0.6)';
            ctx.shadowBlur = 40;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 20;
            ctx.strokeStyle = 'rgba(255,255,255,0.08)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.roundRect(thumbX, thumbY, thumbSize, thumbSize, 24);
            ctx.stroke();
            ctx.shadowBlur = 0;
            ctx.shadowOffsetY = 0;
        } catch (e) {
            ctx.fillStyle = '#1DB954';
            ctx.beginPath();
            ctx.roundRect(thumbX, thumbY, thumbSize, thumbSize, 24);
            ctx.fill();

            ctx.font = 'bold 140px "Segoe UI", sans-serif';
            ctx.fillStyle = '#000000';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('♫', thumbX + thumbSize / 2, thumbY + thumbSize / 2);
            ctx.textAlign = 'left';
        }

        const pillW = 135;
        const pillH = 36;
        const pillX = thumbX + thumbSize + 70;
        const pillY = 125;

        ctx.fillStyle = '#1DB954';
        ctx.beginPath();
        ctx.roundRect(pillX, pillY, pillW, pillH, 18);
        ctx.fill();

        ctx.fillStyle = '#000000';
        ctx.font = 'bold 13px "Segoe UI", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('SPOTIFY', pillX + pillW / 2, pillY + pillH / 2);

        const textX = thumbX + thumbSize + 70;
        let currentY = 210;

        ctx.textAlign = 'left';
        ctx.textBaseline = 'alphabetic';
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 42px "Segoe UI", "Poppins", sans-serif';
        const title = track.title.length > 35 ? track.title.slice(0, 32) + '...' : track.title;
        ctx.fillText(title, textX, currentY);

        currentY += 55;
        ctx.fillStyle = '#a0a0b0';
        ctx.font = '24px "Segoe UI", sans-serif';
        const artist = track.artist.length > 40 ? track.artist.slice(0, 37) + '...' : track.artist;
        ctx.fillText(artist, textX, currentY);

        currentY += 50;
        ctx.strokeStyle = 'rgba(255,255,255,0.08)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(textX, currentY);
        ctx.lineTo(width - 100, currentY);
        ctx.stroke();

        currentY += 50;
        ctx.fillStyle = '#8888a0';
        ctx.font = '20px "Segoe UI", sans-serif';
        ctx.fillText(`⏱ ${track.duration || 'Unknown'}`, textX, currentY);

        currentY += 70;
        const badgeW = 220;
        const badgeH = 48;
        const badgeX = textX;
        const badgeY = currentY;

        ctx.fillStyle = 'rgba(29,185,84,0.15)';
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 24);
        ctx.fill();

        ctx.strokeStyle = 'rgba(29,185,84,0.35)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 24);
        ctx.stroke();

        ctx.fillStyle = '#1DB954';
        ctx.font = 'bold 15px "Segoe UI", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('SIAP DIDOWNLOAD', badgeX + badgeW / 2, badgeY + badgeH / 2);

        ctx.textAlign = 'left';
        ctx.textBaseline = 'alphabetic';
        ctx.fillStyle = 'rgba(255,255,255,0.25)';
        ctx.font = '14px "Segoe UI", sans-serif';
        const queryText = text.length > 40 ? text.slice(0, 37) + '...' : text;
        ctx.fillText(`Query: "${queryText}"`, textX, height - 95);

        ctx.fillStyle = 'rgba(29,185,84,0.10)';
        ctx.font = 'bold 180px "Segoe UI", sans-serif';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'bottom';
        ctx.fillText('♫', width - 80, height - 60);

        const spotifyBuffer = canvas.toBuffer('image/png');

        await raiden.sendMessage(
            m.chat,
            {
                image: spotifyBuffer,
                caption: `
╭─❏ 𝗦𝗽𝗼𝘁𝗶𝗳𝘆
│▣ Judul : ${track.title}
│▣ Artis : ${track.artist}
│▣ Album : ${track.album || '-'}
│▣ Durasi : ${track.duration || '-'}
╰──────────❏`,
                buttons: [
                    {
                        buttonId: `${prefix}spdown ${track.spotify_url}`,
                        buttonText: { displayText: '⬇️ Download' },
                        type: 1
                    }
                ],
                headerType: 4,
                viewOnce: true,
                contextInfo: {
                    mentionedJid: [m.sender]
                }
            },
            { quoted: m }
        );

        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error(e);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
};

export default handler;