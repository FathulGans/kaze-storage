import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'ttqc',
  category: 'download',
  command: ['ttqc'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!tierAkses.isPrem(m.sender) && !isVip) return Reply(mess.prem);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
 if (!text) return Reply(`Contoh: ${prefix + command} nama|teks`);

 let [nama, ...teksArr] = text.split('|');
 let teks = teksArr.join('|');
 if (!nama || !teks) return Reply(`Contoh: ${prefix + command} nama|teks`);

 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 let avatar = await raiden.profilePictureUrl(m.sender, 'image').catch(() => global.defaultPP);
 let url = `https://api.synoxcloud.xyz/canvas/ttqc?username=${encodeURIComponent(nama)}&text=${encodeURIComponent(teks)}&avatar=${encodeURIComponent(avatar)}`;
 let res = await axios.get(url, { responseType: 'arraybuffer' });
 let buffer = Buffer.from(res.data, 'binary');
 await raiden.sendMessage(m.chat, { image: buffer }, { quoted: m });
 } catch (e) {
 Reply(mess.error);
 }
};

export default handler;
