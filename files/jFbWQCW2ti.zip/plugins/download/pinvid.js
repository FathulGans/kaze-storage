import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';

const pluginConfig = {
  name: 'pinvid',
  category: 'download',
  command: ['pinvid', 'vidpin', 'vp', 'pinterestvideo'],
};

const handler = async (m, ctx) => {
    let { Reply, __dirname, daftar, example, isPremium, isVip, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
 if (!text) return Reply(example("teks yang dibutuhkan"));

 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 let tmpDir = path.join(__dirname, 'tmp');
 if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
 let tmpPath = path.join(tmpDir, `pin_${Date.now()}.mp4`);

 try {
 let { data } = await axios.get(`https://api.nexray.eu.cc/search/pinterestvideo?q=${encodeURIComponent(text)}`);

 if (!data?.status || !data?.result?.length) return Reply('Tidak ditemukan');

 let video = data.result[Math.floor(Math.random() * data.result.length)];
 let m3u8Url = video.video_url;

 await new Promise((resolve, reject) => {
 const ff = spawn('ffmpeg', ['-i', m3u8Url, '-c:v', 'libx264', '-c:a', 'aac', '-movflags', '+faststart', '-y', tmpPath]);
 let stderrBuf = '';
 ff.stderr.on('data', (d) => { stderrBuf += d.toString(); });
 ff.on('error', (err) => reject(err));
 ff.on('close', (code) => {
 if (code !== 0) {
 console.log('ffmpeg error:', stderrBuf);
 return reject(new Error(`ffmpeg exited with code ${code}`));
 }
 resolve();
 });
 });

 if (!fs.existsSync(tmpPath) || fs.statSync(tmpPath).size === 0) {
 return Reply('Gagal convert video');
 }

 await raiden.sendMessage(m.chat, {
 video: fs.readFileSync(tmpPath),
 caption: `Pinterest Video\n${video.title?.trim() ? `📝 ${video.title.trim()}` : ''}`
 }, { quoted: m });

 } catch (e) {
 console.log('pinvid error:', e?.response?.data || e.message);
 Reply(mess.error);
 } finally {
 if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
 }
};

export default handler;
