import axios from 'axios';

const pluginConfig = {
  name: 'likee',
  category: 'download',
  command: ['likee'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden, text, troli } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (checkLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
if (!text) return Reply('Format: *.likee <link>*\nContoh: .likee https://likee.video/xxxx');
await m.react('⏳'); addLimit(m.sender, isPremium, isVip);
try {
    const _lkUrl = `${global.apialip}/download/likee?apikey=${global.apikeyalip}&url=${encodeURIComponent(text)}`;
    const _lkRes = await axios.get(_lkUrl,{timeout:30000});
    const _lkData = _lkRes.data;
    if (!_lkData.status||!_lkData.result?.video) throw new Error('Gagal ambil video Likee');
    const _lkVid = await axios.get(_lkData.result.video,{responseType:'arraybuffer',timeout:60000});
    await raiden.sendMessage(m.chat,{video:Buffer.from(_lkVid.data),caption:`❤️ *${_lkData.result.title||'Likee Video'}*\n\n_Powered by ${botname}_`,mimetype:'video/mp4'},{ quoted: troli });
    await m.react('✅');
} catch(e) { await m.react('❌'); Reply('❌ Gagal download Likee: '+e.message); }
};

export default handler;
