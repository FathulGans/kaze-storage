import __crypto from 'crypto';
import axios from 'axios';
import fetch from 'node-fetch';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tt',
  category: 'download',
  command: ['tt', 'tiktok'],
};

const handler = async (m, ctx) => {
    let { daftar, example, generateWAMessage, generateWAMessageFromContent, isVip, prefix, prepareWAMessageMedia, proto, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);

 const crypto = __crypto;
 const TIKWM = "https://www.tikwm.com";
 const TT_UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36";
 const TT_URL_REGEX = /https?:\/\/(?:[\w-]+\.)?(?:tiktok\.com|tt\.site)\/[^\s]+/i;

 const extractTikTokUrl = (input) => {
 const match = String(input || "").match(TT_URL_REGEX);
 return match ? match[0].replace(/[)\]}>.,!?]+$/, "") : null;
 };

 const resolveTikTokUrl = async (url) => {
 try {
 const res = await fetch(url, { redirect: "follow", headers: { "User-Agent": TT_UA }, signal: AbortSignal.timeout(15000) });
 return res.url || url;
 } catch { return url; }
 };

 const ttAbs = (u) => (!u ? null : /^https?:\/\//i.test(u) ? u : TIKWM + u);
 const ttNum = (n = 0) => Number(parseInt(n) || 0).toLocaleString().replace(/,/g, ".");
 const ttDate = (n) => new Date(n).toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "numeric", minute: "numeric", second: "numeric" });

 const fetchTikwm = async (url) => {
 const res = (await axios.post(TIKWM + "/api/", {}, {
 headers: {
 Accept: "application/json, text/javascript, */*; q=0.01",
 "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
 "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
 Origin: TIKWM, Referer: TIKWM + "/", "User-Agent": TT_UA, "X-Requested-With": "XMLHttpRequest",
 },
 params: { url, count: 12, cursor: 0, web: 1, hd: 1 },
 timeout: 30000,
 })).data?.data;
 if (!res) return null;
 const images = Array.isArray(res.images) ? res.images : [];
 const isPhoto = images.length > 0;
 const data = isPhoto
 ? images.map((u) => ({ type: "photo", url: u }))
 : [
 { type: "nowatermark_hd", url: ttAbs(res.hdplay) },
 { type: "nowatermark", url: ttAbs(res.play) },
 { type: "watermark", url: ttAbs(res.wmplay) },
 ].filter((v) => v.url);
 if (!data.length) return null;
 return {
 title: res.title, region: res.region || "-",
 taken_at: res.create_time ? ttDate(res.create_time * 1000) : "-",
 duration: (isPhoto ? 0 : res.duration || 0) + " Seconds",
 data,
 music_info: { title: res.music_info?.title || "-", author: res.music_info?.author || "-", url: ttAbs(res.music) || ttAbs(res.music_info?.play) },
 stats: { views: ttNum(res.play_count), likes: ttNum(res.digg_count), comment: ttNum(res.comment_count), share: ttNum(res.share_count), download: ttNum(res.download_count) },
 author: { fullname: res.author?.unique_id || "-", nickname: res.author?.nickname || "-" },
 };
 };

 const fetchSiputzx = async (url) => {
 const res = (await axios.get("https://api.siputzx.my.id/api/d/tiktok", { params: { url }, timeout: 30000 })).data?.data;
 if (!res) return null;
 const images = res.images || res.photo || res.images_url || [];
 const isPhoto = Array.isArray(images) && images.length > 0;
 const videoUrl = res.video || res.no_watermark || res.play;
 const data = isPhoto ? images.map((u) => ({ type: "photo", url: u })) : videoUrl ? [{ type: "nowatermark", url: videoUrl }] : [];
 if (!data.length) return null;
 const st = res.stats || {};
 return {
 title: res.title || res.desc, region: res.region || "-", taken_at: "-",
 duration: (isPhoto ? 0 : res.duration || 1) + " Seconds",
 data,
 music_info: { title: res.music_info?.title || "-", author: res.music_info?.author || "-", url: res.music || res.audio || res.music_url || res.music_info?.url || null },
 stats: { views: ttNum(st.playCount || res.play_count), likes: ttNum(st.diggCount || res.digg_count || res.like_count), comment: ttNum(st.commentCount || res.comment_count), share: ttNum(st.shareCount || res.share_count), download: ttNum(res.download_count) },
 author: { fullname: res.author?.unique_id || res.author?.uniqueId || "-", nickname: res.author?.nickname || res.author?.name || "-" },
 };
 };

 const fetchTikTok = async (url) => {
 for (const [name, source] of [["tikwm", fetchTikwm], ["siputzx", fetchSiputzx]]) {
 try { const r = await source(url); if (r) return r; }
 catch (e) { console.error(`[tt] ${name} gagal:`, e.message); }
 }
 return null;
 };

 const getTikTok = async (url) => {
 const data = await fetchTikTok(url);
 if (data) return data;
 const resolved = await resolveTikTokUrl(url);
 if (resolved && resolved !== url) return fetchTikTok(resolved);
 return null;
 };

 const audioButtons = (musicUrl) => musicUrl ? [{
 name: "quick_reply",
 buttonParamsJson: JSON.stringify({ display_text: "🎵 Ambil Music", id: `${prefix}ttaudio ${musicUrl}` }),
 }] : [];

 const relayInteractive = async (media, bodyText, buttons) => {
 const msg = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: { message: { interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 header: proto.Message.InteractiveMessage.Header.fromObject(media ? { hasMediaAttachment: true, ...media } : { hasMediaAttachment: false }),
 body: proto.Message.InteractiveMessage.Body.fromObject({ text: bodyText }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `${global.botname || "RaidenAI"} · TikTok Downloader` }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({ buttons }),
 }) } },
 }, { userJid: m.sender, quoted: m });
 await raiden.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 };

 const sendTikTokVideo = async (videoUrl, caption, musicUrl) => {
 const buttons = audioButtons(musicUrl);
 if (buttons.length) {
 try {
 const media = await prepareWAMessageMedia({ video: { url: videoUrl } }, { upload: raiden.waUploadToServer });
 return await relayInteractive(media, caption, buttons);
 } catch (e) { console.error("[tt] interactive gagal, kirim video biasa:", e.message); }
 }
 try {
 return await raiden.sendMessage(m.chat, { video: { url: videoUrl }, mimetype: "video/mp4", caption }, { quoted: m });
 } catch (e) {
 console.error("[tt] kirim via URL gagal, coba buffer:", e.message);
 const vid = await axios.get(videoUrl, { responseType: "arraybuffer", timeout: 90000, maxRedirects: 5, headers: { "User-Agent": TT_UA, Referer: "https://www.tiktok.com/" } });
 return raiden.sendMessage(m.chat, { video: Buffer.from(vid.data), mimetype: "video/mp4", caption }, { quoted: m });
 }
 };

 const sendTikTokAlbum = async (photos, caption) => {
 const album = await generateWAMessageFromContent(m.chat, {
 messageContextInfo: { messageSecret: crypto.randomBytes(32) },
 albumMessage: { expectedImageCount: photos.length, expectedVideoCount: 0 },
 }, { userJid: m.sender, quoted: m, upload: raiden.waUploadToServer });
 await raiden.relayMessage(m.chat, album.message, { messageId: album.key.id });
 for (let i = 0; i < photos.length; i++) {
 const item = await generateWAMessage(m.chat, i === 0 ? { image: { url: photos[i].url }, caption } : { image: { url: photos[i].url } }, { upload: raiden.waUploadToServer });
 item.message.messageContextInfo = {
 messageSecret: crypto.randomBytes(32),
 messageAssociation: { associationType: 1, parentMessageKey: album.key },
 };
 await raiden.relayMessage(m.chat, item.message, { messageId: item.key.id });
 await new Promise((r) => setTimeout(r, 1000));
 }
 };

 const ttInput = (text || "").trim() || m.quoted?.text || "";
 if (!ttInput) return m.reply(example("url"));
 const ttUrl = extractTikTokUrl(ttInput);
 if (!ttUrl) return m.reply("❌ Link TikTok tidak valid.");

 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return m.reply(global.mess.limit);

 try {
 await raiden.sendMessage(m.chat, { react: { text: "🕕", key: m.key } });

 const result = await getTikTok(ttUrl);
 if (!result) {
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return m.reply("Gagal mengambil data. Coba lagi nanti.");
 }

 const isPhoto = result.data[0]?.type === "photo";
 const musicUrl = result.music_info.url;
 const LINE = "┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈";
 const durasi = String(result.duration).replace(" Seconds", " detik");
 const info = (extra) =>
 `▸ Author : ${result.author.nickname} (@${result.author.fullname})\n` +
 `▸ Judul : ${result.title || "-"}\n` +
 `▸ Musik : ${result.music_info.title} - ${result.music_info.author}\n` +
 extra +
 `▸ Upload : ${result.taken_at}\n` +
 `▸ Region : ${result.region}`;
 const stat =
 `👁 Views : ${result.stats.views}\n` +
 `❤️ Suka : ${result.stats.likes}\n` +
 `💬 Komentar : ${result.stats.comment}\n` +
 `🔁 Share : ${result.stats.share}\n` +
 `⬇️ Unduh : ${result.stats.download}`;

 if (!isPhoto) {
 const videoItem = result.data.find((e) => e.type === "nowatermark_hd" || e.type === "nowatermark") || result.data[0];
 const caption = `✦ *TikTok Downloader*\n${LINE}\n${info(`▸ Durasi : ${durasi}\n`)}\n${LINE}\n${stat}`;
 await sendTikTokVideo(videoItem.url, caption, musicUrl);
 } else {
 const caption = `✦ *TikTok Downloader · Slide*\n${LINE}\n${info(`▸ Jumlah : ${result.data.length} foto\n`)}\n${LINE}\n${stat}`;
 await sendTikTokAlbum(result.data, caption);
 const buttons = audioButtons(musicUrl);
 if (buttons.length) {
 try { await relayInteractive(null, "✦ *Slide terkirim*\n▸ Tekan tombol di bawah untuk ambil musik.", buttons); }
 catch (e) { console.error("[tt] tombol music gagal:", e.message); }
 }
 }

 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } catch (e) {
 console.error("[tt] gagal:", e);
 await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return m.reply("Coba lagi nanti.");
 }
};

export default handler;
