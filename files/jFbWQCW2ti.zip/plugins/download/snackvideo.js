import axios from 'axios';

const pluginConfig = {
  name: 'snackvideo',
  category: 'download',
  command: ['snackvideo'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, raiden, text, troli } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (checkLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
if (!text) return Reply('Format: *.snackvideo <link>*\nContoh: .snackvideo https://snackvideo.com/xxxx');
await m.react('⏳'); addLimit(m.sender, isPremium, isVip);
try {
    const _svUrl = `${global.apialip}/download/snackvideo?apikey=${global.apikeyalip}&url=${encodeURIComponent(text)}`;
    const _svRes = await axios.get(_svUrl,{timeout:30000});
    const _svData = _svRes.data;
    if (!_svData.status||!_svData.result?.video) throw new Error('Gagal ambil video SnackVideo');
    const _svVid = await axios.get(_svData.result.video,{responseType:'arraybuffer',timeout:60000});
    await raiden.sendMessage(m.chat,{video:Buffer.from(_svVid.data),caption:`🍿 *${_svData.result.title||'SnackVideo'}*\n\n_Powered by ${botname}_`,mimetype:'video/mp4'},{ quoted: troli });
    await m.react('✅');
} catch(e) { await m.react('❌'); Reply('❌ Gagal download SnackVideo: '+e.message); }
};

export default handler;
