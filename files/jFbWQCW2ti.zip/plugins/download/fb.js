import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'fb',
  category: 'download',
  command: ['fb', 'facebook', 'fbdl'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    if (!text) {
        return Reply(
            `╭─❏ *Facebook Downloader*
│✧ Format : .fb [link]
│✧ Support : Video & Reels
╰──────────❏`
        )
    }
    
    if (!text.includes('facebook.com') && !text.includes('fb.watch')) {
        return Reply('❌ Link Facebook tidak valid!')
    }
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    try {
        const apiUrl = `https://api-cloud.my.id/downloader/facebook?url=${encodeURIComponent(text.trim())}`;
        
        const response = await axios.get(apiUrl, { timeout: 90000, validateStatus: () => true });
        const data = response.data;
        
        if (!data?.status || !data.result) {
            throw new Error(data?.error || data?.message || `Gagal mengambil data (HTTP ${response.status})`);
        }
        
        const result = data.result;
        const judul = result.title || result.caption || 'Facebook Video';
        const akun = result.fullname && ![result.title, result.caption].includes(result.fullname) ? result.fullname : (result.username || '-');
        
        const daftarVideo = (Array.isArray(result.video) ? result.video : [])
            .filter(v => v?.url)
            .sort((x, y) => (/hd|720|1080/i.test(y.quality || '') ? 1 : 0) - (/hd|720|1080/i.test(x.quality || '') ? 1 : 0));
        
        if (daftarVideo.length) {
            let videoBuffer = null;
            let quality = '';
            for (const v of daftarVideo) {
                try {
                    const videoResponse = await axios.get(v.url, { responseType: 'arraybuffer', timeout: 120000 });
                    videoBuffer = Buffer.from(videoResponse.data);
                    quality = v.quality || 'SD';
                    if (videoBuffer.length > 10000) break;
                    videoBuffer = null;
                } catch (e) {
                    console.error(`[FB] unduh kualitas ${v.quality} gagal:`, e.message);
                }
            }
            if (!videoBuffer) throw new Error('Video tidak bisa diunduh');
            
            const fileSizeMB = (videoBuffer.length / 1024 / 1024).toFixed(1);
            const caption = `╭─❏ *Facebook Downloader*
│✧ Judul : ${judul}
│✧ Akun : ${akun}
│✧ Kualitas : ${quality}
│✧ Ukuran : ${fileSizeMB} MB
╰──────────❏`;
            
            await raiden.sendMessage(m.chat, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                caption: caption
            }, { quoted: m });
        } else {
            const daftarGambar = (Array.isArray(result.image) ? result.image : []).filter(g => g?.url);
            if (!daftarGambar.length) throw new Error('Media tidak ditemukan');
            for (let i = 0; i < daftarGambar.length; i++) {
                await raiden.sendMessage(m.chat, {
                    image: { url: daftarGambar[i].url },
                    caption: i === 0 ? `╭─❏ *Facebook Downloader*
│✧ Judul : ${judul}
│✧ Akun : ${akun}
│✧ Foto : ${daftarGambar.length}
╰──────────❏` : undefined
                }, { quoted: m });
            }
        }
        
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[FB DOWNLOAD ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        
        let errorMsg = error.message || 'Gagal mendownload video Facebook';
        if (error.code === 'ECONNABORTED') {
            errorMsg = 'Timeout, coba lagi nanti';
        } else if (error.response?.status === 404) {
            errorMsg = 'Video tidak ditemukan atau link sudah expired';
        }
        
        Reply(
            `╭─❏ *Facebook Downloader* - Gagal
│✧ Error : ${errorMsg}
╰──────────❏`
        )
    }
};

export default handler;
