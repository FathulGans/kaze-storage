import __axios from 'axios';
import fs from 'fs';
import { ytdl2 } from '../../src/scraper/ytdl2.js';

const pluginConfig = {
  name: 'playget',
  category: 'download',
  command: ['playget'],
};

const MAX_AUDIO = 50 * 1024 * 1024;
const MAX_VIDEO = 80 * 1024 * 1024;

async function fetchMedia(axios, url, kind, quality, maxBytes) {
    try {
        const r = await ytdl2(url, { format: kind === 'audio' ? 'mp3' : quality });
        const res = await axios.get(r.download, {
            responseType: 'arraybuffer',
            timeout: 180000,
            maxContentLength: maxBytes,
            maxBodyLength: maxBytes,
            headers: r.headers || {}
        });
        const type = String(res.headers['content-type'] || '');
        if (/text\/html|application\/json/i.test(type)) throw new Error('Respons bukan file media');
        return { buffer: Buffer.from(res.data), filePath: null };
    } catch (e) {
        console.error('[PLAYGET] ytdl2 gagal, pakai yt-dlp:', e.message);
    }

    const { default: ytdlp } = await import('../../src/scraper/ytdlp.js');
    const result = kind === 'audio'
        ? await ytdlp.download(url, { mode: 'audio' })
        : await ytdlp.download(url, { mode: 'video', quality });
    return { buffer: fs.readFileSync(result.filePath), filePath: result.filePath };
}

const handler = async (m, ctx) => {
    let { Reply, isPremium, isVip, prefix, raiden, text } = ctx;
 if (!text) return;
 const axios = __axios;
 const MB = (await import('baileys-mbuilder')).default;
 const [action, index, quality] = text.split('|');
 const videos = global._playSearch?.[m.sender];

 if (!videos) return Reply("❌ Sesi pencarian kadaluarsa. Silakan cari lagi.");
 const target = videos[parseInt(index)];
 if (!target) return Reply("❌ Pilihan tidak valid. Silakan cari lagi.");

 if (action === 'select_q') {
 const qualities = ['1080p', '720p', '480p', '360p'];
 const qRows = qualities.map(q => ({
 title: `🎬 Resolusi ${q}`,
 description: `Download ${target.title.substring(0, 20)}...`,
 id: `${prefix}playget dl_video|${index}|${q}`
 }));

 const btnQ = new MB.ButtonV2(raiden)
 .setTitle(target.title)
 .setSubtitle(`Pilih Kualitas Video`)
 .setBody(`📽️ *Judul:* ${target.title}\n⏱️ *Durasi:* ${target.timestamp}\n\n_Silakan pilih resolusi video yang lu mau di bawah!_`)
 .addRawButton({
 buttonId: 'btn_q_list',
 buttonText: { displayText: '📽️ Pilih Resolusi' },
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: 'Kualitas Tersedia',
 sections: [{ title: 'OPSI RESOLUSI MP4', rows: qRows }]
 })
 }
 });

 return await btnQ.send(m.chat, { quoted: m });
 }

 await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

 let filePath = null;

 try {
 if (action === 'dl_audio') {
 const media = await fetchMedia(axios, target.url, 'audio', null, MAX_AUDIO);
 filePath = media.filePath;

 if (media.buffer.length > MAX_AUDIO) return Reply("❌ File terlalu besar (di atas 50MB)");

 await raiden.sendMessage(m.chat, {
 audio: media.buffer,
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: target.title,
 body: target.author.name,
 thumbnailUrl: target.thumbnail,
 sourceUrl: target.url,
 mediaType: 1
 }
 }
 }, { quoted: m });
 } else if (action === 'dl_video') {
 const q = String(quality || '360p').replace('p', '');
 const media = await fetchMedia(axios, target.url, 'video', q, MAX_VIDEO);
 filePath = media.filePath;

 if (media.buffer.length > MAX_VIDEO) return Reply("❌ File terlalu besar (di atas 80MB), coba resolusi lebih rendah");

 await raiden.sendMessage(m.chat, {
 video: media.buffer,
 mimetype: 'video/mp4',
 caption: `✅ *Success Download*\n\n📌 *Judul:* ${target.title}\n🎞️ *Quality:* ${q}p\n🎧 *Bot:* ${global.botname}`
 }, { quoted: m });
 } else {
 return Reply("❌ Aksi tidak dikenal.");
 }
 await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 addLimit(m.sender, isPremium, isVip);
 } catch (e) {
 console.error('[PLAYGET ERROR]', e);
 await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply("❌ Gagal mendownload media. Server mungkin sedang sibuk.");
 } finally {
 if (filePath) fs.unlink(filePath, () => {});
 }
};

export default handler;