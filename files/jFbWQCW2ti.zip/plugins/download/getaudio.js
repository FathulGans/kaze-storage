import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'getaudio',
  category: 'download',
  command: ['getaudio', 'gtmp3'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, raiden, text } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


  try {
    if (!text) return Reply(example("https://example.com"))
    raiden.sendMessage(m.chat, { audio: { url: text }, mimetype: 'audio/mpeg' }, { quoted: m })
  } catch (e) {
    console.error(e)
    Reply(`Gagal download audio:\n${e}`)
  }
};

export default handler;
