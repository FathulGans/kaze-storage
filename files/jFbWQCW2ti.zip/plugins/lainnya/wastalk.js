const pluginConfig = {
  name: 'wastalk',
  category: 'lainnya',
  command: ['wastalk'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi)
    let input = text.replace(/[^0-9]/g, '')
    if (!input) return Reply(`Masukkan nomor yang ingin di-stalk!\nContoh: ${prefix + command} 6285741137312`)    
    let target = input.startsWith('0') ? '62' + input.slice(1) : input
    let jid = target + '@s.whatsapp.net'    
    try {
        let pp, bio, status        
        try {
            pp = await raiden.profilePictureUrl(jid, 'image')
        } catch {
            pp = global.defaultPP
        }
        try {
            status = await raiden.fetchStatus(jid)
            bio = status.status || 'Kosong'
            let date = new Date(status.setAt)
            var tgl = `${date.toLocaleDateString('id-ID')} jam ${date.toLocaleTimeString('id-ID')}`
        } catch {
            bio = 'Privat / Tidak Ada'
            var tgl = 'Tidak diketahui'
        }
        let teks = `✨ *WHATSAPP STALKER*\n\n`
        teks += `👤 *User:* @${target}\n`
        teks += `📝 *Bio:* ${bio}\n`
        teks += `📅 *Update Bio:* ${tgl}\n`
        teks += `🔗 *Wa Link:* https://wa.me/${target}`
        await raiden.sendMessage(m.chat, { 
            image: { url: pp }, 
            caption: teks,
            mentions: [jid]
        }, { quoted: m })
    } catch (err) {
        Reply(`❌ Gagal mengambil data. Pastikan nomor terdaftar di WhatsApp.`)
    }
};

export default handler;
