import { fetchJson } from '../../library/function.js';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'animewatch',
  category: 'lainnya',
  command: ['animewatch'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, text } = ctx;
 if (!isRegistered(m.sender) && !isVip) return Reply(`Anda belum terdaftar.`);
 if (!text) return Reply(`Contoh: .animewatch naruto 215\nAtau pakai ID episode: .animewatch naruto-episode-215`);
 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);

 await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

 try {
 const [idArg, numArg] = text.trim().split(/\s+/);
 let epId = idArg;

 if (numArg) {
 const det = await fetchJson(`https://api-cloud.my.id/anime/animeplay?action=detail&id=${encodeURIComponent(idArg)}`);
 const eps = (det && det.result && det.result.episodes) || [];
 if (!det.status || !eps.length) return Reply(`Anime dengan ID "${idArg}" tidak ditemukan.`);
 const want = String(parseInt(numArg, 10));
 const ep = eps.find(e => String(parseInt(e.number, 10)) === want);
 if (!ep) return Reply(`Episode ${numArg} tidak ditemukan. Episode terbaru: ${eps[0].number}`);
 epId = ep.id;
 }

 const res = await fetchJson(`https://api-cloud.my.id/anime/animeplay?action=watch&id=${encodeURIComponent(epId)}`);
 const streams = ((res && res.result && res.result.streams) || []).filter(s => s.streaming_url);
 if (!res.status || streams.length === 0)
 return Reply(`Link streaming belum tersedia untuk episode ini.`);

 let teks = `*Link Streaming*\n(${epId})\n\n`;
 streams.forEach((s, i) => {
 teks += `*${i + 1}. ${s.quality}*\n${s.streaming_url}\n\n`;
 });
 teks += `Link berupa halaman player, buka lewat browser.`;
 Reply(teks);

 } catch (e) {
 console.error(e);
 Reply("Terjadi kesalahan saat mengambil link streaming.");
 }
};

export default handler;
