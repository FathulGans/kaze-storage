import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'ceklinkgc',
  category: 'lainnya',
  command: ['ceklinkgc'],
};

const handler = async (m, ctx) => {
    let { Reply, budy, command, daftar, isVip, prefix, raiden, text } = ctx;
if (!m.isGroup) return
if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
if (checkLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);
 const iidgc = budy.match('@g.us')
 if(!iidgc)return Reply(`Sertakan IdGroup Dengan Benar\nExample : ${prefix + command} 120.......@g.us`)
 try{
 const gc = "https://chat.whatsapp.com/" + await raiden.groupInviteCode(text)
await Reply(`${gc}`)
 }catch(e){
 Reply('IdGroup Tidak Valid!!')
 }
};

export default handler;
