const pluginConfig = {
  name: 'sapaanbot',
  category: 'lainnya',
};

export function jalankan(ctx) {
    const { m, raiden, Reply, botUptime, troli } = ctx;
    const botname = global.botname;

    if (m.text.toLowerCase() === "bot") {
        Reply(
`*${botname}* telah aktif ✅
> Online: ${botUptime()}`
        );
    }

    if ([global.botname.toLowerCase(), global.botname2.toLowerCase(), "raiden"].includes(m.text.toLowerCase())) {
        raiden.sendMessage(m.chat, { sticker: { url: './source/media/sticker/bot.webp' } }, { quoted: troli });
    }
}

export default { modulPendukung: true };
