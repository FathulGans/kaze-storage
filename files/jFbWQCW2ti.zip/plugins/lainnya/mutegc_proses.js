const pluginConfig = {
  name: 'mutegc_proses',
  category: 'lainnya',
  command: ['mutegc_proses'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, saveMainGroups, text } = ctx;
    if (!isVip) return Reply(mess.vip);
    if (!text) return Reply('❌ ID grup tidak valid!');
    
    const groupId = text;
    
    try {
        const groupMetadata = await raiden.groupMetadata(groupId);
        
        if (!global.db.groups[groupId]) {
            global.db.groups[groupId] = {};
        }
        
        const isMuted = global.db.groups[groupId].mute === true;
        
        if (isMuted) {
            global.db.groups[groupId].mute = false;
            await Reply(`✅ Berhasil meng-unmute grup:\n*${groupMetadata.subject}*`);
        } else {
            global.db.groups[groupId].mute = true;
            await Reply(`✅ Berhasil memute grup:\n*${groupMetadata.subject}*`);
        }
        
        saveMainGroups();
        
    } catch (error) {
        console.error('[MUTEGC PROSES ERROR]', error);
        Reply(mess.error);
    }
};

export default handler;
