const pluginConfig = {
  name: 'publiccooldown',
  category: 'lainnya',
  command: ['publiccooldown'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, text } = ctx;
    if (!isVip) return Reply(mess.vip);

    if (!global.db.settings) global.db.settings = {};
    const currentDetik = Number(global.db.settings.publicCooldown) || 0;
    const inputDetik = text?.trim();

    if (!inputDetik) {
        return Reply(
            `⏱️ *Cooldown Default Publik*\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `Status saat ini : *${currentDetik > 0 ? currentDetik + ' detik (ON)' : 'OFF (nonaktif)'}*\n\n` +
            `Cara pakai:\n` +
            `▸ ${prefix}publiccooldown <detik> — atur default publik, contoh: ${prefix}publiccooldown 3\n` +
            `▸ ${prefix}publiccooldown 0 — nonaktifkan default publik\n\n` +
            `ℹ️ Nilai ini dipakai oleh SEMUA grup yang belum punya override sendiri (lihat ${prefix}cooldown di dalam grup).`
        );
    }

    const detik = Number(inputDetik);
    if (!Number.isFinite(detik) || isNaN(detik) || detik < 0) {
        return Reply(`❌ Argumen gak valid!\nContoh: ${prefix}publiccooldown 3\nContoh: ${prefix}publiccooldown 0 (nonaktifkan)`);
    }

    if (detik === currentDetik) {
        return Reply(`ℹ️ Cooldown default publik sudah *${detik > 0 ? detik + ' detik' : 'OFF'}* dari sebelumnya, gak ada yang berubah.`);
    }

    global.db.settings.publicCooldown = detik;

    Reply(
        detik > 0
            ? `✅ *Cooldown default publik diubah jadi ${detik} detik.*\n\nBerlaku untuk semua grup yang belum punya override sendiri (${prefix}cooldown <detik> di grup masing-masing).`
            : `✅ *Cooldown default publik dinonaktifkan (OFF).*\n\nGrup tanpa override sendiri sekarang gak kena cooldown sama sekali.`
    );
};

export default handler;
