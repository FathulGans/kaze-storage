import fs from 'fs';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 's',
  category: 'lainnya',
  command: ['s', 'sticker', 'stiker'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, mime, qmsg, raiden } = ctx;
 if (!isRegistered(m.sender) && !isVip)
 return daftar(global.mess.verifikasi);
 if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
 return Reply(global.mess.limit);
 if (!/image|video/gi.test(mime)) 
 return Reply(example("dengan kirim media"));
 if (/video/gi.test(mime) && qmsg.seconds > 15) 
 return Reply("❌ Durasi video maksimal 15 detik!");
 await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 var image = await raiden.downloadAndSaveMediaMessage(qmsg);
 await raiden.sendAsSticker(m.chat, image, m, { packname: global.packname });
 await fs.unlinkSync(image);
 await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
};

export default handler;
