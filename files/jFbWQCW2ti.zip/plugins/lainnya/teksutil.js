const pluginConfig = {
  name: 'teksutil',
  category: 'lainnya',
};

function capital(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function splitLongMessage(text, maxLength = 4000) {
    const parts = [];
    let currentPart = '';
    const lines = text.split('\n');
    
    for (const line of lines) {
        if ((currentPart + line + '\n').length > maxLength) {
            parts.push(currentPart);
            currentPart = line + '\n';
        } else {
            currentPart += line + '\n';
        }
    }
    
    if (currentPart) {
        parts.push(currentPart);
    }
    
    return parts;
}

export { capital, splitLongMessage };

export default { modulPendukung: true };
