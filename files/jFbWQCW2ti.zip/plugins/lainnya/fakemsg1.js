const pluginConfig = {
  name: 'fakemsg1',
  category: 'lainnya',
  command: ['fakemsg1', 'fmsg1'],
};

const handler = async (m, ctx) => {
    let { Reply, command, isVip, prefix, raiden, text } = ctx;
 if (!isVip) return Reply(global.mess.vip);
 if (!m.quoted) return Reply('Reply pesan yang ingin diproses.');
 if (!text) return Reply(`❌ Masukkan teks penggantinya.\nContoh: ${prefix}${command} Halo dunia`);

 const stanzaId = typeof m.quoted.id === 'string' ? m.quoted.id : m.quoted.key?.id;
 if (!stanzaId) return Reply('Gagal ambil ID pesan yang di-reply.');

 const toId = (r) => {
 if (typeof r === 'string') return r;
 if (r && typeof r === 'object') return r.id || r.key?.id || null;
 return null;
 };

 try {
 const rawTempId = await raiden.relayMessage(
 m.chat,
 {
 extendedTextMessage: {
 text: '',
 contextInfo: { isGroupStatus: true },
 },
 },
 {}
 );
 const tempId = toId(rawTempId);
 if (!tempId) throw new Error('Gagal ambil ID pesan sementara (relayMessage tidak balikin string ID)');

 const rawTempId2 = await raiden.relayMessage(
 m.chat,
 {
 protocolMessage: {
 key: { remoteJid: m.chat, fromMe: true, id: tempId },
 type: 14,
 editedMessage: {
 extendedTextMessage: {
 text: String(text),
 contextInfo: { isGroupStatus: false },
 },
 },
 },
 },
 { messageId: stanzaId }
 );
 const tempId2 = toId(rawTempId2) || tempId;

 await new Promise(r => setTimeout(r, 100));

 await Promise.allSettled([
 raiden.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: tempId, fromMe: true } }),
 raiden.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: tempId2, fromMe: true } }),
 ]);
 } catch (e) {
 console.error('[FAKEMSG1]', e);
 Reply('Error: ' + (e?.message || e));
 }
};

export default handler;
