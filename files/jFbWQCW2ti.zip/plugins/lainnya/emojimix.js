import axios from 'axios';

const pluginConfig = {
  name: 'emojimix',
  category: 'lainnya',
  command: ['emojimix'],
};

const handler = async (m, ctx) => {
    let { Reply, example, raiden, text } = ctx;
 if (!text) return Reply(example(".emojimix 😊+😘\n\nAtau: .emojimix 😊 😘"));

 let emojis = text.includes("+") ? text.split("+") : text.split(" ");
 emojis = emojis.map(e => e.trim()).filter(e => e);

 if (emojis.length < 2) return Reply("❌ Masukin 2 emoji ya! Contoh: .emojimix 😊+😘");

 const [emoji1, emoji2] = emojis;

 try {
 const url = `https://api.theresav.eu/api/maker/emojimix?emoji1=${encodeURIComponent(emoji1)}&emoji2=${encodeURIComponent(emoji2)}`;

 const res = await axios.get(url, {
 timeout: 15000,
 responseType: 'arraybuffer',
 validateStatus: () => true,
 headers: { 'x-apikey': 'TayRooAPIkey' }
 });
 const contentType = res.headers['content-type'] || '';

 let buffer;

 if (contentType.includes('application/json')) {
 const json = JSON.parse(Buffer.from(res.data).toString('utf-8'));
 const imgUrl = json?.result?.url || json?.result || json?.url || null;
 if (!imgUrl || typeof imgUrl !== 'string') return Reply(`❌ Gagal! Response:\n${JSON.stringify(json).substring(0, 200)}`);
 const imgRes = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 15000 });
 buffer = Buffer.from(imgRes.data);
 } else {
 buffer = Buffer.from(res.data);
 }

 if (buffer.length < 100) return Reply('❌ Gambar tidak valid dari API');

 const { Sticker, StickerTypes } = (await import('wa-sticker-formatter')).default;
 const sticker = new Sticker(buffer, {
 pack: global.packname || 'Emojimix',
 author: global.author || 'Bot',
 type: StickerTypes.FULL,
 quality: 100
 });

 const stickerBuffer = await sticker.toBuffer();
 await raiden.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });

 } catch (e) {
 console.error('[emojimix] error:', e?.message || e);
 Reply(`❌ Terjadi error!\n\n${e.message || e}`);
 }
};

export default handler;
