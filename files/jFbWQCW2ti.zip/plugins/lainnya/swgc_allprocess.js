import { sleep } from '../../library/function.js';

const pluginConfig = {
  name: 'swgc_allprocess',
  category: 'lainnya',
  command: ['swgc_allprocess'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, swgcIsiStatus } = ctx;
    if (!isVip) return Reply(mess.vip)

    const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
    if (!data) return Reply('❌ Tidak ada media tersimpan. Gunakan .swgcall dulu!');
    
    try {
        await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const allGroups = await raiden.groupFetchAllParticipating();
        const groupList = Object.values(allGroups);
        
        if (groupList.length === 0) return Reply('❌ Bot tidak ada di grup manapun');
        
        let success = 0;
        
        const { sendGroupStatus } = (await import('../../src/lib/group_status.js')).default;
        const isiStatus = swgcIsiStatus(data);
        let gagalKirim = 0;
        for (const group of groupList) {
            try {
                await sendGroupStatus(raiden, group.id, isiStatus);
                success++;
            } catch (e) { gagalKirim++; console.error('[SWGC ALL]', group.id, e.message); }
            await sleep(4000);
        }
        
        delete global.swgcBuffer[m.sender];
        Reply(`✅ Status terkirim ke ${success} grup` + (gagalKirim ? `, ${gagalKirim} gagal.` : '.'));
        
    } catch (e) {
        console.error('[SWGC ALLPROCESS ERROR]', e);
        Reply(mess.error);
    }
};

export default handler;
