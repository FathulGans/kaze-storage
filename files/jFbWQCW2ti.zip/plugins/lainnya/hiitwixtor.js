import __axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'hiitwixtor',
  category: 'lainnya',
  command: ['hiitwixtor', 'twixtor'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, text } = ctx;
 if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


  if (!text) return Reply('Contoh: hiitwixtor Gojo');
  const axios = __axios;
  const cheerio = (await import('cheerio'));
  const search = async (query) => {
    try {
      const url = `https://hiitwixtor.com/?s=${encodeURIComponent(query)}`;
      const { data } = await axios.get(url);
      const $ = cheerio.load(data);
      let result = [];
      $('.post-details').each((_, el) => {
        const title = $(el).find('h2').text().trim();
        const link = $(el).find('h2>a').attr('href');
        const image = $('a.post-thumb').find('img').attr('src');
        const coment = $(el).find('span.meta-comment.tie-icon.meta-item.fa-before').text().trim();
        const fire = $(el).find('span.meta-views.meta-item.very-hot').text().trim();
        result.push({ title, link, image, coment, fire });
      });
      return result;
    } catch (e) {
      return [];
    }
  };
  let res = await search(text);
  if (!res.length) return Reply('Tidak ditemukan.');
  let teks = `*Hasil pencarian Hiitwixtor: ${text}*\n\n`;
  for (let i = 0; i < res.length; i++) {
    teks += `*${i + 1}. ${res[i].title}*\n`;
    teks += `🔥 Views: ${res[i].fire} | 💬 Comments: ${res[i].coment}\n`;
    teks += `${res[i].link}\n\n`;
  }
  Reply(teks);
};

export default handler;
