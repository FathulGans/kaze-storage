import __fs from 'fs';
import path from 'path';

const pluginConfig = {
  name: 'ganticase',
  category: 'lainnya',
  command: ['ganticase', 'replacecase'],
};

const handler = async (m, ctx) => {
    let { Reply, __filename, command, isVip, prefix, text } = ctx;
  if (!isVip) return Reply(mess.vip);
  const fs = __fs;
  const cf = (await import('../../src/lib/casefile.js')).default;

  const bantuan = `Cara pakai:\n1. Reply kode case lengkap: ${prefix + command} [nama_case]\n2. Atau tempel langsung: ${prefix + command} [nama_case] case 'nama': { ... } break\n\nNama case otomatis diambil dari kode kalau tidak ditulis.`;

  const rapikan = (s) => (s || '').replace(/\r\n/g, '\n').trim();
  const cariAwalKode = (s) => {
    const mt = /(^|\s)case\s+['"`‘’“”]/.exec(s);
    return mt ? mt.index + mt[1].length : -1;
  };

  let namaInput = '';
  let newCode = '';
  const teksInput = rapikan(text);
  const teksQuoted = rapikan(m.quoted && (m.quoted.text || m.quoted.body || m.quoted.caption));

  if (teksQuoted && cariAwalKode(teksQuoted) === 0) {
    newCode = teksQuoted;
    namaInput = teksInput.split(/\s+/)[0] || '';
  } else if (teksInput) {
    const pos = cariAwalKode(teksInput);
    if (pos < 0) return Reply(`Kode case tidak ditemukan di pesan.\n\n${bantuan}`);
    namaInput = teksInput.slice(0, pos).trim().split(/\s+/)[0] || '';
    newCode = teksInput.slice(pos).trim();
  }
  if (!newCode) return Reply(bantuan);
  if (namaInput.startsWith(prefix)) namaInput = namaInput.slice(prefix.length);

  const labelKode = [...newCode.split('\n')[0].matchAll(/case\s+['"`‘’“”]([^'"`‘’“”]+)['"`‘’“”]\s*:/g)].map(v => v[1]);
  if (!labelKode.length) return Reply('Baris pertama kode harus berupa label case, contoh: case \'nama\': {');
  const target = namaInput || labelKode[0];
  if (!labelKode.includes(target)) return Reply(`Nama case di kode (${labelKode.join(', ')}) tidak sama dengan target *${target}*.`);

  let catatan = '';
  if (!/\bbreak\s*;?\s*$/.test(newCode)) {
    newCode += '\nbreak';
    catatan = '\nCatatan: break ditambahkan otomatis karena kode tidak diakhiri break.';
  }

  const file = __filename;
  const lines = fs.readFileSync(file, 'utf8').split('\n');
  const esc = target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const reTarget = new RegExp('^case\\b[^\\n]*?[\'"`]' + esc + '[\'"`]\\s*:');
  const reLabelSaja = /^\s*case\s+['"`][^'"`]+['"`]\s*:\s*$/;
  const reLabelAwal = /^(case\s+['"`]|default\s*:)/;

  const cocok = [];
  lines.forEach((l, i) => { if (reTarget.test(l)) cocok.push(i); });
  if (!cocok.length) return Reply(`Case *${target}* tidak ditemukan di ${path.basename(file)}. Ganti case hanya untuk case yang sudah ada.`);
  if (cocok.length > 1) return Reply(`Case *${target}* muncul ${cocok.length}x (baris ${cocok.map(v => v + 1).join(', ')}). Rapikan duplikatnya dulu.`);

  let start = cocok[0];
  while (start > 0 && reLabelSaja.test(lines[start - 1])) start--;

  let j = cocok[0];
  while (j < lines.length && reLabelSaja.test(lines[j])) j++;
  let next = j + 1;
  while (next < lines.length && !reLabelAwal.test(lines[next])) next++;

  let end = next;
  for (let k = next - 1; k > start; k--) {
    const t = lines[k].trim();
    if (!t || t.startsWith('//') || t.startsWith('/*') || t.startsWith('*')) continue;
    if (/\bbreak\b/.test(t)) end = k + 1;
    break;
  }
  while (end > start + 1 && !lines[end - 1].trim()) end--;

  const hasil = lines.slice(0, start).concat(newCode.split('\n'), lines.slice(end)).join('\n');

  const cekSintaks = (src) => cf.validate(src, file);
  let final = hasil;
  let err = cekSintaks(final);
  if (err) {
    const kodeLurus = newCode.replace(/[‘’]/g, "'").replace(/[“”]/g, '"');
    const coba = lines.slice(0, start).concat(kodeLurus.split('\n'), lines.slice(end)).join('\n');
    if (!cekSintaks(coba)) { final = coba; err = null; catatan += '\nCatatan: kutip melengkung diubah jadi kutip lurus.'; }
  }
  if (err) return Reply(`Kode ditolak, file TIDAK diubah.\nSyntax error: ${err.message}`);

  fs.copyFileSync(file, file + '.bak');
  fs.writeFileSync(file, final);
  console.log('[GANTICASE]', { by: m.sender, case: target, barisLama: end - start, barisBaru: newCode.split('\n').length });
  Reply(`Berhasil mengganti case *${target}*\nBaris lama: ${end - start}, baris baru: ${newCode.split('\n').length}\nBackup: ${path.basename(file)}.bak${catatan}\n\nBot akan reload otomatis.`);
};

export default handler;
