const pluginConfig = {
  name: 'ttaudio',
  category: 'lainnya',
  command: ['ttaudio'],
};

const handler = async (m, ctx) => {
    let { example, raiden, text } = ctx;
 if (!text) return m.reply(example("url"));

 try {
 await raiden.sendMessage(m.chat, {
 audio: { url: text.trim() },
 mimetype: 'audio/mp4',
 ptt: false
 }, { quoted: m });
 } catch (e) {
 console.log("Error TikTok Audio:", e);
 return m.reply("❌ Gagal mengambil audio, coba lagi.");
 }
};

export default handler;
