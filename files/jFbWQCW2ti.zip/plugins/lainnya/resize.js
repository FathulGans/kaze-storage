import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'resize',
  category: 'lainnya',
  command: ['resize'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, safeErr, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    const type = m.quoted ? (m.quoted.mtype || Object.keys(m.quoted.message || {})[0] || '') : ''
    if (!m.quoted || !/image/i.test(type)) return Reply(`📌 reply gambarnya terus ketik lebarnya saja atau lebar & tinggi\ncontoh: *${prefix + command} 500* atau *${prefix + command} 500 500*`)        
    let [w, h] = text.split(' ').map(v => parseInt(v))
    if (!w) return Reply(`📌 kasih ukurannya\ncontoh: *${prefix + command} 800*`)        
    try {
        await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })
        const { sharp } = await import('../../src/lib/sharpkit.js');
        const media = await m.quoted.download()
        const buffer = await sharp(media)
            .resize(w, h || null, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
            .toBuffer()            
       await raiden.sendMessage(m.chat, { 
            image: buffer, 
            caption: `✅ *SUKSES RESIZE*\n\n📏 *Dimensi:* ${w} x ${h || 'Auto'}\n📍 *Status:* Berhasil diubah ukurannya` 
        }, { quoted: m })                
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
    } catch (err) {
        console.error(err)
        Reply(`❌ gagal resize: ${safeErr(err)}`)
    }
};

export default handler;
