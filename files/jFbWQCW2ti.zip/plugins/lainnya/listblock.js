const pluginConfig = {
  name: 'listblock',
  category: 'lainnya',
  command: ['listblock'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, troli } = ctx;
    if (!isVip) return Reply(global.mess.vip);
    try {
        const blocklist = await raiden.fetchBlocklist();
        if (blocklist.length === 0) return Reply("tidak ada nomor yang sedang diblokir");
        let teks = `*Daftar Nomor Diblokir*\n\nTotal: ${blocklist.length} user\n\n`;
        for (let jid of blocklist) {
            teks += `• @${jid.split('@')[0]}\n`;
        }
        raiden.sendMessage(m.chat, { 
            text: teks, 
            mentions: blocklist 
        }, { quoted: troli });
    } catch (err) {
        console.error(err);
        Reply("gagal mengambil daftar blokir");
    }
};

export default handler;
