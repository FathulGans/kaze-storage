const pluginConfig = {
  name: 'setdeskgc',
  category: 'lainnya',
  command: ['setdeskgc'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, raiden, text } = ctx;
    if (!m.isGroup) return Reply('❌ Command ini hanya untuk grup!');
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    if (!m.isBotAdmin) return Reply('❌ Bot harus admin untuk ubah deskripsi grup!'); 
    if (!text) return Reply('❌ Masukkan deskripsi grup baru!\nContoh: .setdeskgc Welcome to our group.'); 
    try {
        Reply('⏳ Mengubah deskripsi grup...');        
        await raiden.groupUpdateDescription(m.chat, text);
        Reply('✅ Deskripsi grup berhasil diperbarui!');
    } catch (error) {
        console.error('Set Deskripsi Error:', error);    
        if (error.message.includes('not-authorized')) {
            Reply('❌ Gagal. Pastikan bot adalah admin dan fitur edit info grup diizinkan.');
        } else {
            Reply('❌ Gagal mengubah deskripsi grup. Silakan coba lagi nanti.');
        }
    }
};

export default handler;
