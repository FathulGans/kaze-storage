import fs from 'fs';

const pluginConfig = {
  name: 'blacklist',
  category: 'owner',
  command: ['blacklist'],
};

const handler = async (m, ctx) => {
    let { Reply, areJidsSameUser, args, blacklist, blacklistPath, isVip } = ctx;
    if (!isVip) return Reply(mess.vip)

  let target = null

  if (m.isGroup) {
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      const mentionedId = m.mentionedJid[0]
      if (mentionedId.endsWith('@lid')) {
        const participant = m.metadata.participants.find(x => x.id === mentionedId)
        target = participant ? participant.jid : globalThis.lidKeNomor(mentionedId)
      } else {
        target = mentionedId
      }
    } else if (m.quoted) {
      target = m.quoted.sender
    } else if (args[0]) {
      const number = args[0].replace(/[^0-9]/g, '')
      if (number.length >= 10) {
        target = number + '@s.whatsapp.net'
      }
    }
  } else {
    if (m.quoted) {
      target = m.quoted.sender
    } else if (args[0]) {
      const number = args[0].replace(/[^0-9]/g, '')
      if (number.length >= 10) {
        target = number + '@s.whatsapp.net'
      }
    }
  }

  if (!target) return Reply('🚫 Tag user, reply chat, atau ketik nomor yang mau di-blacklist.\nContoh: .blacklist @user\n.blacklist 628123456789')

  if (blacklist.some(b => areJidsSameUser(b, target))) {
    return Reply(`❗ User @${target.split('@')[0]} sudah di blacklist.`, [target])
  }

  blacklist.push(target)
  fs.writeFileSync(blacklistPath, JSON.stringify(blacklist, null, 2))
  
  Reply(`✅ Berhasil *BLACKLIST* user @${target.split('@')[0]}`, [target])
};

export default handler;
