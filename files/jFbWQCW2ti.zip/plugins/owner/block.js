const pluginConfig = {
  name: 'block',
  category: 'owner',
  command: ["blokir", "blok"],
};

let handler = async (m, { raiden, isVip, example, Reply, text }) => {
if (!isVip) return Reply(global.mess.vip)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await raiden.updateBlockStatus(mem, "block");
if (m.isGroup) raiden.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}

export default handler