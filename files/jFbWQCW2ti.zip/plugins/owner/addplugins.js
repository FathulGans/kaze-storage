import fs from 'fs';
const CP_URL = new URL('../../src/lib/findplugin.js', import.meta.url);
let cp;
async function muatCp() {
    const st = fs.statSync(CP_URL);
    cp = (await import(`${CP_URL.href}?v=${Math.trunc(st.mtimeMs)}-${st.size}`)).default;
    return cp;
}

const pluginConfig = {
  name: 'addplugins',
  category: 'owner',
  command: ['addplugins', 'addplugin', 'addp', 'addplug'],
};

const daftarKategori = () => cp.daftarKategori().map(k => `▸ ${k}`).join('\n');

let handler = async (m, { isVip, text, Reply, example }) => {
    await muatCp();
    if (!isVip) return Reply(global.mess.vip);
    const contoh = example('tools/namaplugin (reply kode plugin / dokumen .js)');
    if (!m.quoted) return Reply(contoh);

    let kode, catatan;
    try { ({ kode, catatan } = cp.periksaKode(await cp.ambilKode(m))); }
    catch (e) { return Reply(`❌ Kode ditolak, plugin TIDAK ditambah.\n${e.message}`); }

    const semuaKategori = cp.daftarKategori();
    const cfg = cp.configDariTeks(kode);
    let { kategori, nama } = cp.uraiNama(text);
    if (!kategori && semuaKategori.includes(nama)) { kategori = nama; nama = ''; }
    nama = nama || cfg.name || cp.namaDokumen(m);
    kategori = kategori || cfg.category;
    if (!nama) return Reply(contoh);
    if (!kategori) {
        return Reply(`Kategori belum ada. Tulis di perintah, contoh: *.addplugin tools/${nama}*\n` +
            `atau isi *category* di pluginConfig pada kode.\n\nKategori yang ada:\n${daftarKategori()}`);
    }
    if (!semuaKategori.includes(kategori)) return Reply(`Kategori *${kategori}* tidak ada.\n\nKategori yang ada:\n${daftarKategori()}`);
    const file = cp.pathAman(kategori, nama);
    if (!file) return Reply('Nama plugin hanya boleh huruf, angka, titik, - dan _.');

    const pasang = cp.pasangConfig(kode, nama, kategori);
    if (pasang.aksi === 'gagal') return Reply('❌ pluginConfig tidak bisa dipasang: `export default` harus nama variabel (mis. `export default handler`).');
    kode = pasang.kode;
    catatan += cp.catatanConfig(pasang, nama, kategori);

    const semua = cp.semuaPlugin();
    const samaNama = semua.filter(p => p.nama === nama || p.namaKode === nama);
    if (samaNama.length) {
        return Reply(`Nama *${nama}* sudah dipakai: ${samaNama.map(cp.label).join(', ')}\n` +
            `Pakai nama lain, atau ganti isinya dengan *.gantiplugin ${cp.label(samaNama[0])}*`);
    }
    const bentrok = cp.cekBentrok(cp.perintahDariTeks(kode), semua);
    if (bentrok.length) return Reply(`❌ Perintah bentrok, plugin TIDAK ditambah:\n${bentrok.map(b => `▸ ${b}`).join('\n')}`);

    cp.tulisAtomik(file, kode);
    let hasil;
    try { hasil = await cp.cobaMuat(file); }
    catch (e) {
        fs.rmSync(file, { force: true });
        return Reply(`❌ Plugin gagal dimuat, file dibatalkan.\n${e && e.message ? e.message : e}`);
    }

    const diCase = hasil.perintah.filter(c => cp.cariDiCase(c));
    if (diCase.length) catatan += `\n⚠️ ${cp.daftarPerintah(diCase)} juga ada di raidensystem.js (case). Versi plugin ini yang dipakai.`;
    console.log('[ADDPLUGIN]', { oleh: m.sender, file: `${kategori}/${nama}.js` });
    return Reply(`✅ Berhasil menambah plugin *${kategori}/${nama}*\n` +
        `Perintah: ${cp.daftarPerintah(hasil.perintah)}${catatan}${hasil.peringatan}\n\nPlugin langsung aktif.`);
};

export default handler;
