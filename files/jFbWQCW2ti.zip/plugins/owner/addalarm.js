const pluginConfig = {
  name: 'addalarm',
  category: 'owner',
  command: ['addalarm'],
};

const handler = async (m, ctx) => {
    let { Reply, botNumber, daftar, isVip, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi)
    if (!m.isGroup) return Reply('❌ fitur ini cuma bisa di grup ya')
    if (!m.isAdmin && !isVip) return Reply('❌ cuma admin yang bisa atur alarm')
    if (!text) return Reply('📌 *format: .addalarm pesan|jam*\ncontoh: .addalarm bangun woi|06.00')
    let [pesanAlarm, jamInput] = text.split('|')
    if (!pesanAlarm || !jamInput) return Reply('❌ format salah, pastiin pake pemisah | ya')
    pesanAlarm = pesanAlarm.trim()
    jamInput = jamInput.trim().replace('.', ':')
    if (!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(jamInput)) {
        return Reply('❌ format jam salah, gunain HH:MM atau HH.MM (contoh 06.00)')
    }
    const { loadAlarm, saveAlarm, scheduleAlarm } = (await import('../../src/lib/alarm.js')).default
    let db = loadAlarm()
    if (!Array.isArray(db[m.chat])) db[m.chat] = []
    const newAlarm = {
        time: jamInput,
        message: pesanAlarm,
        setBy: m.sender,
        bot: String(botNumber || '').split('@')[0]
    }
    db[m.chat].push(newAlarm)
    saveAlarm(db)
    const [j, n] = jamInput.split(':').map(Number)
    const alarmId = db[m.chat].length - 1
    scheduleAlarm(raiden, m.chat, j, n, pesanAlarm, alarmId)
    Reply(`✅ alarm "${pesanAlarm}" berhasil dipasang buat jam ${jamInput} WIB`)
};

export default handler;
