import fs from 'fs';

const pluginConfig = {
  name: 'cekcapjulukantime',
  category: 'owner',
  command: ['cekcapjulukantime', 'infocapjulukan', 'cekcaptime'],
};

const handler = async (m, ctx) => {
    let { Reply, prefix } = ctx;
    if (!m.isGroup) return Reply(global.mess.group);

    const julukanConfigPath = './library/database/julukan_config.json';
    let julukanCfg = {};
    try {
        if (fs.existsSync(julukanConfigPath)) {
            julukanCfg = JSON.parse(fs.readFileSync(julukanConfigPath, 'utf8'));
        }
    } catch (e) { console.error(e); }

    const cooldownMin = julukanCfg[m.chat]?.cooldown ?? 30;
    const isDefault   = !julukanCfg[m.chat]?.cooldown;

    let labelWaktu;
    if (cooldownMin >= 60 && cooldownMin % 60 === 0) {
        labelWaktu = `${cooldownMin / 60} jam`;
    } else if (cooldownMin >= 60) {
        const jam = Math.floor(cooldownMin / 60);
        const sisa = cooldownMin % 60;
        labelWaktu = `${jam} jam ${sisa} menit`;
    } else {
        labelWaktu = `${cooldownMin} menit`;
    }

    Reply(
        `╭─❏ *⏱️ INFO CAP JULUKAN*\n│\n` +
        `│ 🏠 *Grup:* ${m.metadata?.subject || 'Grup ini'}\n│\n` +
        `│ ⏱️ *Cooldown:* ${labelWaktu}${isDefault ? ' (default)' : ''}\n│\n` +
        `│ Bot menyapa member ber-julukan\n│ setiap *${labelWaktu}* sekali.\n│\n` +
        (isDefault
            ? `│ 💡 Ubah dengan:\n│ ${prefix}setcapjulukantime <menit>\n│\n`
            : ''
        ) +
        `╰──────────❏`
    );
    return;
};

export default handler;
