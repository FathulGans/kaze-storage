const pluginConfig = {
  name: 'autotyping',
  category: 'owner',
  command: ['autotyping'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, prefix, text } = ctx;
    if (!isVip) return Reply(mess.vip);

    const action = text?.toLowerCase().trim();

    if (!action) {
        const statusNow = db.settings.autotyping ? '✅ ON' : '❌ OFF';
        return Reply(
            `🤖 *Auto Typing Mode*\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `Status saat ini: *${statusNow}*\n\n` +
            `Cara pakai:\n` +
            `▸ ${prefix}autotyping on  — aktifkan\n` +
            `▸ ${prefix}autotyping off — nonaktifkan\n\n` +
            `ℹ️ Kalau ON, setiap pesan yang bot kirim\n` +
            `bakal muncul efek "mengetik..." dulu\n` +
            `dengan durasi sesuai panjang pesan.`
        );
    }

    if (action !== 'on' && action !== 'off') {
        return Reply(`❌ Argumen gak valid!\nContoh: ${prefix}autotyping on\nContoh: ${prefix}autotyping off`);
    }

    const newState = (action === 'on');
    global.db.settings.autotyping = newState;
    (await import('../../library/botsettings.js')).default.saveBotSettings({ autotyping: newState });

    Reply(
        `${newState ? '✅' : '❌'} *Auto Typing Mode ${newState ? 'diaktifkan' : 'dinonaktifkan'}*\n\n` +
        `${newState
            ? `Sekarang bot bakal tampilkan indikator "mengetik..."\nsebelum kirim pesan (kayak manusia beneran 🧑‍💻)`
            : `Sekarang bot langsung kirim pesan\ntanpa efek mengetik.`
        }`
    );
};

export default handler;
