import fs from 'fs';
import path from 'path';

const pluginConfig = {
  name: 'cd',
  category: 'owner',
  command: ['cd', 'cekfolder', 'foldercek'],
};

const handler = async (m, ctx) => {
    let { Reply, command, isVip, prefix, raiden, safeErr, text } = ctx;
    if (!isVip) return Reply(mess.vip)
    if (!text) return Reply(`📌 ketik nama folder yang mau dicek bang\ncontoh: *${prefix + command} library/database*\nketik *.* atau *root* buat cek folder utama`)    
    try {
        const folderTarget = text.trim()
        const targetDir = (folderTarget === '.' || folderTarget === 'root') ? process.cwd() : path.join(process.cwd(), folderTarget)
        if (!fs.existsSync(targetDir)) return Reply(`❌ folder *${folderTarget}* gak ketemu bang, coba cek lagi tulisannya`)        
        const stats = fs.statSync(targetDir)
        if (!stats.isDirectory()) return Reply(`❌ itu bukan folder bang, tapi file pake command ${prefix}getfile aja kalo mau ambil file nya`)
        await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })
        const files = fs.readdirSync(targetDir)
        if (files.length === 0) return Reply(`📂 folder *${folderTarget}* kosong bang, gak ada isinya sama sekali, coba cek folder lain`)
        let teksList = `🚀 *CEK FOLDER BERHASIL*\n\n`
        teksList += `📁 *folder:* ${folderTarget === '.' || folderTarget === 'root' ? 'Root (Utama)' : folderTarget}\n`
        teksList += `📊 *total:* ${files.length} item\n\n`
        files.forEach((file, i) => {
            const fStat = fs.statSync(path.join(targetDir, file))
            const icon = fStat.isDirectory() ? '📁' : '📄'
            teksList += `${i + 1}. ${icon} \`${file}\`\n`
        })
        teksList += `\n📍 *path:* ${targetDir}`
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
        Reply(teksList)
    } catch (err) {
        console.error(err)
        Reply(`❌ gagal cek folder: ${safeErr(err)}`)
    }
};

export default handler;
