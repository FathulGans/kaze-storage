import __path from 'path';
import fs from 'fs';

const pluginConfig = {
  name: 'addsticker',
  category: 'owner',
  command: ['addsticker'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip, text } = ctx;
    if (!isVip) return Reply(mess.vip);
    if (!m.quoted) return Reply("❌ Balas stiker yang ingin disimpan!");
    const quotedType = m.quoted.mtype || Object.keys(m.quoted.message)[0];
    if (!/sticker/i.test(quotedType)) return Reply("❌ Itu bukan stiker! Tipe terdeteksi: " + quotedType);
    if (!text) return Reply("❌ Masukkan nama stiker!\nContoh: .addsticker archio");
    const path = __path;
    const fileName = text.replace(/[^a-zA-Z0-9]/g, ''); 
    const filePath = path.join('./source/media/sticker', `${fileName}.webp`);
    try {
        const buffer = await m.quoted.download();
        if (!buffer) return Reply("❌ Gagal mengambil data stiker.");
        fs.writeFileSync(filePath, buffer);
        Reply(`✅ Berhasil menyimpan stiker dengan nama: ${fileName}`);
    } catch (e) {
        console.error(e);
        Reply("❌ Terjadi kesalahan saat memproses stiker.");
    }
};

export default handler;
