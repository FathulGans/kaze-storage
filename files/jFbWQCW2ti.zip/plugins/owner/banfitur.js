const pluginConfig = {
  name: 'banfitur',
  category: 'owner',
  command: ['banfitur'],
};

const handler = async (m, ctx) => {
    let { Reply, command, isVip, prefix, text } = ctx;
    if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di dalam Grup!");
    if (!isVip && !m.isAdmin) return Reply(mess.admin);
    if (!text) return Reply(`Contoh:\n${prefix + command} list\n${prefix + command} all menu, nsfw\n${prefix + command} grup menu, nsfw`);
    const args = text.trim().split(/ +/);
    const action = args[0].toLowerCase();
    if (action === 'list') {
        let teks = `*DAFTAR FITUR TERBLOKIR*\n\n*🌐 Global:*\n`;
        if (global.db.data.bannedFeatures.length > 0) {
            global.db.data.bannedFeatures.forEach((v, i) => teks += `${i + 1}. ${v}\n`);
        } else {
            teks += `- Tidak ada\n`;
        }
        teks += `\n*👥 Grup Ini:*\n`;
        let groupBanned = global.db.data.groups[m.chat]?.bannedFeatures || [];
        if (groupBanned.length > 0) {
            groupBanned.forEach((v, i) => teks += `${i + 1}. ${v}\n`);
        } else {
            teks += `- Tidak ada\n`;
        }
        return Reply(teks);
    }
    if (action !== 'all' && action !== 'grup') {
        return Reply(`⚠️ Tipe tidak valid! Gunakan 'all', 'grup', atau 'list'`);
    }
    const rawFeatures = args.slice(1).join(" ");
    if (!rawFeatures) return Reply(`Masukkan nama fiturnya! Bisa dipisah dengan koma.\nContoh: ${prefix + command} ${action} nsfw, judol`);
    const features = rawFeatures.split(',').map(v => v.trim().toLowerCase()).filter(v => v !== "");
    let success = [];
    let skipped = [];
    if (action === 'all') {
        if (!isVip) return Reply(mess.vip);
        features.forEach(feat => {
            if (global.db.data.bannedFeatures.includes(feat)) {
                skipped.push(feat);
            } else {
                global.db.data.bannedFeatures.push(feat);
                success.push(feat);
            }
        });
    } else if (action === 'grup') {
        if (!global.db.data.groups[m.chat]) global.db.data.groups[m.chat] = {};
        if (!global.db.data.groups[m.chat].bannedFeatures) global.db.data.groups[m.chat].bannedFeatures = [];
        features.forEach(feat => {
            if (global.db.data.groups[m.chat].bannedFeatures.includes(feat)) {
                skipped.push(feat);
            } else {
                global.db.data.groups[m.chat].bannedFeatures.push(feat);
                success.push(feat);
            }
        });
    }
    let response = `*HASIL BAN FITUR (${action.toUpperCase()})*\n\n`;
    if (success.length > 0) response += `✅ Berhasil: ${success.join(', ')}\n`;
    if (skipped.length > 0) response += `⚠️ Sudah Ada: ${skipped.join(', ')}\n`;
    return Reply(response);
};

export default handler;
