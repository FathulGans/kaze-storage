import __fs from 'fs';

const pluginConfig = {
  name: 'autoreactsw',
  category: 'owner',
  command: ['autoreactsw'],
};

const handler = async (m, ctx) => {
    let { Reply, example, isVip, text } = ctx;
    if (!isVip) return Reply(mess.vip);
    if (!text) return Reply(example("on/off"));
    
    let arg = text.toLowerCase();
    if (arg !== 'on' && arg !== 'off') return Reply(example("on/off"));

    const fs = __fs;
    const dbDir = './library/database';
    const dbPath = `${dbDir}/autoreact.json`;
    
    if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
    
    let isAutoReact = arg === 'on';
    fs.writeFileSync(dbPath, JSON.stringify({ status: isAutoReact }, null, 2));
    
    Reply(`✅ Auto Read & React SW ${isAutoReact ? 'AKTIF' : 'MATI'}`);
};

export default handler;
