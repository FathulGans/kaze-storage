const pluginConfig = {
  name: 'addlimitall',
  category: 'owner',
  command: ['addlimitall'],
};

const handler = async (m, ctx) => {
    let { Reply, atomicWriteJSON, getWIBTime, isVip, limitBonusPath, safeReadJSON, text, userDBPath } = ctx;
  if (!isVip) return Reply(mess.vip);

  if (!text || isNaN(text)) {
    return Reply(`❌ Masukkan jumlah limit yang ingin ditambahkan untuk semua user.\n\nContoh: .addlimitall 50`);
  }
  const amount = parseInt(text);
  if (amount <= 0) return Reply('❌ Jumlah limit harus lebih dari 0.');

  m.reply(`⏳ Memproses penambahan *${amount}* limit untuk semua user terdaftar...`);

  const userDB = safeReadJSON(userDBPath, []); 
  const bonusDB = safeReadJSON(limitBonusPath, {});
  
  if (userDB.length === 0) {
    return Reply('⚠️ Tidak ada user terdaftar di database.');
  }

  const today = getWIBTime().toISOString().split('T')[0];
  let successCount = 0;

  for (const user of userDB) {
    const jid = user.jid;
    if (!jid) continue;

    if (!bonusDB[jid] || bonusDB[jid].date !== today) {
      bonusDB[jid] = { bonus: 0, date: today };
    }
    
    bonusDB[jid].bonus += amount;
    successCount++;
  }

  atomicWriteJSON(limitBonusPath, bonusDB);

  Reply(`✅ Berhasil menambahkan *${amount}* limit bonus untuk *${successCount}* user terdaftar.\n\nBonus ini hanya berlaku untuk hari ini.`);
};

export default handler;
