const pluginConfig = {
  name: 'addrespon',
  category: 'owner',
  command: ['addrespon'],
};

const handler = async (m, ctx) => {
    let { Reply, detectQuotedType, downloadQuotedMedia, example, getContentType, getResponList, isVip, setResponList, text } = ctx;
if (!isVip) return Reply(global.mess.vip);
if (!text) return Reply(example("Reply pesan (teks/foto/video/gif/audio/voice note/stiker/dokumen/zip/apk/pdf/kontak/lokasi/poll) dengan caption .addrespon anak haram"))
if (!m.quoted) return Reply("❌ Reply pesan yang ingin dijadikan respon!")

const cmd = text.toLowerCase().trim()
let responList = getResponList(m.chat)
let res = responList.find(e => e.cmd == cmd)
if (res) return m.reply(`Cmd *${cmd}* sudah ada di chat ini!`)

let quotedMsg = m.quoted
let msgType = detectQuotedType(quotedMsg)
let rawMessage = quotedMsg.message || {}

if ((msgType == 'viewOnceMessage' || msgType == 'viewOnceMessageV2' || msgType == 'viewOnceMessageV2Extension') && rawMessage[msgType]?.message) {
    rawMessage = rawMessage[msgType].message
    msgType = getContentType(rawMessage) || msgType
}
if (msgType == 'documentWithCaptionMessage' && rawMessage.documentWithCaptionMessage?.message?.documentMessage) {
    rawMessage = { documentMessage: rawMessage.documentWithCaptionMessage.message.documentMessage }
    msgType = 'documentMessage'
}

let mediaData = null
let mediaMimetype = null
let mediaFilename = null
let textRespon = null
let captionRespon = null
let isGif = false
let isPtt = false
let contactsRespon = null
let locationRespon = null
let pollRespon = null

if (rawMessage.imageMessage?.caption) captionRespon = rawMessage.imageMessage.caption
else if (rawMessage.videoMessage?.caption) captionRespon = rawMessage.videoMessage.caption
else if (rawMessage.documentMessage?.caption) captionRespon = rawMessage.documentMessage.caption

if (msgType == 'imageMessage') {
    mediaData = (await downloadQuotedMedia(rawMessage.imageMessage, 'image')).toString('base64')
    mediaMimetype = rawMessage.imageMessage.mimetype
    mediaFilename = rawMessage.imageMessage.filename || 'image.jpg'
}
else if (msgType == 'videoMessage') {
    mediaData = (await downloadQuotedMedia(rawMessage.videoMessage, 'video')).toString('base64')
    mediaMimetype = rawMessage.videoMessage.mimetype
    mediaFilename = rawMessage.videoMessage.filename || 'video.mp4'
    isGif = !!rawMessage.videoMessage.gifPlayback
}
else if (msgType == 'audioMessage') {
    isPtt = !!rawMessage.audioMessage.ptt
    mediaData = (await downloadQuotedMedia(rawMessage.audioMessage, 'audio')).toString('base64')
    mediaMimetype = rawMessage.audioMessage.mimetype
    mediaFilename = rawMessage.audioMessage.filename || (isPtt ? 'voicenote.ogg' : 'audio.mp3')
}
else if (msgType == 'stickerMessage') {
    mediaData = (await downloadQuotedMedia(rawMessage.stickerMessage, 'sticker')).toString('base64')
    mediaMimetype = rawMessage.stickerMessage.mimetype || 'image/webp'
    mediaFilename = 'sticker.webp'
}
else if (msgType == 'documentMessage') {
    mediaData = (await downloadQuotedMedia(rawMessage.documentMessage, 'document')).toString('base64')
    mediaMimetype = rawMessage.documentMessage.mimetype
    mediaFilename = rawMessage.documentMessage.filename || 'file'
}
else if (msgType == 'contactMessage') {
    contactsRespon = [{ displayName: rawMessage.contactMessage.displayName || 'Contact', vcard: rawMessage.contactMessage.vcard }]
}
else if (msgType == 'contactsArrayMessage') {
    contactsRespon = (rawMessage.contactsArrayMessage.contacts || []).map(c => ({ displayName: c.displayName || 'Contact', vcard: c.vcard }))
    if (contactsRespon.length < 1) return Reply('❌ Pesan kontak ini kosong')
}
else if (msgType == 'locationMessage' || msgType == 'liveLocationMessage') {
    const loc = rawMessage[msgType]
    locationRespon = {
        degreesLatitude: loc.degreesLatitude,
        degreesLongitude: loc.degreesLongitude,
        name: loc.name || '',
        address: loc.address || ''
    }
}
else if (msgType && msgType.startsWith('pollCreationMessage')) {
    const poll = rawMessage[msgType]
    pollRespon = {
        name: poll.name || '',
        values: (poll.options || []).map(o => o.optionName),
        selectableCount: poll.selectableOptionsCount || 1
    }
}
else if (msgType == 'conversation' || msgType == 'extendedTextMessage') {
    textRespon = quotedMsg.text || rawMessage.conversation || rawMessage.extendedTextMessage?.text || ''
}
else {
    return Reply(`❌ Tipe pesan *${msgType || 'tidak dikenal'}* belum didukung untuk .addrespon`)
}

let obj = {
    cmd: cmd,
    type: msgType,
    media: mediaData,
    mimetype: mediaMimetype,
    filename: mediaFilename,
    text: textRespon,
    caption: captionRespon,
    isGif: isGif,
    isPtt: isPtt,
    contacts: contactsRespon,
    location: locationRespon,
    poll: pollRespon,
    createdAt: Date.now()
}

responList.push(obj)
setResponList(m.chat, responList)
m.reply(`✅ Berhasil menambah respon untuk *${cmd}* khusus di chat ini`)
};

export default handler;
