import fs from 'fs';

const pluginConfig = {
  name: 'addgold',
  category: 'owner',
  command: ['addgold'],
};

const handler = async (m, ctx) => {
    let { Reply, args, isSenderPartner, isVip } = ctx;
 if (!isVip && !isSenderPartner) return Reply('❌ Khusus Owner!');
 let amount = parseInt(args.find(arg => /^[0-9]+$/.test(arg)));
 if (!amount) return Reply("Masukkan jumlah gold!");

 let users = (m.mentionedJid && m.mentionedJid.length > 0) ? m.mentionedJid.map(id => {
 if (id.endsWith('@lid') && m.metadata?.participants) {
 let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
 return p ? p.jid : id
 }
 return id
 }) : (m.quoted ? [m.quoted.sender] : [m.sender]);

 const rpgPath = './library/database/rpg.json';
 let rpgData = JSON.parse(fs.readFileSync(rpgPath, 'utf8'));

 for (let target of users) {
 if (!rpgData.players || !rpgData.players[target]) {
 Reply(`❌ @${target.split('@')[0]} belum .rpgstart`, [target]);
 continue;
 }
 rpgData.players[target].gold += amount;
 Reply(`✅ Berhasil menambah *${amount.toLocaleString()}* Gold untuk @${target.split('@')[0]}`, [target]);
 }
 fs.writeFileSync(rpgPath, JSON.stringify(rpgData, null, 2));
};

export default handler;
