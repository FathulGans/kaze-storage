import fs from 'fs';

const pluginConfig = {
  name: 'addpremgc',
  category: 'owner',
  command: ['addpremgc', 'addpremgrup', 'addpremiumgc'],
};

const handler = async (m, ctx) => {
    let { Reply, args, botNumber, dbPrem, example, isVip, prem } = ctx;
    if (!m.isGroup) return Reply(mess.group);
    if (!isVip) return Reply(mess.vip);
    
    if (!args[0]) return Reply(example("30"));
    
    let days = Number(args[0]);
    if (isNaN(days) || days <= 0) return Reply('❌ Masukkan jumlah hari yang valid! (minimal 1)');
    if (days > 365) return Reply('❌ Maksimal 365 hari!');
    
    const participants = m.metadata.participants || [];
    const ownerJid = global.creator + '@s.whatsapp.net';
    
    let memberJids = [];
    for (let p of participants) {
        let jid = p.jid;
        if (!jid && p.id) {
            jid = p.id.endsWith('@lid') ? globalThis.lidKeNomor(p.id) : p.id;
        }
        
        if (jid && jid !== botNumber && jid !== ownerJid && (jid.endsWith('@s.whatsapp.net') || jid.includes('@'))) {
            memberJids.push(jid);
        }
    }
    
    if (memberJids.length === 0) return Reply('❌ Tidak ada member yang bisa ditambahkan premium!');
    
    const ms = days * 24 * 60 * 60 * 1000;
    const expired = Date.now() + ms;
    
    let addedCount = 0, existingCount = 0;
    
    for (let jid of memberJids) {
        const user = prem.find(u => u.jid === jid);
        if (user) {
            if (user.expired > Date.now()) {
                user.expired += ms;
                existingCount++;
            } else {
                user.expired = expired;
                addedCount++;
            }
            user.addedBy = m.sender;
            user.addedAt = Date.now();
            user.addedByGroup = m.chat;
        } else {
            prem.push({ jid, expired, addedBy: m.sender, addedAt: Date.now(), addedByGroup: m.chat });
            addedCount++;
        }
    }
    
    fs.writeFileSync(dbPrem, JSON.stringify(prem, null, 2));
    
    Reply(`*✅ Premium grup berhasil ditambahkan!*
Semua member grup sekarang memiliki akses premium selama ${days} hari!`);
    return;
};

export default handler;
