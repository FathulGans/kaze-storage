import fs from 'fs';
const CP_URL = new URL('../../src/lib/findplugin.js', import.meta.url);
let cp;
async function muatCp() {
    const st = fs.statSync(CP_URL);
    cp = (await import(`${CP_URL.href}?v=${Math.trunc(st.mtimeMs)}-${st.size}`)).default;
    return cp;
}

const pluginConfig = {
  name: 'cekplugin',
  category: 'owner',
  command: ['cekplugin', 'cekfitur', 'carifitur'],
};

const MAKS_HASIL = 40;

function punyaCommand(file) {
    let teks = '';
    try { teks = fs.readFileSync(file, 'utf8'); } catch (_) { return false; }
    return /pluginConfig\s*=\s*\{[^}]*\bcommand\s*:/s.test(teks) || /\bhandler\.command\s*=/.test(teks);
}

async function petaFitur() {
    const semua = cp.semuaPlugin();
    const peta = [];
    const tanpaPerintah = [];
    for (const p of semua) {
        let perintah = p.perintah;
        if (!perintah.length && punyaCommand(p.file)) {
            try {
                const mod = await import(cp.urlPlugin(p.file));
                const c = mod?.pluginConfig?.command ?? mod?.default?.command;
                perintah = (Array.isArray(c) ? c : c ? [c] : []).filter(x => typeof x === 'string').map(x => x.toLowerCase());
            } catch (_) { perintah = []; }
        }
        if (!perintah.length) { tanpaPerintah.push(p.rel); continue; }
        for (const cmd of perintah) peta.push({ perintah: cmd, rel: p.rel, alias: perintah.filter(x => x !== cmd) });
    }
    return { semua, peta, tanpaPerintah };
}

const baris = (f) => `• *.${f.perintah}* || *${f.rel}*` + (f.alias.length ? `\n   alias: ${f.alias.map(a => '.' + a).join(', ')}` : '');

let handler = async (m, { isVip, text, Reply, raiden }) => {
    await muatCp();
    if (!isVip) return Reply(global.mess.vip);

    const { semua, peta, tanpaPerintah } = await petaFitur();
    const kunci = String(text || '').trim().toLowerCase().replace(/^[.#!/]/, '').replace(/\.js$/, '');

    const perFile = new Map();
    for (const f of peta) {
        if (!perFile.has(f.perintah)) perFile.set(f.perintah, new Set());
        perFile.get(f.perintah).add(f.rel);
    }
    const bentrok = [...perFile].filter(([, set]) => set.size > 1);

    if (!kunci) {
        return Reply(
            `🔎 *Cek Plugin*\n\n` +
            `▸ File plugin: ${semua.length}\n` +
            `▸ Fitur (perintah): ${perFile.size}\n` +
            `▸ Plugin tanpa perintah (modul pendukung): ${tanpaPerintah.length}\n` +
            (bentrok.length
                ? `\n⚠️ *${bentrok.length} perintah dipakai lebih dari satu file:*\n` +
                  bentrok.slice(0, 15).map(([c, set]) => `• *.${c}* || ${[...set].map(r => `*${r}*`).join(', ')}`).join('\n') +
                  (bentrok.length > 15 ? `\n…dan ${bentrok.length - 15} lagi (lihat *.cekplugin semua*)` : '') + '\n'
                : '\n✅ Tidak ada perintah yang bentrok.\n') +
            `\nCari fitur: *.cekplugin hd*\nDaftar lengkap (.txt): *.cekplugin semua*`
        );
    }

    if (kunci === 'semua' || kunci === 'all') {
        const isi = [
            `DAFTAR FITUR || PLUGIN  (${perFile.size} fitur, ${semua.length} file)`,
            `Dibuat: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Makassar' })}`,
            '',
            ...[...peta].sort((a, b) => a.perintah.localeCompare(b.perintah) || a.rel.localeCompare(b.rel))
                .map(f => `.${f.perintah} || ${f.rel}`),
            '',
            bentrok.length ? `PERINTAH BENTROK (${bentrok.length}):` : 'PERINTAH BENTROK: tidak ada',
            ...bentrok.map(([c, set]) => `.${c} || ${[...set].join(', ')}`),
            '',
            `PLUGIN TANPA PERINTAH (${tanpaPerintah.length}):`,
            ...tanpaPerintah
        ].join('\n');
        return raiden.sendMessage(m.chat, {
            document: Buffer.from(isi, 'utf8'),
            fileName: 'daftar-fitur-plugin.txt',
            mimetype: 'text/plain',
            caption: `📄 ${perFile.size} fitur dari ${semua.length} file plugin`
        }, { quoted: m });
    }

    const tanpaJs = (rel) => rel.replace(/\.js$/, '');
    const persis = peta.filter(f => f.perintah === kunci || tanpaJs(f.rel) === kunci || tanpaJs(f.rel).split('/').pop() === kunci);
    const persisUnik = [];
    const sudah = new Set();
    for (const f of persis.sort((a, b) => (b.perintah === kunci) - (a.perintah === kunci))) {
        if (sudah.has(f.rel)) continue;
        sudah.add(f.rel);
        persisUnik.push(f);
    }
    const mirip = [];
    const sudahMirip = new Set(sudah);
    for (const f of peta) {
        if (sudahMirip.has(f.rel)) continue;
        if (f.perintah.includes(kunci) || f.rel.toLowerCase().includes(kunci)) {
            sudahMirip.add(f.rel);
            mirip.push(f);
        }
    }

    if (!persisUnik.length && !mirip.length) {
        return Reply(`❌ Tidak ada fitur / plugin yang cocok dengan *${kunci}*.\n\nCoba kata lain, atau lihat semua: *.cekplugin semua*`);
    }

    let pesan = `🔎 *Cek Plugin: ${kunci}*\n_Nama fitur || Nama plugin_\n`;
    if (persisUnik.length) pesan += `\n✅ *Persis*\n${persisUnik.map(baris).join('\n')}\n`;
    if (mirip.length) {
        pesan += `\n🔸 *Mirip* (${mirip.length})\n${mirip.slice(0, MAKS_HASIL).map(baris).join('\n')}`;
        if (mirip.length > MAKS_HASIL) pesan += `\n…dan ${mirip.length - MAKS_HASIL} lagi. Persempit kata kuncinya.`;
    }
    return Reply(pesan.trim());
};

export default handler;