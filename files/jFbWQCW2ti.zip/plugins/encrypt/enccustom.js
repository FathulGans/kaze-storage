import fs from 'fs';
import path from 'path';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'enccustom',
  category: 'encrypt',
  command: ['enccustom', 'encryptcustom', 'encrypt-custom', 'customenc', 'custom-encrypt', 'enc-custom', 'enccustomjs', 'encryptcustomjs', 'customjsen', 'jscustomenc'],
};

const handler = async (m, ctx) => {
    let { Reply, __dirname, body, command, daftar, downloadContentFromMessage, isVip, prefix, raiden, safeErr } = ctx;
    if (!m.quoted) return Reply('Kutip file .js untuk dienkripsi!')
    
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    
    try {
        const args = (body || '').trim().split(/\s+/)
        const customName = (args[0] || '').replace(/[^a-zA-Z0-9_]/g, '')
        if (!customName) return Reply(`Format: ${prefix}${command} <nama>\nContoh: ${prefix}${command} myid`)

        const fileName = m.quoted?.msg?.fileName || m.quoted?.fileName || ''
        if (!fileName.endsWith('.js')) return Reply('Kutip file `.js` untuk dienkripsi!')

        const idGen = () => {
            const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            let suf = ''
            for (let i = 0; i < Math.floor(Math.random() * 3) + 2; i++) suf += chars[Math.floor(Math.random() * chars.length)]
            return `${customName}_${suf}`
        }

        const getCustomObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: idGen,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.75,
            shuffle: true,
            duplicateLiteralsRemoval: true,
            deadCode: true,
            calculator: true,
            opaquePredicates: true,
            lock: {
                selfDefending: true,
                antiDebug: true,
                integrity: true,
                tamperProtection: true
            }
        })

        let mediaBuffer
        if (m.quoted.msg?.documentMessage) {
            const media = await downloadContentFromMessage(m.quoted.msg.documentMessage, 'document')
            let buffer = Buffer.from([])
            for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
            mediaBuffer = buffer
        } else if (m.quoted?.message?.documentMessage) {
            const media = await downloadContentFromMessage(m.quoted.message.documentMessage, 'document')
            let buffer = Buffer.from([])
            for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
            mediaBuffer = buffer
        } else {
            return Reply('Tidak bisa mendapatkan file dari pesan yang dikutip')
        }

        const raw = mediaBuffer.toString('utf8')

        try {
            new Function(raw)
        } catch (e) {
            return Reply(`❌ File JS tidak valid:\n${e.message}`)
        }

        await raiden.sendMessage(m.chat, { react: { text: "⚙️", key: m.key } })
        
        await Reply('⏳ *Memproses custom encrypt...*')

        const JsConfuser = (await import('js-confuser')).default
        const obf = await JsConfuser.obfuscate(raw, getCustomObf())
        const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

        const outName = `custom-encrypted-${customName}-${Date.now()}.js`
        const outPath = path.join(__dirname, outName)
        fs.writeFileSync(outPath, code, 'utf8')

        const fileBuffer = fs.readFileSync(outPath)
        await raiden.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: `✅ *Custom encrypted (${customName})!*`
        }, {
            quoted: m
        })

        try {
            fs.unlinkSync(outPath)
        } catch (e) { console.error(e); }
    } catch (err) {
        console.error(err)
        Reply(`❌ Terjadi kesalahan: ${safeErr(err)}`)
    }
};

export default handler;
