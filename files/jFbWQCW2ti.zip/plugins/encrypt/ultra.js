const pluginConfig = {
  name: 'ultra',
  category: 'encrypt',
  command: ['ultra'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, text } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
if (!text) return Reply('Format: *.ultra <teks>*\nFungsi: ROT13 + Reverse + Base64 triple combo.');
const _r13 = s=>s.replace(/[a-zA-Z]/g,c=>String.fromCharCode(c.charCodeAt(0)+(c.toLowerCase()<'n'?13:-13)));
const _u1=_r13(text), _u2=_u1.split('').reverse().join(''), _u3=Buffer.from(_u2,'utf8').toString('base64');
Reply(`⚡ *ULTRA ENCODE*\n\n📝 Original: ${text}\n🔄 ROT13: ${_u1}\n🔃 Reversed: ${_u2}\n🔒 Base64:\n${_u3}`);
};

export default handler;
