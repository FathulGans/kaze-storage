const pluginConfig = {
  name: 'siu',
  category: 'encrypt',
  command: ['siu'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, text } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
if (!text) return Reply('Format: *.siu <teks>*\nFungsi: Teks bold estetik Ronaldo style.');
const _sm = {'a':'𝐚','b':'𝐛','c':'𝐜','d':'𝐝','e':'𝐞','f':'𝐟','g':'𝐠','h':'𝐡','i':'𝐢','j':'𝐣','k':'𝐤','l':'𝐥','m':'𝐦','n':'𝐧','o':'𝐨','p':'𝐩','q':'𝐪','r':'𝐫','s':'𝐬','t':'𝐭','u':'𝐮','v':'𝐯','w':'𝐰','x':'𝐱','y':'𝐲','z':'𝐳','A':'𝐀','B':'𝐁','C':'𝐂','D':'𝐃','E':'𝐄','F':'𝐅','G':'𝐆','H':'𝐇','I':'𝐈','J':'𝐉','K':'𝐊','L':'𝐋','M':'𝐌','N':'𝐍','O':'𝐎','P':'𝐏','Q':'𝐐','R':'𝐑','S':'𝐒','T':'𝐓','U':'𝐔','V':'𝐕','W':'𝐖','X':'𝐗','Y':'𝐘','Z':'𝐙'};
Reply(`✨ *SIU! STYLE*\n\n📝 Original: ${text}\n\n🎨 Result:\n${text.split('').map(c=>_sm[c]||c).join('')}`);
};

export default handler;
