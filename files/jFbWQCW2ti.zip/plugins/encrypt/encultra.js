import fs from 'fs';
import path from 'path';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'encultra',
  category: 'encrypt',
  command: ['encultra', 'encryptultra', 'encrypt-ultra', 'ultraenc', 'ultra-encrypt', 'enc-ultra', 'encultrajs', 'jsultraenc', 'ultrajsen'],
};

const handler = async (m, ctx) => {
    let { Reply, __dirname, daftar, downloadContentFromMessage, isVip, raiden, safeErr } = ctx;
    if (!m.quoted) return Reply('Kutip pesan dokumen!')
    
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    
    try {
        const fileName = m.quoted?.msg?.fileName || m.quoted?.fileName || ''
        if (!fileName.endsWith('.js')) return Reply('Kutip file `.js` untuk dienkripsi!')

        const genUltra = () => {
            const chars = 'abcdefghijklmnopqrstuvwxyz'
            const nums = '0123456789'
            return 'z' + nums[Math.floor(Math.random() * nums.length)] + chars[Math.floor(Math.random() * chars.length)] + Math.random().toString(36).slice(2, 6)
        }

        const getUltraObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: genUltra,
            stringCompression: true,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.9,
            flatten: true,
            shuffle: true,
            rgf: true,
            deadCode: true,
            opaquePredicates: true,
            dispatcher: true,
            lock: {
                selfDefending: true,
                antiDebug: true,
                integrity: true,
                tamperProtection: true
            }
        })

        let mediaBuffer
        if (m.quoted.msg?.documentMessage) {
            const media = await downloadContentFromMessage(m.quoted.msg.documentMessage, 'document')
            let buffer = Buffer.from([])
            for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
            mediaBuffer = buffer
        } else if (m.quoted?.message?.documentMessage) {
            const media = await downloadContentFromMessage(m.quoted.message.documentMessage, 'document')
            let buffer = Buffer.from([])
            for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
            mediaBuffer = buffer
        } else {
            return Reply('Tidak bisa mendapatkan file dari pesan yang dikutip')
        }

        const raw = mediaBuffer.toString('utf8')

        try {
            new Function(raw)
        } catch (e) {
            return Reply(`❌ File JS tidak valid:\n${e.message}`)
        }

        await raiden.sendMessage(m.chat, { react: { text: "🚀", key: m.key } })
        
        await Reply('⏳ *Memproses ultra encrypt...*')

        const JsConfuser = (await import('js-confuser')).default
        const obf = await JsConfuser.obfuscate(raw, getUltraObf())
        const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

        const outName = `ultra-encrypted-${Date.now()}.js`
        const outPath = path.join(__dirname, outName)
        fs.writeFileSync(outPath, code, 'utf8')

        const fileBuffer = fs.readFileSync(outPath)
        await raiden.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: '✅ *Hardened Ultra encrypted!* — SATURN 🔥'
        }, {
            quoted: m
        })

        try {
            fs.unlinkSync(outPath)
        } catch (e) { console.error(e); }
    } catch (err) {
        console.error(err)
        Reply(`❌ Terjadi kesalahan: ${safeErr(err)}`)
    }
};

export default handler;
