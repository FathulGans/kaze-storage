import fs from 'fs';
import path from 'path';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'encsiu',
  category: 'encrypt',
  command: ['encsiu', 'encryptsiu', 'encrypt-siu', 'siuenc', 'siu-encrypt', 'enc-siu', 'encsiujs', 'jssiuenc', 'siujsen'],
};

const handler = async (m, ctx) => {
    let { Reply, __dirname, daftar, downloadContentFromMessage, isVip, raiden, safeErr } = ctx;
    if (!m.quoted) return Reply('Kutip pesan dokumen!')
    
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    
    try {
        const fileName = m.quoted?.msg?.fileName || m.quoted?.fileName || ''
        if (!fileName.endsWith('.js')) return Reply('Kutip file `.js` untuk dienkripsi!')

        const genSiu = () => {
            const abc = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            let r = ''
            for (let i = 0; i < 6; i++) r += abc[Math.floor(Math.random() * abc.length)]
            return `CalceKarik和SiuSiu${r}`
        }

        const getSiuObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: genSiu,
            stringCompression: true,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.95,
            flatten: true,
            shuffle: true,
            duplicateLiteralsRemoval: true,
            deadCode: true,
            calculator: true,
            opaquePredicates: true,
            lock: {
                selfDefending: true,
                antiDebug: true,
                integrity: true,
                tamperProtection: true
            }
        })

        let mediaBuffer
        if (m.quoted.msg?.documentMessage) {
            const media = await downloadContentFromMessage(m.quoted.msg.documentMessage, 'document')
            let buffer = Buffer.from([])
            for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
            mediaBuffer = buffer
        } else if (m.quoted?.message?.documentMessage) {
            const media = await downloadContentFromMessage(m.quoted.message.documentMessage, 'document')
            let buffer = Buffer.from([])
            for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
            mediaBuffer = buffer
        } else {
            return Reply('Tidak bisa mendapatkan file dari pesan yang dikutip')
        }

        const raw = mediaBuffer.toString('utf8')

        try {
            new Function(raw)
        } catch (e) {
            return Reply(`❌ File JS tidak valid:\n${e.message}`)
        }

        await raiden.sendMessage(m.chat, { react: { text: "🔥", key: m.key } })
        
        await Reply('⏳ *Memproses SIU encrypt...*')

        const JsConfuser = (await import('js-confuser')).default
        const obf = await JsConfuser.obfuscate(raw, getSiuObf())
        const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

        const outName = `siu-encrypted-${Date.now()}.js`
        const outPath = path.join(__dirname, outName)
        fs.writeFileSync(outPath, code, 'utf8')

        const fileBuffer = fs.readFileSync(outPath)
        await raiden.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: '✅ *Calcrick Chaos Core encrypted!*'
        }, {
            quoted: m
        })

        try {
            fs.unlinkSync(outPath)
        } catch (e) { console.error(e); }
    } catch (err) {
        console.error(err)
        Reply(`❌ Terjadi kesalahan: ${safeErr(err)}`)
    }
};

export default handler;
