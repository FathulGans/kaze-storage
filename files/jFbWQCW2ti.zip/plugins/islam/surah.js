import { fetchJson } from '../../library/function.js';

const pluginConfig = {
  name: 'surah',
  category: 'islam',
  command: ['surah'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, raiden, text, troli } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

    if (!text || isNaN(parseInt(text))) return Reply(
        `📖 *DETAIL SURAH AL-QUR'AN*\n\n` +
        `Masukkan nomor surah (1-114).\n` +
        `Contoh: *${prefix + command} 18*`
    );

    const _surahNum = parseInt(text);
    if (isNaN(_surahNum) || _surahNum < 1 || _surahNum > 114) return Reply('❌ Nomor surah harus antara 1-114.');

    Reply(`⏳ Memuat informasi Surah ke-${_surahNum}...`);

    try {
        const _res = await fetchJson(`https://cloudku.us.kg/api/murotal/surah?id=${_surahNum}`);
        if (_res.status !== 'success' || !_res.result) return Reply(`❌ Surah nomor ${_surahNum} tidak ditemukan.`);

        const _s = _res.result;
        const _caption = [
            `📖 *DETAIL SURAH AL-QUR'AN*`,
            ``,
            `╭─────────────────────╼`,
            `│ 🕋 *Surah*  : ${_s.name_id} (${_s.name_long})`,
            `│ 🌍 *Arti*   : ${_s.translation_id}`,
            `│ 🔢 *Nomor*  : ${_s.number}`,
            `│ 📜 *Ayat*   : ${_s.number_of_verses} Ayat`,
            `│ 🕌 *Tipe*   : ${_s.revelation_id}`,
            `╰─────────────────────╼`,
            ``,
            `✨ *Tafsir Singkat:*`,
            ``,
            `${_s.tafsir}`,
        ].join('\n');

        if (_s.audio_url) {
            await raiden.sendMessage(m.chat, {
                audio: { url: _s.audio_url },
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: troli });
        }

        Reply(_caption);

    } catch (e) {
        console.error('[surah-error]', e.message);
        Reply('❌ Gagal mengambil data surah.');
    }
};

export default handler;
