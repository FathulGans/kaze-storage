import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'asmaulhusna',
  category: 'islam',
  command: ['asmaulhusna'],
};

const handler = async (m, ctx) => {
    let { Reply, fullAsmaulHusna, isVip, text } = ctx;
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);



    let asma;
    if (text && !isNaN(text)) {
        const index = parseInt(text);
        if (index > 0 && index <= 99) {
            asma = fullAsmaulHusna[index - 1];
        } else {
            return Reply("❌ Nomor tidak valid. Masukkan angka antara 1 sampai 99.");
        }
    } else {
        asma = fullAsmaulHusna[Math.floor(Math.random() * fullAsmaulHusna.length)];
    }
    
    let teks = `🌟 *Asmaul Husna*\n\n`;
    teks += `${asma.index}. *${asma.latin}* (${asma.arabic})\n`;
    teks += `*Artinya:* ${asma.arti}`;
    Reply(teks);
};

export default handler;
