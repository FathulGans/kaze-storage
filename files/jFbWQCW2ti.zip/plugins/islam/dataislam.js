const pluginConfig = {
  name: 'dataislam',
  category: 'islam',
};

const fullAsmaulHusna = [
  { index: 1, latin: "Ar Rahman", arabic: "الرحمن", arti: "Yang Maha Pengasih" },
  { index: 2, latin: "Ar Rahiim", arabic: "الرحيم", arti: "Yang Maha Penyayang" },
  { index: 3, latin: "Al Malik", arabic: "الملك", arti: "Yang Maha Merajai" },
  { index: 4, latin: "Al Quddus", arabic: "القدوس", arti: "Yang Maha Suci" },
  { index: 5, latin: "As Salaam", arabic: "السلام", arti: "Yang Maha Memberi Kesejahteraan" },
  { index: 6, latin: "Al Mu'min", arabic: "المؤمن", arti: "Yang Maha Memberi Keamanan" },
  { index: 7, latin: "Al Muhaimin", arabic: "المهيمن", arti: "Yang Maha Mengatur" },
  { index: 8, latin: "Al 'Aziiz", arabic: "العزيز", arti: "Yang Maha Perkasa" },
  { index: 9, latin: "Al Jabbar", arabic: "الجبار", arti: "Yang Memiliki Mutlak Kegagahan" },
  { index: 10, latin: "Al Mutakabbir", arabic: "المتكبر", arti: "Yang Maha Megah" },
  { index: 11, latin: "Al Khaliq", arabic: "الخالق", arti: "Yang Maha Pencipta" },
  { index: 12, latin: "Al Baari'", arabic: "البارئ", arti: "Yang Maha Melepaskan" },
  { index: 13, latin: "Al Mushawwir", arabic: "المصور", arti: "Yang Maha Membentuk Rupa" },
  { index: 14, latin: "Al Ghaffaar", arabic: "الغفار", arti: "Yang Maha Pengampun" },
  { index: 15, latin: "Al Qahhaar", arabic: "القهار", arti: "Yang Maha Menundukkan" },
  { index: 16, latin: "Al Wahhaab", arabic: "الوهاب", arti: "Yang Maha Pemberi Karunia" },
  { index: 17, latin: "Ar Razzaaq", arabic: "الرزاق", arti: "Yang Maha Pemberi Rezeki" },
  { index: 18, latin: "Al Fattaah", arabic: "الفتاح", arti: "Yang Maha Pembuka Rahmat" },
  { index: 19, latin: "Al 'Aliim", arabic: "العليم", arti: "Yang Maha Mengetahui" },
  { index: 20, latin: "Al Qaabidh", arabic: "القابض", arti: "Yang Maha Menyempitkan" },
  { index: 21, latin: "Al Baasith", arabic: "الباسط", arti: "Yang Maha Melapangkan" },
  { index: 22, latin: "Al Khaafidh", arabic: "الخافض", arti: "Yang Maha Merendahkan" },
  { index: 23, latin: "Ar Raafi'", arabic: "الرافع", arti: "Yang Maha Meninggikan" },
  { index: 24, latin: "Al Mu'izz", arabic: "المعز", arti: "Yang Maha Memuliakan" },
  { index: 25, latin: "Al Mudzil", arabic: "المذل", arti: "Yang Maha Menghinakan" },
  { index: 26, latin: "As Samii'", arabic: "السميع", arti: "Yang Maha Mendengar" },
  { index: 27, latin: "Al Bashiir", arabic: "البصير", arti: "Yang Maha Melihat" },
  { index: 28, latin: "Al Hakam", arabic: "الحكم", arti: "Yang Maha Menetapkan" },
  { index: 29, latin: "Al 'Adl", arabic: "العدل", arti: "Yang Maha Adil" },
  { index: 30, latin: "Al Lathiif", arabic: "اللطيف", arti: "Yang Maha Lembut" },
  { index: 31, latin: "Al Khabiir", arabic: "الخبير", arti: "Yang Maha Mengenal" },
  { index: 32, latin: "Al Haliim", arabic: "الحليم", arti: "Yang Maha Penyantun" },
  { index: 33, latin: "Al 'Azhiim", arabic: "العظيم", arti: "Yang Maha Agung" },
  { index: 34, latin: "Al Ghafuur", arabic: "الغفور", arti: "Yang Maha Memberi Pengampunan" },
  { index: 35, latin: "As Syakuur", arabic: "الشكور", arti: "Yang Maha Pembalas Budi" },
  { index: 36, latin: "Al 'Aliy", arabic: "العلى", arti: "Yang Maha Tinggi" },
  { index: 37, latin: "Al Kabiir", arabic: "الكبير", arti: "Yang Maha Besar" },
  { index: 38, latin: "Al Hafizh", arabic: "الحفيظ", arti: "Yang Maha Memelihara" },
  { index: 39, latin: "Al Muqiit", arabic: "المقيت", arti: "Yang Maha Pemberi Kecukupan" },
  { index: 40, latin: "Al Hasiib", arabic: "الحسيب", arti: "Yang Maha Membuat Perhitungan" },
  { index: 41, latin: "Al Jaliil", arabic: "الجليل", arti: "Yang Maha Luhur" },
  { index: 42, latin: "Al Kariim", arabic: "الكريم", arti: "Yang Maha Pemurah" },
  { index: 43, latin: "Ar Raqiib", arabic: "الرقيب", arti: "Yang Maha Mengawasi" },
  { index: 44, latin: "Al Mujiib", arabic: "المجيب", arti: "Yang Maha Mengabulkan" },
  { index: 45, latin: "Al Waasi'", arabic: "الواسع", arti: "Yang Maha Luas" },
  { index: 46, latin: "Al Hakiim", arabic: "الحكيم", arti: "Yang Maha Maka Bijaksana" },
  { index: 47, latin: "Al Waduud", arabic: "الودود", arti: "Yang Maha Mengasihi" },
  { index: 48, latin: "Al Majiid", arabic: "المجيد", arti: "Yang Maha Mulia" },
  { index: 49, latin: "Al Baa'its", arabic: "الباعث", arti: "Yang Maha Membangkitkan" },
  { index: 50, latin: "As Syahiid", arabic: "الشهيد", arti: "Yang Maha Menyaksikan" },
  { index: 51, latin: "Al Haqq", arabic: "الحق", arti: "Yang Maha Benar" },
  { index: 52, latin: "Al Wakiil", arabic: "الوكيل", arti: "Yang Maha Memelihara" },
  { index: 53, latin: "Al Qawiyyu", arabic: "القوى", arti: "Yang Maha Kuat" },
  { index: 54, latin: "Al Matiin", arabic: "المتين", arti: "Yang Maha Kokoh" },
  { index: 55, latin: "Al Waliyy", arabic: "الولى", arti: "Yang Maha Melindungi" },
  { index: 56, latin: "Al Hamiid", arabic: "الحميد", arti: "Yang Maha Terpuji" },
  { index: 57, latin: "Al Muhshii", arabic: "المحصى", arti: "Yang Maha Menghitung" },
  { index: 58, latin: "Al Mubdi'", arabic: "المبدئ", arti: "Yang Maha Memulai" },
  { index: 59, latin: "Al Mu'iid", arabic: "المعيد", arti: "Yang Maha Mengembalikan Kehidupan" },
  { index: 60, latin: "Al Muhyii", arabic: "المحيى", arti: "Yang Maha Menghidupkan" },
  { index: 61, latin: "Al Mumiitu", arabic: "المميت", arti: "Yang Maha Mematikan" },
  { index: 62, latin: "Al Hayyu", arabic: "الحي", arti: "Yang Maha Hidup" },
  { index: 63, latin: "Al Qayyuum", arabic: "القيوم", arti: "Yang Maha Mandiri" },
  { index: 64, latin: "Al Waajid", arabic: "الواجد", arti: "Yang Maha Penemu" },
  { index: 65, latin: "Al Maajid", arabic: "الماجد", arti: "Yang Maha Mulia" },
  { index: 66, latin: "Al Waahid", arabic: "الواحد", arti: "Yang Maha Tunggal" },
  { index: 67, latin: "Al Ahad", arabic: "الاحد", arti: "Yang Maha Esa" },
  { index: 68, latin: "As Shamad", arabic: "الصمد", arti: "Yang Maha Dibutuhkan" },
  { index: 69, latin: "Al Qaadir", arabic: "القادر", arti: "Yang Maha Menentukan" },
  { index: 70, latin: "Al Muqtadir", arabic: "المقتدر", arti: "Yang Maha Berkuasa" },
  { index: 71, latin: "Al Muqaddim", arabic: "المقدم", arti: "Yang Maha Mendahulukan" },
  { index: 72, latin: "Al Mu'akkhir", arabic: "المؤخر", arti: "Yang Maha Mengakhirkan" },
  { index: 73, latin: "Al Awwal", arabic: "الأول", arti: "Yang Maha Awal" },
  { index: 74, latin: "Al Aakhir", arabic: "الأخر", arti: "Yang Maha Akhir" },
  { index: 75, latin: "Az Zhaahir", arabic: "الظاهر", arti: "Yang Maha Nyata" },
  { index: 76, latin: "Al Baathin", arabic: "الباطن", arti: "Yang Maha Ghaib" },
  { index: 77, latin: "Al Waali", arabic: "الوالي", arti: "Yang Maha Memerintah" },
  { index: 78, latin: "Al Muta'aalii", arabic: "المتعالي", arti: "Yang Maha Tinggi" },
  { index: 79, latin: "Al Barru", arabic: "البر", arti: "Yang Maha Penderma" },
  { index: 80, latin: "At Tawwaab", arabic: "التواب", arti: "Yang Maha Penerima Tobat" },
  { index: 81, latin: "Al Muntaqim", arabic: "المنتقم", arti: "Yang Maha Pemberi Balasan" },
  { index: 82, latin: "Al Afuww", arabic: "العفو", arti: "Yang Maha Pemaaf" },
  { index: 83, latin: "Ar Ra'uuf", arabic: "الرؤوف", arti: "Yang Maha Pengasuh" },
  { index: 84, latin: "Malikul Mulk", arabic: "مالك الملك", arti: "Yang Maha Penguasa Kerajaan" },
  { index: 85, latin: "Dzul Jalaali Wal Ikraam", arabic: "ذو الجلال و الإكرام", arti: "Yang Maha Pemilik Kebesaran dan Kemuliaan" },
  { index: 86, latin: "Al Muqsith", arabic: "المقسط", arti: "Yang Maha Pemberi Keadilan" },
  { index: 87, latin: "Al Jamii'", arabic: "الجامع", arti: "Yang Maha Mengumpulkan" },
  { index: 88, latin: "Al Ghaniyy", arabic: "الغنى", arti: "Yang Maha Kaya" },
  { index: 89, latin: "Al Mughnii", arabic: "المغنى", arti: "Yang Maha Pemberi Kekayaan" },
  { index: 90, latin: "Al Maani", arabic: "المانع", arti: "Yang Maha Mencegah" },
  { index: 91, latin: "Ad Dhaar", arabic: "الضار", arti: "Yang Maha Penimpa Kemudharatan" },
  { index: 92, latin: "An Nafii'", arabic: "النافع", arti: "Yang Maha Memberi Manfaat" },
  { index: 93, latin: "An Nuur", arabic: "النور", arti: "Yang Maha Bercahaya" },
  { index: 94, latin: "Al Haadi", arabic: "الهادئ", arti: "Yang Maha Pemberi Petunjuk" },
  { index: 95, latin: "Al Badii'", arabic: "البديع", arti: "Yang Maha Pencipta Tiada Bandingannya" },
  { index: 96, latin: "Al Baaqii", arabic: "الباقي", arti: "Yang Maha Kekal" },
  { index: 97, latin: "Al Waarits", arabic: "الوارث", arti: "Yang Maha Pewaris" },
  { index: 98, latin: "Ar Rasyiid", arabic: "الرشيد", arti: "Yang Maha Pandai" },
  { index: 99, latin: "As Shabuur", arabic: "الصبور", arti: "Yang Maha Sabar" }
];

const dataBacaanSholat = {
  "takbir": { "title": "Takbiratul Ihram", "arabic": "اللهُ أَكْبَرُ", "latin": "Allahu Akbar", "arti": "Allah Maha Besar" },
  "iftitah": { "title": "Doa Iftitah", "arabic": "اللهُ أَكْبَرُ كَبِيرًا وَالْحَمْدُ لِلَّهِ كَثِيرًا وَسُبْحَانَ اللَّهِ بُكْرَةً وَأَصِيلاً", "latin": "Allahu akbar kabiiro, walhamdulillahi katsiiro, wa subhanallahi bukrotaw wa'ashiila", "arti": "Allah Maha Besar dengan sebesar-besarnya, segala puji bagi Allah dengan pujian yang banyak, Maha Suci Allah pada waktu pagi dan petang." },
  "fatihah": { "title": "Al-Fatihah", "arabic": "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ...", "latin": "Bismillah hirrahman nirrahim...", "arti": "Dengan menyebut nama Allah Yang Maha Pengasih lagi Maha Penyayang..." },
  "ruku": { "title": "Ruku'", "arabic": "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ", "latin": "Subhaana robbiyal 'adziimi wa bihamdih", "arti": "Maha Suci Tuhanku yang Maha Agung dan dengan memuji-Nya." },
  "itidal": { "title": "I'tidal", "arabic": "سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ", "latin": "Sami'allaahu liman hamidah", "arti": "Allah Maha Mendengar orang yang memuji-Nya." },
  "sujud": { "title": "Sujud", "arabic": "سُبْحَانَ رَبِّيَ الأَعْلَى وَبِحَمْدِهِ", "latin": "Subhaana robbiyal a'laa wa bihamdih", "arti": "Maha Suci Tuhanku Yang Maha Tinggi dan dengan memuji-Nya." },
  "tahiyat": { "title": "Tahiyat Akhir", "arabic": "التَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ لِلَّهِ...", "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah...", "arti": "Segala kehormatan, keberkahan, rahmat dan kebaikan adalah milik Allah..." },
  "salam": { "title": "Salam", "arabic": "السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ", "latin": "Assalaamu 'alaikum wa rohmatullaah", "arti": "Semoga keselamatan dan rahmat Allah dilimpahkan kepadamu." }
};

const dataDoaPilihan = {
    "qunut": {"title": "Doa Qunut", "arabic": "اَللّهُمَّ اهْدِنِىْ فِيْمَنْ هَدَيْتَ...", "latin": "Allahummahdinii fiiman hadait...", "arti": "Ya Allah, berilah aku petunjuk di antara orang-orang yang Engkau beri petunjuk..."},
    "tahajud": {"title": "Doa Setelah Sholat Tahajud", "arabic": "اَللهم رَبَّنَا لَكَ الْحَمْدُ...", "latin": "Allahumma robbana lakal hamdu...", "arti": "Ya Allah, Tuhan kami, segala puji bagi-Mu..."},
    "dhuha": {"title": "Doa Setelah Sholat Dhuha", "arabic": "اَللّٰهُمَّ اِنَّ الضُّحَآءَ ضُحَاءُكَ...", "latin": "Allahumma innad-duhaa'a duhaa'uka...", "arti": "Ya Allah, sesungguhnya waktu Dhuha adalah waktu Dhuha-Mu..."}
};

const dataHadits = [
  { "rawi": "Bukhari", "hadits": "Sesungguhnya setiap amalan bergantung pada niatnya." },
  { "rawi": "Muslim", "hadits": "Barangsiapa yang menunjuki kepada kebaikan maka dia akan mendapatkan pahala seperti pahala orang yang mengerjakannya." },
  { "rawi": "Tirmidzi", "hadits": "Senyummu di hadapan saudaramu adalah sedekah." },
  { "rawi": "Bukhari", "hadits": "Orang yang paling baik di antara kalian adalah yang paling baik akhlaknya." },
  { "rawi": "Muslim", "hadits": "Kebersihan adalah sebagian dari iman." }
];

function formatBoxes(boxes) {
    let result = '';
    for (let i = 0; i < 10; i++) {
        result += `${i+1}. ${boxes[i]} `;
        if ((i+1) % 5 === 0) result += '\n';
    }
    return result;
}

export { formatBoxes, fullAsmaulHusna, dataBacaanSholat, dataDoaPilihan, dataHadits };

export default { modulPendukung: true };
