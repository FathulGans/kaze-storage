import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'wirid',
  category: 'islam',
  command: ['wirid', 'dzikir'],
};

const handler = async (m, ctx) => {
    let { Reply, isVip } = ctx;
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);



    const teks = `📿 *Wirid & Dzikir Setelah Sholat Fardhu*\n\n1. Membaca Istighfar (3x)\n   أَسْتَغْفِرُ اللهَ الْعَظِيمَ\n   "Astaghfirullahal 'adziim"\n\n2. Membaca Tahlil\n   لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ...\n   "Laa ilaha illallahu wahdahu laa syarika lah..."\n\n3. Membaca Tasbih (33x)\n   سُبْحَانَ اللهِ\n   "Subhanallah"\n\n4. Membaca Tahmid (33x)\n   الْحَمْدُ لِلَّهِ\n   "Alhamdulillah"\n\n5. Membaca Takbir (33x)\n   اللهُ أَكْبَرُ\n   "Allahu Akbar"\n\n6. Ditutup dengan Tahlil Panjang & Doa.\n\n(Ini adalah versi ringkas, urutan dapat bervariasi)`;
    Reply(teks);
};

export default handler;
