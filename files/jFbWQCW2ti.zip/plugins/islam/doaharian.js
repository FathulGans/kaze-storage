import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'doaharian',
  category: 'islam',
  command: ['doaharian'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
    return Reply(global.mess.limit);

const doa = [
    { title: "Doa Sebelum Tidur", arabic: "بِاسْمِكَ اللَّهُمَّ أَحْيَا وَبِاسْمِكَ أَمُوتُ", latin: "Bismika Allahumma ahya wa bismika amut.", meaning: "Dengan nama-Mu ya Allah aku hidup dan dengan nama-Mu aku mati." },
    { title: "Doa Bangun Tidur", arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ", latin: "Alhamdulillahilladzi ahyana ba'da ma amatana wa ilaihin nusyur.", meaning: "Segala puji bagi Allah yang telah menghidupkan kami setelah mematikan kami, dan kepada-Nya kami akan kembali." },
    { title: "Doa Sebelum Makan", arabic: "اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ", latin: "Allahumma barik lana fima razaqtana waqina 'adzaban nar.", meaning: "Ya Allah, berkahilah kami dalam rezeki yang telah Engkau berikan kepada kami dan peliharalah kami dari siksa api neraka." },
    { title: "Doa Sesudah Makan", arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ", latin: "Alhamdulillahilladzi ath'amana wa saqana wa ja'alana minal muslimin.", meaning: "Segala puji bagi Allah yang telah memberi kami makan dan minum, serta menjadikan kami seorang muslim." },
    { title: "Doa Masuk Kamar Mandi", arabic: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ", latin: "Allahumma inni a'udzubika minal khubutsi wal khabaitsi.", meaning: "Ya Allah, aku berlindung pada-Mu dari godaan setan laki-laki dan setan perempuan." },
    { title: "Doa Keluar Kamar Mandi", arabic: "غُفْرَانَكَ الْحَمْدُ لِلَّهِ الَّذِي أَذْهَبَ عَنِّي الْأَذَى وَعَافَانِي", latin: "Ghufronaka alhamdulillahilladzi adzhaba 'annil adzaa wa'aafaanii.", meaning: "Dengan mengharap ampunan-Mu, segala puji milik Allah yang telah menghilangkan kotoran dari badanku dan yang telah menyejahterakan." }
];
const randomDoa = doa[Math.floor(Math.random() * doa.length)];
let teks = `🤲 *Doa Harian*\n\n`;
teks += `*Judul:* ${randomDoa.title}\n`;
teks += `*Arab:* ${randomDoa.arabic}\n`;
teks += `*Latin:* ${randomDoa.latin}\n`;
teks += `*Artinya:* ${randomDoa.meaning}`;
Reply(teks);
};

export default handler;
