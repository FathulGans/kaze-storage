import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'jadwalsholat',
  category: 'islam',
  command: ['jadwalsholat'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isVip, prefix, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);
    if (!text) return Reply(`Mau cek jadwal sholat di kota mana?\nContoh: ${prefix + command} Jakarta`);
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        const { data } = await axios.get(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(text)}&country=Indonesia&method=20`);
        
        if (data.code !== 200) throw new Error("Gagal mengambil data");

        const timings = data.data.timings;
        const dateStr = data.data.date.readable;
        const hijri = data.data.date.hijri;
        const hijriDate = `${hijri.day} ${hijri.month.en} ${hijri.year}`;

        let teksSholat = `🕌 *JADWAL SHOLAT*\n\n`;
        teksSholat += `📍 *Kota:* ${text.toUpperCase()}\n`;
        teksSholat += `📅 *Masehi:* ${dateStr}\n`;
        teksSholat += `🌙 *Hijriah:* ${hijriDate}\n\n`;
        teksSholat += `🌅 *Imsak:* ${timings.Imsak}\n`;
        teksSholat += `🌄 *Subuh:* ${timings.Fajr}\n`;
        teksSholat += `🌞 *Terbit:* ${timings.Sunrise}\n`;
        teksSholat += `☀️ *Dzuhur:* ${timings.Dhuhr}\n`;
        teksSholat += `🌤️ *Ashar:* ${timings.Asr}\n`;
        teksSholat += `🌇 *Maghrib:* ${timings.Maghrib}\n`;
        teksSholat += `🌌 *Isya:* ${timings.Isha}`;

        Reply(teksSholat);

    } catch (err) {
        Reply(`❌ Gagal mengambil jadwal sholat untuk kota "${text}".\nPastikan nama kota dieja dengan benar.`);
    }
};

export default handler;
