import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'tebakkah',
  category: 'game',
  command: ['tebakkah'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


    const soalList = [
        { soal: "Apa yang bisa terbang, tetapi tidak memiliki sayap?", jawaban: "waktu" },
        { soal: "Aku punya banyak kunci, tapi tidak bisa membuka pintu. Apa aku?", jawaban: "piano" },
        { soal: "Apa yang selalu naik tapi tidak pernah turun?", jawaban: "umur" },
        { soal: "Aku bisa dipegang, tapi tidak bisa dilihat. Apa aku?", jawaban: "janji" },
        { soal: "Apa yang bisa dipotong, tapi tidak berkurang?", jawaban: "rambut" },
        { soal: "Aku bisa menangis tanpa mata. Apa aku?", jawaban: "awan" },
        { soal: "Apa yang ada di depan kamu, tapi kamu tidak bisa melihatnya?", jawaban: "masa depan" },
        { soal: "Aku bisa berlari, tapi tidak punya kaki. Apa aku?", jawaban: "air" },
        { soal: "Aku bisa terbang, tapi bukan burung. Aku adalah?", jawaban: "layang-layang" },
        { soal: "Aku bisa berbicara, tapi tidak punya mulut. Apa aku?", jawaban: "gema" }
    ];
    let soalAcak = soalList[Math.floor(Math.random() * soalList.length)];
    global.tebakJawaban = soalAcak.jawaban.toLowerCase();
    Reply(`🎮 *Game Tebak Random!*\n\n❓ *Soal:* ${soalAcak.soal}\n\nKetik *.jawabtebak [jawaban kamu]*`);
};

export default handler;
