import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebakkata',
  category: 'game',
  command: ['tebakkata'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebakkata', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
