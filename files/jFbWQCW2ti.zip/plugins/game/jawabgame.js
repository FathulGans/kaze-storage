const pluginConfig = {
  name: 'jawabgame',
  category: 'game',
  command: ['jawabgame', 'jg'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip, text } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
if (!global._gameSession) global._gameSession = {};
const _sess = global._gameSession[m.sender];
if (!_sess) return Reply('⚠️ *Belum ada game aktif!*\nMulai game dulu dari menu Game.');
if (!text) return Reply('Ketik: *.jawabgame <jawaban kamu>*');
const _jawabUser = text.toLowerCase().trim();
const _benar = Array.isArray(_sess.jawaban) ? _sess.jawaban.includes(_jawabUser) : _jawabUser === _sess.jawaban;
if (_benar) {
 delete global._gameSession[m.sender];
 Reply('✅ *BETUL BANGET!* 🎉\nJawaban: *' + (Array.isArray(_sess.jawaban) ? _sess.jawaban[0] : _sess.jawaban) + '*\n\n🔥 Otakmu tajam banget!');
} else {
 const _hint = Array.isArray(_sess.jawaban) ? _sess.jawaban[0] : _sess.jawaban;
 Reply('❌ *Salah!* Coba lagi...\n💡 Clue: Jawabannya *' + _hint.length + ' huruf*');
}
};

export default handler;
