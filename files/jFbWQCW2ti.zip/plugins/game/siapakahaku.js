import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'siapakahaku',
  category: 'game',
  command: ['siapakahaku'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('siapakahaku', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
