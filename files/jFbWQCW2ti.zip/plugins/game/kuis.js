import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'kuis',
  category: 'game',
  command: ['kuis'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip } = ctx;
if (!isRegistered(m.sender) && !isVip)
    return daftar(global.mess.verifikasi);

if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
return Reply(global.mess.limit);


    const soalList = [
        { soal: "Ibukota Indonesia adalah?", jawaban: "jakarta" },
        { soal: "Siapa presiden pertama Indonesia?", jawaban: "soekarno" },
        { soal: "Planet terbesar di tata surya?", jawaban: "jupiter" },
        { soal: "Bendera Jepang berwarna apa?", jawaban: "putih merah" },
        { soal: "Jumlah provinsi di Indonesia tahun 2023?", jawaban: "38" },
        { soal: "Bahasa resmi negara Brazil?", jawaban: "portugis" },
        { soal: "1 lusin berapa?", jawaban: "12" },
        { soal: "Apa kepanjangan dari CPU?", jawaban: "central processing unit" },
        { soal: "Lambang kimia dari air?", jawaban: "h2o" },
        { soal: "Gunung tertinggi di dunia?", jawaban: "everest" },
        { soal: "Apa warna daun?", jawaban: "hijau" },
        { soal: "Binatang berkaki delapan?", jawaban: "laba-laba" },
        { soal: "Apa yang dipakai untuk menulis di papan tulis?", jawaban: "spidol" },
        { soal: "Ibukota Jawa Barat?", jawaban: "bandung" },
        { soal: "Sebutkan alat musik yang ditiup?", jawaban: "seruling" }
    ];
    let soalAcak = soalList[Math.floor(Math.random() * soalList.length)];
    global.kuisJawaban = soalAcak.jawaban.toLowerCase();
    Reply(`🎯 *KUIS CEPAT!* \n\n*Soal:* ${soalAcak.soal}\n\nKetik *.jawabkuis [jawaban kamu]*`);
};

export default handler;
