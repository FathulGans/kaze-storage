import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebakmakanan',
  category: 'game',
  command: ['tebakmakanan'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebakmakanan', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
