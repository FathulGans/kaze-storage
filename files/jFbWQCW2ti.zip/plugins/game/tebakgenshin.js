import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebakgenshin',
  category: 'game',
  command: ['tebakgenshin'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebakgenshin', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
