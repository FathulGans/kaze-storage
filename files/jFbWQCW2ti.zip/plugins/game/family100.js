import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'family100',
  category: 'game',
  command: ['family100'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('family100', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
