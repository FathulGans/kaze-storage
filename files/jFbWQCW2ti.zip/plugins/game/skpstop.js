const pluginConfig = {
  name: 'skpstop',
  category: 'game',
  command: ['skpstop'],
};

const handler = async (m, ctx) => {
    let { Reply } = ctx;
if (!global._skpSessions || !global._skpSessions[m.chat]) return Reply('⚠️ Tidak ada game Sambung Kata Plus yang berlangsung.');
const _skpE = global._skpSessions[m.chat];
const _skpBoard = Object.entries(_skpE.skor).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([id,s],i)=>`${i+1}. @${id.split('@')[0]} — ${s} kata`).join('\n');
delete global._skpSessions[m.chat];
Reply(`🏁 *GAME SELESAI!*\n\n📋 Total kata: ${_skpE.chain.length}\n\n🏆 *Leaderboard:*\n${_skpBoard||'Belum ada skor'}`,Object.keys(_skpE.skor));
};

export default handler;
