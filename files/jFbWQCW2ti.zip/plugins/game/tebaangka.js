const pluginConfig = {
  name: 'tebaangka',
  category: 'game',
  command: ['tebaangka'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isPremium, isVip } = ctx;
if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);
if (global.gameSessions[m.chat]) return Reply('⚠️ Masih ada game berlangsung! Ketik *.nyerah* dulu.');
const _taN = Math.floor(Math.random()*100)+1;
const _taMsg = await Reply(`🔢 *TEBAK ANGKA!*\n\nAku menyimpan angka *1 - 100*\n\n💡 Tebak berapa?\n📌 *Balas/Reply* pesan ini!\n⏳ Waktu: 60 detik | Bisa coba berkali-kali!`);
if (!_taMsg?.key?.id) { Reply('❌ Gagal mulai game'); return; }
global.gameSessions[m.chat] = {
    gameType: 'tebaangka', jawaban: String(_taN), target: _taN, percobaan: 0,
    messageId: _taMsg.key.id, startTime: Date.now(),
    timeout: setTimeout(()=>{ if(global.gameSessions[m.chat]){ Reply(`⏰ Waktu habis! Angkanya adalah *${_taN}*`); delete global.gameSessions[m.chat]; }},60000)
};
};

export default handler;
