import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'caklontong',
  category: 'game',
  command: ['caklontong'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('caklontong', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
