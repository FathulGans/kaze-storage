const pluginConfig = {
  name: 'coinflip',
  category: 'game',
  command: ['coinflip'],
};

const handler = async (m, ctx) => {
    let { Reply, command, daftar, isPremium, isVip, prefix, text } = ctx;
    if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, isPremium, isVip)) return Reply(global.mess.limit);

    if (!text) return Reply(`*Format:* ${prefix + command} <taruhan> <heads/tails>\n*Contoh:* ${prefix + command} 1000 heads`);

    const argsArr = text.trim().split(/\s+/);
    const bet = parseInt(argsArr[0]);
    const side = argsArr[1]?.toLowerCase();

    if (!bet || bet <= 0) return Reply('❌ Taruhan harus berupa angka positif.');
    if (!side || !['heads', 'tails'].includes(side)) return Reply('❌ Pilih *heads* atau *tails*.');

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const win = side === result;
    const emoji = result === 'heads' ? '👑' : '🦅';

    let txt = `🪙 *COIN FLIP* 🪙\n\n`;
    txt += `${emoji} Koin mendarat di *${result.toUpperCase()}*!\n\n`;
    txt += win
        ? `✅ *Menang!* Taruhan: Rp${bet.toLocaleString('id-ID')}`
        : `❌ *Kalah!* Taruhan: Rp${bet.toLocaleString('id-ID')}`;

    Reply(txt);
};

export default handler;
