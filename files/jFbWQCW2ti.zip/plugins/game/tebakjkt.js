import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebakjkt',
  category: 'game',
  command: ['tebakjkt'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebakjkt', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
