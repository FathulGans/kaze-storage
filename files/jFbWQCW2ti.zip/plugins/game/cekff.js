import axios from 'axios';
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'cekff',
  category: 'game',
  command: ['cekff', 'stalkff', 'freestalk'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, example, isVip, raiden, text } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    if (!text) {
        return Reply(example("14794881003"));
    }
    
    let uid = text.trim();
    if (!/^\d+$/.test(uid)) {
        return Reply("❌ UID harus berupa angka!");
    }
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    try {
        const apiUrl = `https://api.nexray.eu.cc/stalker/freefire?uid=${uid}`;
        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;
        
        if (!data.status || !data.result) {
            throw new Error('Gagal mengambil data');
        }
        
        const r = data.result;
        
        let rankBr = 'Tidak ditampilkan';
        let brRankPoint = r.br_rank_point || r.guild_leader_br_points || '-';
        let brMaxRank = r.br_max_rank || r.guild_leader_br_max_rank || '-';
        if ((r.show_br_rank === 1 || r.show_br_rank === true) && brRankPoint !== '-') {
            rankBr = `${brRankPoint} (Max: ${brMaxRank})`;
        }
        
        let rankCs = 'Tidak ditampilkan';
        let csRankPoint = r.cs_rank_point || r.guild_leader_cs_points || '-';
        let csMaxRank = r.cs_max_rank || r.guild_leader_cs_max_rank || '-';
        if ((r.show_cs_rank === 1 || r.show_cs_rank === true) && csRankPoint !== '-') {
            rankCs = `${csRankPoint} (Max: ${csMaxRank})`;
        }
        
        let caption = `╭─❏ *AKUN*
│✧ ID : ${r.id || '-'}
│✧ UID : ${r.uid}
│✧ Nama : ${r.name}
│✧ Level : ${r.level}
│✧ EXP : ${r.exp?.toLocaleString() || '-'}
│✧ Region : ${r.region}
│✧ Likes : ${r.likes || r.guild_leader_likes || '-'}
│✧ Credit Score : ${r.credit_score || '-'}
│✧ Signature : ${r.signature || '-'}
│✧ Title : ${r.title || '-'}
│✧ Language : ${r.language || '-'}
│✧ Gender : ${r.gender || '-'}
│✧ Prime Level : ${r.prime_level || '-'}
│✧ Honor Score : ${r.honor_score || '-'}
│✧ Celebrity Status : ${r.celebrity_status || '-'}
│✧ Days Old : ${r.days_old || '-'}
╰──────────❏

╭─❏ *RANK*
│✧ BR Rank : ${rankBr}
│✧ BR Rank Point : ${brRankPoint}
│✧ BR Max Rank : ${brMaxRank}
│✧ CS Rank : ${rankCs}
│✧ CS Rank Point : ${csRankPoint}
│✧ CS Max Rank : ${csMaxRank}
│✧ CS Peak Points : ${r.cs_peak_points || '-'}
│✧ Rank Show : ${r.rank_show || (r.show_br_rank === 1 ? 'BR' : 'CS')}
╰──────────❏

╭─❏ *GUILD*
│✧ Nama : ${r.guild_name || '-'}
│✧ ID : ${r.guild_id || '-'}
│✧ Level : ${r.guild_level || '-'}
│✧ Owner : ${r.guild_leader_name || r.guild_owner_id || '-'}
│✧ Owner UID : ${r.guild_leader_uid || '-'}
│✧ Owner Level : ${r.guild_leader_level || '-'}
│✧ Member : ${r.guild_member || r.guild_members || 0}/${r.guild_capacity || 20}
╰──────────❏

╭─❏ *EQUIPPED*
│✧ Avatar ID : ${r.equipped_avatar_id || r.guild_leader_avatar_id || '-'}
│✧ Badge ID : ${r.equipped_bp_id || r.guild_leader_badge_id || '-'}
│✧ Badge Badges : ${r.equipped_bp_badges || r.guild_leader_bp_badges || '-'}
│✧ Banner ID : ${r.equipped_banner_id || r.guild_leader_banner_id || '-'}
│✧ Pin ID : ${r.pin_id || r.guild_leader_pin_id || '-'}
│✧ Outfit : ${r.equipped_outfit || '-'}
│✧ Weapon : ${r.equipped_weapon || '-'}
│✧ Gun ID : ${r.equipped_gun_id || '-'}
│✧ Animation ID : ${r.equipped_animation_id || '-'}
│✧ Transform Animation : ${r.transform_animation_id || '-'}
│✧ Skills : ${r.equipped_skills ? r.equipped_skills.substring(0, 50) + (r.equipped_skills.length > 50 ? '...' : '') : '-'}
╰──────────❏

╭─❏ *PET*
│✧ Pet Name : ${r.pet_name || '-'}
│✧ Pet Level : ${r.pet_level || '-'}
│✧ Pet EXP : ${r.pet_exp || '-'}
│✧ Pet Type : ${r.pet_type || '-'}
│✧ Pet Equipped : ${r.pet_equipped || '-'}
│✧ Pet ID : ${r.pet_id || '-'}
│✧ Pet Skin ID : ${r.pet_skin_id || '-'}
│✧ Pet Is Selected : ${r.pet_is_selected === 1 ? 'Ya' : 'Tidak'}
╰──────────❏

╭─❏ *LAINNYA*
│✧ Account Type : ${r.account_type === 1 ? 'Normal' : r.account_type || '-'}
│✧ Release Version : ${r.release_version || r.guild_leader_release_version || '-'}
│✧ Season ID : ${r.season_id || r.guild_leader_season_id || '-'}
│✧ Fire Pass : ${r.fire_pass || '-'}
│✧ Booyah Pass : ${r.booyah_pass || '-'}
│✧ BP Badges : ${r.bp_badges || '-'}
│✧ Most Recent OB : ${r.most_recent_ob || '-'}
│✧ Mode Prefer : ${r.mode_prefer || '-'}
│✧ Time Active : ${r.time_active || '-'}
│✧ Created At : ${r.created_at?.split('T')[0] || r.guild_leader_created_at?.split('T')[0] || '-'}
│✧ Last Login : ${r.last_login?.split('T')[0] || r.guild_leader_last_login?.split('T')[0] || '-'}
│✧ Last Updated : ${r.last_updated?.split('T')[0] || '-'}
│✧ From Database : ${r.fromDatabase ? 'Ya' : 'Tidak'}
│✧ Source : ${r.source || '-'}
╰──────────❏`;
        
        return Reply(caption);
        
    } catch (error) {
        console.error('[CEKFF ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        return Reply('❌ Gagal mengambil data. Pastikan UID benar.');
    }
};

export default handler;
