import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebaklirik',
  category: 'game',
  command: ['tebaklirik'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebaklirik', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
