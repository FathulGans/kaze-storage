import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'quax',
  category: 'game',
  command: ['quax', 'qu'],
};

const handler = async (m, ctx) => {
    let { Reply, daftar, isVip, raiden, safeErr, uploadQu } = ctx;
    if (!isRegistered(m.sender) && !isVip)
        return daftar(global.mess.verifikasi);
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip))
        return Reply(global.mess.limit);
    
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    
    if (!/image|video|audio|document/.test(mime)) {
        return Reply(`╭─❏ *Qu.ax Uploader*
│✧ Format : Reply media dengan caption .qu
│✧ Support : Gambar, Video, Audio, File
╰──────────❏`);
    }
    
    await raiden.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    try {
        const buffer = await q.download();
        if (!buffer) throw new Error('Gagal download media');
        
        const generateFilename = (mimeType) => {
            const ext = mimeType.split('/')[1] || 'bin';
            return `archio-${Date.now()}.${ext}`;
        };
        
        const result = await uploadQu(buffer, mime, generateFilename);
        
        if (!result || !result.url) {
            throw new Error('Upload gagal');
        }
        
        await Reply(result.url);
        await raiden.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[QU ERROR]', error);
        await raiden.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(`╭─❏ *Qu.ax Uploader* - Gagal\n│✧ Error : ${safeErr(error)}\n╰──────────❏`);
    }
    return;
};

export default handler;
