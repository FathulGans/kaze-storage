import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'asahotak',
  category: 'game',
  command: ['asahotak'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('asahotak', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
