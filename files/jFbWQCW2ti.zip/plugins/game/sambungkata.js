import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'sambungkata',
  category: 'game',
  command: ['sambungkata'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('sambungkata', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
