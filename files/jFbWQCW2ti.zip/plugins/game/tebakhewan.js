import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebakhewan',
  category: 'game',
  command: ['tebakhewan'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebakhewan', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
