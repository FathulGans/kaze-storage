import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebakbendera',
  category: 'game',
  command: ['tebakbendera'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebakbendera', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
