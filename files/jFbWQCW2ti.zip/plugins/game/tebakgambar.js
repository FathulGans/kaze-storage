import { startGame } from '../../src/lib/game.js';

const pluginConfig = {
  name: 'tebakgambar',
  category: 'game',
  command: ['tebakgambar'],
};

const handler = async (m, { raiden, Reply, isRegistered, isVip }) => {
    await startGame('tebakgambar', m, raiden, Reply, isRegistered, isVip);
};

export default handler;
