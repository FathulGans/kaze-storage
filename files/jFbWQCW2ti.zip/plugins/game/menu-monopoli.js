// Dipindahkan ke plugins/lainnya/menu.js. Berkas ini sudah tidak dipakai dan boleh dihapus.
export default { modulPendukung: true };
