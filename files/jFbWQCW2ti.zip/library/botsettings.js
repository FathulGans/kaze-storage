import { fileURLToPath } from 'url';
import fs from 'fs';
import path from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const BOT_SETTINGS_PATH = path.join(__dirname, 'database', 'botsettings.json');

function loadBotSettings() {
    try {
        if (!fs.existsSync(BOT_SETTINGS_PATH)) return {};
        const raw = fs.readFileSync(BOT_SETTINGS_PATH, 'utf-8');
        if (!raw || !raw.trim()) return {};
        const parsed = JSON.parse(raw);
        return (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) ? parsed : {};
    } catch (e) {
        console.log('[botsettings] Gagal membaca botsettings.json, abaikan:', e.message);
        return {};
    }
}

function saveBotSettings(partial) {
    try {
        const current = loadBotSettings();
        const merged = { ...current, ...partial };
        const dir = path.dirname(BOT_SETTINGS_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(BOT_SETTINGS_PATH, JSON.stringify(merged, null, 2));
        return merged;
    } catch (e) {
        console.log('[botsettings] Gagal menyimpan botsettings.json:', e.message);
        return null;
    }
}

export default { loadBotSettings, saveBotSettings, BOT_SETTINGS_PATH };
export { loadBotSettings, saveBotSettings, BOT_SETTINGS_PATH };
