import { fileURLToPath } from 'url';
import fs from 'fs';
import path from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_DIR = path.join(__dirname, 'database');
const DB_FILE = path.join(DB_DIR, 'albumStore.json');

const TTL_MS = 6 * 60 * 60 * 1000;

const store = new Map();

function loadFromDisk() {
    try {
        if (!fs.existsSync(DB_FILE)) return;
        const raw = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
        const now = Date.now();
        for (const [key, record] of Object.entries(raw || {})) {
            if (!record || (record.updatedAt && now - record.updatedAt > TTL_MS)) continue;
            store.set(key, record);
        }
    } catch (e) {
        console.log('[albumStore] Gagal load database lama, mulai dari kosong:', e?.message || e);
    }
}
loadFromDisk();

let writeQueue = Promise.resolve();
let writeScheduled = false;

function scheduleSave() {
    if (writeScheduled) return;
    writeScheduled = true;
    writeQueue = writeQueue.then(async () => {
        writeScheduled = false;
        await flushToDisk();
    }).catch((e) => {
        writeScheduled = false;
        console.log('[albumStore] Gagal simpan ke disk:', e?.message || e);
    });
}

async function flushToDisk() {
    if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

    const obj = {};
    for (const [key, record] of store.entries()) obj[key] = record;

    const tmpFile = `${DB_FILE}.${process.pid}.${Date.now()}.tmp`;
    await fs.promises.writeFile(tmpFile, JSON.stringify(obj));
    await fs.promises.rename(tmpFile, DB_FILE);
}

function keyOf(chatId, albumId) {
    return `${chatId}::${albumId}`;
}

function ensureRecord(chatId, albumId) {
    const key = keyOf(chatId, albumId);
    let record = store.get(key);
    if (!record) {
        record = { chatId, albumId, totalExpected: 0, children: [], updatedAt: Date.now() };
        store.set(key, record);
    }
    return record;
}

function saveMeta(albumId, chatId, totalExpected) {
    const record = ensureRecord(chatId, albumId);
    const n = Number(totalExpected);
    if (Number.isFinite(n) && n > 0) record.totalExpected = n;
    record.updatedAt = Date.now();
    scheduleSave();
}

function appendChild(albumId, chatId, type, content) {
    const record = ensureRecord(chatId, albumId);
    record.children.push({ type, content });
    record.updatedAt = Date.now();
    scheduleSave();
}

function getChildren(chatId, albumId) {
    const record = store.get(keyOf(chatId, albumId));
    if (!record) return [];
    return record.children.slice();
}

function getMeta(chatId, albumId) {
    const record = store.get(keyOf(chatId, albumId));
    if (!record) return { totalExpected: 0, receivedCount: 0 };
    return { totalExpected: record.totalExpected, receivedCount: record.children.length };
}

const cleanupTimer = setInterval(() => {
    const now = Date.now();
    let changed = false;
    for (const [key, record] of store.entries()) {
        if (now - record.updatedAt > TTL_MS) {
            store.delete(key);
            changed = true;
        }
    }
    if (changed) scheduleSave();
}, 30 * 60 * 1000);
cleanupTimer.unref();

export default { saveMeta, appendChild, getChildren, getMeta };
export { saveMeta, appendChild, getChildren, getMeta };
