const lastUsed = new Map();

const MAX_ENTRY_AGE_MS = 24 * 60 * 60 * 1000;

const cleanupTimer = setInterval(() => {
    const now = Date.now();
    for (const [key, ts] of lastUsed.entries()) {
        if (now - ts > MAX_ENTRY_AGE_MS) lastUsed.delete(key);
    }
}, 30 * 60 * 1000);
cleanupTimer.unref();

let _peringatanTanpaBot = false;
function idBot(bot) {
    const n = String(bot || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    if (!n && !_peringatanTanpaBot) {
        _peringatanTanpaBot = true;
        console.warn('[cooldown] dipanggil tanpa nomor bot -- cooldown tidak terpisah per bot untuk pemanggil ini.');
    }
    return n || '-';
}

function keyOf(chat, bot) {
    return idBot(bot) + '|' + String(chat);
}

function isFiniteNonNegativeNumber(n) {
    return typeof n === 'number' && Number.isFinite(n) && n >= 0;
}

function getEffectiveCooldown(chat) {
    const settings = (global.db && global.db.settings) || {};
    const ownPublic = Number(settings.publicCooldown);
    const publicSeconds = settings.publicCooldown !== undefined && settings.publicCooldown !== null && isFiniteNonNegativeNumber(ownPublic)
        ? ownPublic
        : 0;

    const group = chat && global.db && global.db.groups ? global.db.groups[chat] : null;
    const rawGroupValue = group ? group.cooldown : null;
    const hasGroupOverride = rawGroupValue !== null && rawGroupValue !== undefined && isFiniteNonNegativeNumber(Number(rawGroupValue));
    const groupSeconds = hasGroupOverride ? Number(rawGroupValue) : null;

    if (hasGroupOverride) {
        return { seconds: groupSeconds, source: 'group', publicSeconds, groupSeconds };
    }
    return { seconds: publicSeconds, source: 'public', publicSeconds, groupSeconds: null };
}

const EXEMPT_COMMANDS = new Set(['cooldown', 'publiccooldown']);

function isExemptCommand(command) {
    return EXEMPT_COMMANDS.has(command);
}

function checkAndConsume(chat, bot) {
    const { seconds } = getEffectiveCooldown(chat);
    if (!(seconds > 0)) return true;

    const cooldownMs = seconds * 1000;
    const key = keyOf(chat, bot);
    const now = Date.now();

    const last = lastUsed.get(key) || 0;
    if (last > 0 && (now - last) < cooldownMs) {
        return false;
    }

    lastUsed.set(key, now);
    return true;
}

function isCoolingDown(chat, bot) {
    const { seconds } = getEffectiveCooldown(chat);
    if (!(seconds > 0)) return false;

    const last = lastUsed.get(keyOf(chat, bot)) || 0;
    if (last <= 0) return false;

    return (Date.now() - last) < (seconds * 1000);
}

export default { getEffectiveCooldown, checkAndConsume, isCoolingDown, isExemptCommand };
export { getEffectiveCooldown, checkAndConsume, isCoolingDown, isExemptCommand };
