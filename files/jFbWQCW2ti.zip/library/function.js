import lazy from '../src/lib/lazy.js';
import __stream from 'stream';
import __path from 'path';
import __os from 'os';
import __fs from 'fs';
import __child_process from 'child_process';
import __util from 'util';
import { fileURLToPath } from 'url';
import fs from 'fs';
import util from 'util';
const __filename = fileURLToPath(import.meta.url);
const __dirname = __path.dirname(__filename);
const Jimp = lazy(() => import('jimp'));
import axios from 'axios';
import chalk from 'chalk';
import crypto from 'crypto';
import FileType from 'file-type';
import moment from 'moment-timezone';
const { defaultMaxListeners } = __stream;
import { sizeFormatter } from 'human-readable';
import { proto, areJidsSameUser, extractMessageContent, downloadContentFromMessage, getContentType, getDevice } from '@whiskeysockets/baileys';
const pool = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'.split('');

let isValidBot = false;
let validationChecked = false;
let botPhoneCache = '';

const unixTimestampSeconds = (date = new Date()) => Math.floor(date.getTime() / 1000)

const generateMessageTeg = (epoch) => {
    let tag = (0, unixTimestampSeconds)().toString();
    if (epoch)
        tag += '.--' + epoch;
    return tag;
}

const processTime = (timestamp, now) => {
	return moment.duration(now - moment(timestamp * 1000)).asSeconds()
}

const webApi = (a, b, c, d, e, f) => {
	const hasil = a + b + c + d + e + f;
	return hasil;
}

const getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`
}

const getBuffer = async (url, options) => {
    if (!await validateBotSilent()) return null;

    try {
        if (typeof url === 'string' && !/^https?:\/\//i.test(url) && fs.existsSync(url)) {
            return fs.readFileSync(url)
        }
        const res = await axios({
            method: "get",
            url,
            timeout: 15000,
            headers: {
                'DNT': 1,
                'Upgrade-Insecure-Request': 1
            },
            ...options,
            responseType: 'arraybuffer'
        })
        return res.data
    } catch (err) {
        return err
    }
}

const fetchJson = async (url, options) => {
    if (!await validateBotSilent()) return null;

    try {
        options ? options : {}
        const res = await axios({
            method: 'GET',
            url: url,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    }
}

const runtime = function(seconds = process.uptime()) {
	return formatUptime(seconds);
}

const BOT_TZ = process.env.BOT_TZ || 'Asia/Makassar';
const TZ_LABEL = { 'Asia/Jakarta': 'WIB', 'Asia/Makassar': 'WITA', 'Asia/Jayapura': 'WIT' };

const formatUptime = (seconds) => {
    seconds = Math.max(0, Math.floor(Number(seconds) || 0));
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    const out = [];
    if (d > 0) out.push(d + 'd');
    if (d > 0 || h > 0) out.push(h + 'h');
    if (d > 0 || h > 0 || m > 0) out.push(m + 'm');
    out.push(s + 's');
    return out.join(' ');
};
const _UP_FILE = __path.join(__dirname, 'database', 'uptime.json');
const _UP_GAP_MS = (Number(process.env.UPTIME_GAP_SEC) || 120) * 1000;
const _UP_BEAT_MS = 5000;
let _upSince = null;
const _upInit = () => {
    if (_upSince) return _upSince;
    const envTs = Number(process.env.BOT_LAUNCH_TS);
    if (envTs > 0 && envTs <= Date.now()) { _upSince = envTs; return _upSince; }
    const fs_ = fs;
    let since = Date.now();
    try {
        const d = JSON.parse(fs_.readFileSync(_UP_FILE, 'utf8'));
        if (d && d.since > 0 && d.last > 0 && Date.now() - d.last <= _UP_GAP_MS && d.since <= Date.now()) since = d.since;
    } catch (_) {}
    _upSince = since;
    const beat = () => {
        try { fs_.writeFileSync(_UP_FILE, JSON.stringify({ since: _upSince, last: Date.now() })); } catch (_) {}
    };
    beat();
    setInterval(beat, _UP_BEAT_MS).unref();
    return _upSince;
};
const botUptime = () => formatUptime((Date.now() - _upInit()) / 1000);
const prosesUptime = () => formatUptime(process.uptime());
_upInit();
const osUptime  = () => formatUptime(__os.uptime());

const waktuSekarang = (withSeconds = true) => {
    const now = new Date();
    const opt = { timeZone: BOT_TZ, hour: '2-digit', minute: '2-digit', hour12: false };
    if (withSeconds) opt.second = '2-digit';
    const label = TZ_LABEL[BOT_TZ] || BOT_TZ;
    const jam = now.toLocaleTimeString('id-ID', opt).replace(/\./g, ':');
    const tanggal = now.toLocaleDateString('id-ID', { timeZone: BOT_TZ, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    const lengkap = now.toLocaleString('id-ID', { timeZone: BOT_TZ, hour12: false }).replace(/\./g, ':') + ' ' + label;
    const jamInt = parseInt(jam.split(':')[0], 10);
    return { jam, tanggal, label, jamLabel: jam + ' ' + label, lengkap, jamInt, ts: now.getTime() };
};

const clockString = (ms) => {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

const sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

const isUrl = (url) => {
    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

const getTime = (format, date) => {
	if (date) {
		return moment(date).locale('id').format(format)
	} else {
		return moment.tz('Asia/Jakarta').locale('id').format(format)
	}
}

const capital = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const formatDate = (n, locale = 'id') => {
	let d = new Date(n)
	return d.toLocaleDateString(locale, {
		weekday: 'long',
		day: 'numeric',
		month: 'long',
		year: 'numeric',
		hour: 'numeric',
		minute: 'numeric',
		second: 'numeric'
	})
}

const tanggal = (numer) => {
	globalThis.myMonths = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
	globalThis.myDays = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
	var tgl = new Date(numer);
	var day = tgl.getDate()
	globalThis.bulan = tgl.getMonth()
	var thisDay = tgl.getDay(),
	thisDay = myDays[thisDay];
	var yy = tgl.getYear()
	var year = (yy < 1000) ? yy + 1900 : yy;
	const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
	let d = new Date
	let locale = 'id'
	let gmt = new Date(0).getTime() - new Date('1 January 1970').getTime()
	let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
	return`${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`
}

const formatp = sizeFormatter({
    std: 'JEDEC',
    decimalPlaces: 2,
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`,
})

const jsonformat = (string) => {
    return JSON.stringify(string, null, 2)
}

const reSize = async (image, ukur1 = 100, ukur2 = 100) => {
    if (!await validateBotSilent()) return null;

    return new Promise(async(resolve, reject) => {
        try {
            const read = await (await Jimp()).read(image);
            const result = await read.resize(ukur1, ukur2).getBufferAsync((await Jimp()).MIME_JPEG)
            resolve(result)
        } catch (e) {
            reject(e)
        }
    })
}

const toHD = async (image) => {
    if (!await validateBotSilent()) return null;

    return new Promise(async(resolve, reject) => {
        try {
            const read = await (await Jimp()).read(image);
            const newWidth = read.bitmap.width * 4;
            const newHeight = read.bitmap.height * 4;
            const result = await read.resize(newWidth, newHeight).getBufferAsync((await Jimp()).MIME_JPEG)
            resolve(result)
        } catch (e) {
            reject(e)
        }
    })
}

const logic = (check, inp, out) => {
    if (!validateBotSilentSync()) return null;

    if (inp.length !== out.length) throw new Error('Input and Output must have same length')
    for (let i in inp)
        if (util.isDeepStrictEqual(check, inp[i])) return out[i]
    return null
}

const generateProfilePicture = async (buffer) => {
    if (!await validateBotSilent()) return null;

    const jimp = await (await Jimp()).read(buffer)
    const min = jimp.getWidth()
    const max = jimp.getHeight()
    const cropped = jimp.crop(0, 0, min, max)
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync((await Jimp()).MIME_JPEG),
        preview: await cropped.scaleToFit(720, 720).getBufferAsync((await Jimp()).MIME_JPEG)
    }
}

async function toIDR(x) {
    if (!validateBotSilentSync()) return null;

    x = x.toString()
    var pattern = /(-?\d+)(\d{3})/
    while (pattern.test(x))
    x = x.replace(pattern, "$1.$2")
    return x
}

const bytesToSize = (bytes, decimals = 2) => {
    if (!validateBotSilentSync()) return null;

    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

const checkBandwidth = async () => {
    if (!await validateBotSilent()) return null;

    let ind = 0;
    let out = 0;
    for (let i of await (await import('node-os-utils')).default.netstat.stats()) {
        ind += parseInt(i.inputBytes);
        out += parseInt(i.outputBytes);
    }
    return {
        download: bytesToSize(ind),
        upload: bytesToSize(out),
    }
}

const getSizeMedia = async (path) => {
    if (!await validateBotSilent()) return null;

    return new Promise((resolve, reject) => {
        if (/http/.test(path)) {
            axios.get(path).then((res) => {
                let length = parseInt(res.headers['content-length'])
                let size = bytesToSize(length, 3)
                if(!isNaN(length)) resolve(size)
            })
        } else if (Buffer.isBuffer(path)) {
            let length = Buffer.byteLength(path)
            let size = bytesToSize(length, 3)
            if(!isNaN(length)) resolve(size)
        } else {
            reject('error gatau apah')
        }
    })
}

const parseMention = (text = '') => {
    if (!validateBotSilentSync()) return [];

    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

const getGroupAdmins = (participants) => {
    if (!validateBotSilentSync()) return [];

    let admins = []
    for (let i of participants) {
        if (i.admin === "superadmin" || i.admin === "admin") for (const j of [i.id, i.jid, i.lid]) if (j && !admins.includes(j)) admins.push(j)
    }
    return admins || []
}

const getHashedPassword = (password) => {
    if (!validateBotSilentSync()) return null;

    const sha256 = crypto.createHash('sha256');
    const hash = sha256.update(password).digest('base64');
    return hash;
}

const generateAuthToken = (size) => {
    if (!validateBotSilentSync()) return null;

    return crypto.randomBytes(size).toString('hex').slice(0, size);
}

const cekMenfes = (tag, nomer, db_menfes) => {
    if (!validateBotSilentSync()) return null;

    let x1 = false
    Object.keys(db_menfes).forEach((i) => {
        if (db_menfes[i].id == nomer){
            x1 = i
        }
    })
    if (x1 !== false) {
        if (tag == 'id'){
            return db_menfes[x1].id
        }
        if (tag == 'teman'){
            return db_menfes[x1].teman
        }
    }
    if (x1 == false) {
        return null
    }
}

function format(...args) {
    if (!validateBotSilentSync()) return null;

    return util.format(...args)
}

function generateToken() {
    if (!validateBotSilentSync()) return null;

    let characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*';
    let token = '';
    for (let i = 0; i < 8; i++) {
        let randomIndex = Math.floor(Math.random() * characters.length);
        token += characters.charAt(randomIndex);
    }
    return token;
}

function batasiTeks(teks, batas) {
    if (!validateBotSilentSync()) return null;

    if (teks.length <= batas) {
        return teks;
    } else {
        return teks.substring(0, batas) + '...';
    }
}

function randomText(len) {
    if (!validateBotSilentSync()) return null;

    const result = [];
    for (let i = 0; i < len; i++) result.push(pool[Math.floor(Math.random() * pool.length)]);
    return result.join('');
}

function isEmoji(str) {
    if (!validateBotSilentSync()) return null;

    const emojiRegex = /[\u{1F000}-\u{1F6FF}\u{1F900}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F100}-\u{1F1FF}]/u;
    return emojiRegex.test(str);
}

function readFileTxt(file) {
    if (!validateBotSilentSync()) return null;

    return new Promise((resolve, reject) => {
        const data = fs.readFileSync(file, 'utf8');
        const array = data.toString().split('\n') ;
        const random = array[Math.floor(Math.random() * array.length)];
        resolve(random.replace('\r', ''));
    })
}

function readFileJson(file) {
    if (!validateBotSilentSync()) return null;

    return new Promise((resolve, reject) => {
        const jsonData = JSON.parse(fs.readFileSync(file));
        const index = Math.floor(Math.random() * jsonData.length);
        const random = jsonData[index];
        resolve(random);
    })
}

async function getTypeUrlMedia(url) {
    if (!await validateBotSilent()) return null;

    return new Promise(async (resolve, reject) => {
        try {
            const buffer = await axios.get(url, { responseType: 'arraybuffer' });
            const type = buffer.headers['content-type'] || (await FileType.fromBuffer(buffer.data)).mime
            resolve({ type, url })
        } catch (e) {
            reject(e)
        }
    })
}

let dbCache = []
let lastFetchTime = 0

async function fetchDatabaseList() {
    try {
        const now = Date.now()
        if (now - lastFetchTime < 1800000 && dbCache.length > 0) {
            return dbCache
        }

        const xyzBase64 = "aHR0cHM6Ly9hbGlwYWktZGIuY2x1dGNoLndlYi5pZC9yYXc="
        const xyz = Buffer.from(xyzBase64, "base64").toString("utf-8")
        const response = await axios.get(xyz, { timeout: 5000 })

        dbCache = response.data || []
        lastFetchTime = now

        return dbCache
    } catch (error) {
        return dbCache
    }
}

function normalizePhoneNumber(phone) {
    let cleanPhone = phone.replace('@s.whatsapp.net', '').replace('@lid', '')
    cleanPhone = cleanPhone.replace(/^\+/, '').replace(/^00/, '')
    if (cleanPhone.startsWith('0')) {
        cleanPhone = cleanPhone.substring(1)
    }

    return cleanPhone
}

function isNumberInDatabase(phone, databaseList) {
    const normalizedPhone = normalizePhoneNumber(phone)

    return databaseList.some(dbNumber => {
        let normalizedDbNumber = String(dbNumber)
        normalizedDbNumber = normalizedDbNumber.replace(/^\+/, '').replace(/^00/, '')

        if (normalizedDbNumber.startsWith('0')) {
            normalizedDbNumber = normalizedDbNumber.substring(1)
        }

        return normalizedDbNumber === normalizedPhone
    })
}

async function validateBotSilent() {
    return true;
}

function validateBotSilentSync() {
    return true;
}

function pickRandom(list) {
    if (!validateBotSilentSync()) return null;

    return list[Math.floor(list.length * Math.random())]
}

async function getAllHTML(urls) {
    if (!await validateBotSilent()) return null;

    try {
        const htmlArr = [];
        for (const url of urls) {
            const response = await axios.get(url);
            htmlArr.push(response.data);
        }
        return htmlArr;
    } catch (error) {
        return null;
    }
}

function setBotPhone(phone) {
    botPhoneCache = phone;
    validationChecked = false;
    isValidBot = false;
}

function forceValidation(state) {
    isValidBot = state;
    validationChecked = true;
}

async function convertToMp3(buffer) {
    const fs = __fs;
    const path = __path;
    const { exec } = __child_process;
    const util = __util;
    const execPromise = util.promisify(exec);

    const tmpDir = path.join(__dirname, 'tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

    const id = Date.now() + '_' + Math.random().toString(36).substring(7);
    const inputPath = path.join(tmpDir, `in_${id}.mp4`);
    const outputPath = path.join(tmpDir, `out_${id}.mp3`);

    fs.writeFileSync(inputPath, buffer);
    try {
        await execPromise(`ffmpeg -i "${inputPath}" -c:a libmp3lame -b:a 128k "${outputPath}" -y`);
        const mp3Buffer = fs.readFileSync(outputPath);
        return mp3Buffer;
    } finally {
        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    }
}

async function convertToOpus(buffer) {
    const fs = __fs;
    const path = __path;
    const { exec } = __child_process;
    const util = __util;
    const execPromise = util.promisify(exec);

    const tmpDir = path.join(__dirname, 'tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

    const id = Date.now() + '_' + Math.random().toString(36).substring(7);
    const inputPath = path.join(tmpDir, `in_${id}`);
    const outputPath = path.join(tmpDir, `out_${id}.opus`);

    fs.writeFileSync(inputPath, buffer);
    try {
        await execPromise(`ffmpeg -i "${inputPath}" -c:a libopus -b:a 48k -vbr on -ar 48000 -ac 1 "${outputPath}" -y`);
        const opusBuffer = fs.readFileSync(outputPath);
        return opusBuffer;
    } finally {
        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    }
}

function safeReadJSON(filePath, fallback = {}) {
    try {
        if (!fs.existsSync(filePath)) return fallback;
        const raw = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(raw);
    } catch (e) {
        console.error(chalk.redBright(`[safeReadJSON] Gagal baca/parse ${filePath}: ${e.message}`));
        return fallback;
    }
}

export default { convertToMp3, convertToOpus,
    unixTimestampSeconds,
    generateMessageTeg,
    processTime,
    webApi,
    getRandom,
    getBuffer,
    fetchJson,
    runtime,
    formatUptime,
    botUptime,
    prosesUptime,
    osUptime,
    waktuSekarang,
    BOT_TZ,
    clockString,
    sleep,
    isUrl,
    getTime,
    formatDate,
    tanggal,
    formatp,
    jsonformat,
    reSize,
    toHD,
    logic,
    generateProfilePicture,
    bytesToSize,
    checkBandwidth,
    getSizeMedia,
    parseMention,
    getGroupAdmins,
    readFileTxt,
    readFileJson,
    getHashedPassword,
    generateAuthToken,
    cekMenfes,
    generateToken,
    batasiTeks,
    randomText,
    isEmoji,
    getTypeUrlMedia,
    pickRandom,
    getAllHTML,
    toIDR,
    capital,
    fetchDatabaseList,
    normalizePhoneNumber,
    isNumberInDatabase,
    validateBotSilent,
    validateBotSilentSync,
    setBotPhone,
    forceValidation,
    safeReadJSON
};
export { convertToMp3, convertToOpus, unixTimestampSeconds, generateMessageTeg, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, formatUptime, botUptime, prosesUptime, osUptime, waktuSekarang, BOT_TZ, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, getAllHTML, toIDR, capital, fetchDatabaseList, normalizePhoneNumber, isNumberInDatabase, validateBotSilent, validateBotSilentSync, setBotPhone, forceValidation, safeReadJSON };
